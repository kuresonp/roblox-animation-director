import { useEffect, useRef } from "react";
// @ts-ignore - plain JS rig module
import { initRig } from "./rig/rig.js";

export default function App() {
  const host = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!host.current) return;
    const dispose = initRig(host.current);
    return dispose;
  }, []);
  return <div ref={host} className="rig-host" />;
}

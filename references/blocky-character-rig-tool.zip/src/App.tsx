import { useEffect, useRef } from "react";
import { startRig } from "./rig/rig";

export default function App() {
  const host = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const stop = startRig(host.current!);
    return stop;
  }, []);
  return <div ref={host} />;
}

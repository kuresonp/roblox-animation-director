// @ts-nocheck
import * as THREE from "three";
import { HD, PI, V, superGeo, superPt, lockGeo, mulberry } from "./geo";

const { Y0, A, B, C, E1, E2 } = HD;
const sf = (u, v, k = 1) => superPt(u, v, k);
const wrap = (u) => ((((u + PI) % (2 * PI)) + 2 * PI) % (2 * PI)) - PI;
const vFor = (y) => {
  const s = Math.max(-0.995, Math.min(0.995, (y - Y0) / B));
  return Math.asin(Math.sign(s) * Math.pow(Math.abs(s), 1 / E1));
};
// hairline: front / side / back heights -> latitude function of u
const hl = (yF, yS, yB, ts = 1.5) => (u) => {
  const f = Math.abs(wrap(u)) / PI;
  let y;
  if (f < 0.5) y = yF + (yS - yF) * Math.pow(f / 0.5, ts);
  else { const q = (f - 0.5) / 0.5; y = yS + (yB - yS) * (q * q * (3 - 2 * q)); }
  return vFor(y);
};
const lerp = (a, b, t) => a + (b - a) * t;
const sstep = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

/* ---------- strand texture + glossy hair material ---------- */
const texCache = {};
function hairTex(color) {
  if (texCache[color]) return texCache[color];
  const mk = (base, bump) => {
    const cv = document.createElement("canvas"); cv.width = 128; cv.height = 256;
    const x = cv.getContext("2d"); x.fillStyle = base; x.fillRect(0, 0, 128, 256);
    const r = mulberry(bump ? 11 : 7);
    for (let i = 0; i < 130; i++) {
      const px = r() * 128, w = 0.7 + r() * 2.2, ph = r() * 6, amp = 1 + r() * 3;
      x.strokeStyle = bump ? `rgba(${r() > 0.5 ? "255,255,255" : "0,0,0"},${0.25 + r() * 0.5})` : r() > 0.45 ? `rgba(255,255,255,${0.03 + r() * 0.08})` : `rgba(0,0,0,${0.07 + r() * 0.18})`;
      x.lineWidth = w; x.beginPath();
      for (let y = 0; y <= 256; y += 16) x.lineTo(px + Math.sin(y * 0.03 + ph) * amp, y);
      x.stroke();
    }
    const t = new THREE.CanvasTexture(cv);
    t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 4;
    t.userData.keep = 1;
    if (!bump) t.colorSpace = THREE.SRGBColorSpace;
    return t;
  };
  return (texCache[color] = { map: mk(color, false), bump: mk("#808080", true) });
}
export function hairMat(color, opts = {}) {
  const t = hairTex(color);
  return new THREE.MeshPhysicalMaterial({
    color: 0xffffff, map: t.map, bumpMap: t.bump, bumpScale: 1.2, roughness: 0.5, clearcoat: 0.18, clearcoatRoughness: 0.4, envMapIntensity: 0.6,
    sheen: 0.35, sheenRoughness: 0.6, sheenColor: new THREE.Color(color).lerp(new THREE.Color("#ffffff"), 0.12),
    side: THREE.DoubleSide, ...opts,
  });
}

/* ---------- builders ---------- */
const SPH = new THREE.SphereGeometry(1, 18, 14);
const ID = new THREE.Quaternion();
const add = (b, g) => { const m = new THREE.Mesh(g, b.m); m.castShadow = m.receiveShadow = true; b.g.add(m); return m; };
const lk = (b, pts, w, th, o = {}) => add(b, lockGeo(pts, { w, th, ...o }));
const inst = (b, items) => {
  const im = new THREE.InstancedMesh(SPH, b.m, items.length), m = new THREE.Matrix4(), s = new THREE.Vector3();
  items.forEach((it, i) => { s.set(it.sx, it.sy ?? it.sx, it.sz ?? it.sx); m.compose(it.p, it.q || ID, s); im.setMatrixAt(i, m); });
  im.castShadow = im.receiveShadow = true; b.g.add(im);
};
const ball = (b, p, r, sx = 1, sy = 1, sz = 1) => inst(b, [{ p, sx: r * sx, sy: r * sy, sz: r * sz }]);

function shell(b, o) {
  const ke = o.ke ?? 1.015, k = o.k ?? 1.06;
  const g = superGeo({
    a: A, b: B, c: C, e1: E1, e2: E2, cy: Y0, vEnd: o.hl, vStart: o.vs ?? PI / 2, uSeg: 72, vSeg: 28,
    kf: (t) => (o.ring ? ke + (k - ke) * Math.sin(PI * t) : ke + (k - ke) * (1 - t * t)), uTiles: 5, vTiles: 2,
  });
  return add(b, g);
}
// lock that clings to the head along (u, v, k) waypoints
const sl = (b, list, w, th, o) => lk(b, list.map(([u, v, k = 1.07]) => sf(u, v, k)), w, th, o);
// lock running front-to-back along the head (phi: >0 toward the face, <0 toward the nape)
const sag = (b, s, list, w, th, o = {}) => {
  const spd = o.sp ?? 0.55;
  return lk(b, list.map(([ph, k]) => (ph >= 0 ? sf(s * spd, PI / 2 - ph, k) : sf(PI - s * spd, PI / 2 + ph, k))), w, th, o);
};
// lock that leaves the scalp at (u, v0) and hangs down
const hang = (b, u, v0, len, o = {}) => {
  const { w = 0.2, th = 0.1, wave = 0, ph = 0, out = 0.1, curl = 0, kk = 1.07, tx, tz, w1 = 0.45, tp = 1.5 } = o;
  const p0 = sf(u, v0 + 0.4, kk), p1 = sf(u, v0, kk);
  const r = V(Math.sin(u), 0, Math.cos(u)), sd = V(Math.cos(u), 0, -Math.sin(u));
  const pts = [p0, p1], n = 6;
  const T = tx !== undefined ? V(tx, 0, tz) : V(p1.x + r.x * out, 0, p1.z + r.z * out);
  for (let i = 1; i <= n; i++) {
    const f = i / n, e = f * (2 - f);
    const wv = wave * Math.sin(f * PI * 2 + ph) * f;
    pts.push(V(p1.x + (T.x - p1.x) * e + sd.x * wv + r.x * curl * f * f, p1.y - len * f, p1.z + (T.z - p1.z) * e + sd.z * wv + r.z * curl * f * f));
  }
  return lk(b, pts, w, th, { w1, tp });
};
const spike = (b, u, v, L, o = {}) => {
  const p0 = sf(u, v, 1), n = p0.clone().sub(V(0, Y0, 0)).normalize(), d = n.clone();
  if (o.bias) d.add(o.bias);
  if (o.rand) { d.x += (b.r() - 0.5) * o.rand; d.y += (b.r() - 0.5) * o.rand; d.z += (b.r() - 0.5) * o.rand; }
  d.normalize();
  const dr = o.droop || 0;
  lk(b, [p0.clone().addScaledVector(n, -0.08), p0, p0.clone().addScaledVector(d, L * 0.5).add(V(0, -dr * L * 0.1, 0)), p0.clone().addScaledVector(d, L).add(V(0, -dr * L * 0.45, 0))],
    o.w ?? 0.2, o.th ?? 0.14, { w1: o.w1 ?? 0, tp: 1, ref: o.ref });
};
const bundle = (b, spine, n, spread, w, th, o = {}) => {
  const lat = o.lat || V(1, 0, 0), dep = o.dep || V(0, 0, 1);
  for (let k = 0; k < n; k++) {
    const oo = n > 1 ? (k / (n - 1) - 0.5) * 2 : 0, dd = b.r() - 0.5;
    const pts = spine.map((p, i) => {
      const f = i / (spine.length - 1);
      return p.clone().addScaledVector(lat, oo * spread * (0.1 + f * 0.9) + Math.sin(f * 6 + k * 1.7) * (o.wave || 0) * f).addScaledVector(dep, dd * spread * 0.6 * f);
    });
    lk(b, pts, w, th, { w1: o.w1 ?? 0.3, tp: o.tp ?? 1.6 });
  }
};
const tie = (b, p, dir, r, col) => {
  const m = new THREE.Mesh(new THREE.TorusGeometry(r, r * 0.38, 10, 24), new THREE.MeshPhysicalMaterial({ color: col, roughness: 0.35, clearcoat: 0.6 }));
  m.userData.own = 1; m.geometry.userData.own = 1;
  m.position.copy(p); m.quaternion.setFromUnitVectors(V(0, 0, 1), dir.clone().normalize()); m.castShadow = true; b.g.add(m);
};
const braid = (b, spine, r, n) => {
  const curve = new THREE.CatmullRomCurve3(spine, false, "centripetal"), items = [], Y = V(0, 1, 0);
  for (let i = 0; i < n; i++) {
    const t = (i / (n - 1)) * 0.98, p = curve.getPointAt(t), T = curve.getTangentAt(t);
    const side = V().crossVectors(T, V(0, 0, 1)); if (side.length() < 0.2) side.crossVectors(T, V(1, 0, 0)); side.normalize();
    const s = i % 2 ? 1 : -1, rr = r * (1 - 0.5 * t);
    const q = new THREE.Quaternion().setFromUnitVectors(Y, T).multiply(new THREE.Quaternion().setFromAxisAngle(V(0, 0, 1), s * 0.75));
    items.push({ p: p.clone().addScaledVector(side, s * rr * 0.38), q, sx: rr * 0.9, sy: rr * 1.3, sz: rr * 0.85 });
  }
  inst(b, items);
  const e = curve.getPointAt(1), T = curve.getTangentAt(1);
  lk(b, [e.clone().addScaledVector(T, -0.1), e, e.clone().addScaledVector(T, 0.28).add(V(0, -0.05, 0))], r * 0.8, r * 0.6, { w1: 0, tp: 1 });
};
const puff = (b, c, R) => {
  const items = [{ p: c, sx: R * 0.85 }];
  for (let i = 0; i < 16; i++) {
    const a = b.r() * PI * 2, z = b.r() * 2 - 1, s = Math.sqrt(1 - z * z);
    items.push({ p: c.clone().add(V(Math.cos(a) * s, z, Math.sin(a) * s).multiplyScalar(R * 0.62)), sx: R * (0.4 + b.r() * 0.12) });
  }
  inst(b, items);
};
const curls = (b, n, o) => {
  const items = []; let tries = 0;
  while (items.length < n && tries++ < n * 30) {
    const s = lerp(o.s0 ?? 0, 1, b.r()), v = Math.asin(s) * (o.vmax ? 1 : 1), u = b.r() * PI * 2;
    const vv = o.lo !== undefined ? lerp(o.lo, PI / 2, Math.pow(b.r(), o.pw ?? 0.7)) : v;
    if (o.ok && !o.ok(u, vv)) continue;
    const r = o.r * (0.8 + b.r() * 0.45);
    items.push({ p: sf(u, vv, o.k ?? 1.1).add(V(0, o.up ?? 0, 0)), sx: r, sy: r * (o.sy ?? 1) });
  }
  inst(b, items);
};
const noFace = (u, v) => !(Math.abs(wrap(u)) < 1.0 && v < 0.82);

const fringe = (b, o = {}) => {
  const n = o.n ?? 7, end = o.end ?? 1.2, k = o.k ?? 1.1;
  for (let i = 0; i < n; i++) {
    const s = n > 1 ? (i / (n - 1) - 0.5) * 2 : 0;
    sag(b, s, [[-0.5, 1.07], [0, 1.1], [0.5, k], [0.9, k + 0.01], [end - Math.abs(s) * (o.arc ?? 0.1), k]], o.w ?? 0.24, o.th ?? 0.1, { sp: o.sp ?? 0.85, w1: 0.25 });
  }
};
const curtain = (b, o = {}) => {
  for (const sg of [-1, 1]) for (let j = 0; j < (o.n ?? 3); j++) {
    sl(b, [[sg * 0.1, 1.45], [sg * (0.38 + j * 0.1), 1.0, 1.1], [sg * (0.8 + j * 0.15), 0.62 - j * 0.07, 1.12], [sg * (1.25 + j * 0.1), 0.2 - j * 0.1 - (o.drop ?? 0), 1.09]], 0.26, 0.1, { w1: 0.25 });
  }
};
const swoop = (b, side = 1) => {
  sl(b, [[-0.7 * side, 1.2, 1.075], [-0.2 * side, 1.0, 1.1], [0.4 * side, 0.8, 1.13], [0.85 * side, 0.6, 1.11], [1.15 * side, 0.4, 1.07]], 0.34, 0.12, { w1: 0.15 });
  sl(b, [[-0.7 * side, 1.3, 1.08], [0, 1.1, 1.12], [0.6 * side, 0.9, 1.12], [1.1 * side, 0.65, 1.09], [1.3 * side, 0.4, 1.06]], 0.3, 0.12, { w1: 0.15 });
  sl(b, [[-0.4 * side, 1.4, 1.08], [0.2 * side, 1.12, 1.12], [0.8 * side, 0.85, 1.1], [1.3 * side, 0.55, 1.07]], 0.26, 0.1, { w1: 0.15 });
};
// curtain of hanging hair around the back and sides
const fall = (b, o = {}) => {
  const { len = 1.9, ls = len * 0.85, wave = 0.1, curl = 0, n = 22, w = 0.27, th = 0.12, v0 = 0.05, span = 1.65, front = true, ns = 2, w1 = 0.45 } = o;
  for (let i = 0; i < n; i++) {
    const f = i / (n - 1), u = PI - span + 2 * span * f;
    const L = len * (0.92 + b.r() * 0.16) + (o.dl ? o.dl(u) : 0);
    hang(b, u, v0 - 0.08 * Math.sin(f * PI), L, { w, th, wave, ph: b.r() * 6, out: 0.1, curl, w1 });
  }
  for (const s of [-1, 1]) for (let j = 0; j < ns; j++) {
    const u = s * (1.0 + j * 0.2), L = ls * (0.95 + b.r() * 0.1) + (o.dl ? o.dl(u) : 0);
    hang(b, u, v0, L, { w, th, wave: wave * 0.8, ph: b.r() * 6, w1, ...(front ? { tx: s * (0.66 + j * 0.04), tz: 0.82 } : { out: 0.12 }), curl: front ? 0 : curl });
  }
};
const topKnot = (b, c, r, col) => {
  ball(b, c, r, 1, 0.9, 1);
  tie(b, c.clone().add(V(0, -r * 0.7, 0)), V(0, 1, 0), r * 0.62, col);
};
const sampleHeads = (b, n, o) => {
  const items = []; let t = 0;
  while (items.length < n && t++ < n * 40) {
    const v = Math.asin(lerp(o.s0, 1, Math.pow(b.r(), o.pw ?? 0.8))), u = b.r() * PI * 2;
    if (o.ok && !o.ok(u, v)) continue;
    const r = o.r * (0.85 + b.r() * 0.35);
    items.push({ p: sf(u, v, o.k), sx: r });
  }
  inst(b, items);
};

/* ---------- facial hair ---------- */
const vsBeard = (front) => (u) => {
  const a = Math.abs(wrap(u));
  if (a < 0.55) return front;
  if (a < 1.1) return lerp(front, 0.12, (a - 0.55) / 0.55);
  return lerp(0.12, -0.25, Math.min(1, (a - 1.1) / 1.4));
};
function beardShell(b, o) {
  const g = superGeo({
    a: A, b: B, c: C, e1: E1, e2: E2, cy: Y0, uMin: -(o.u ?? 2.4), uMax: o.u ?? 2.4, uSeg: 48, vSeg: 20,
    vStart: o.vs, vEnd: o.ve ?? -PI / 2, kf: (t) => (o.k ?? 1.05) - 0.04 * Math.pow(1 - t, 2.5), uTiles: 4, vTiles: 1,
  });
  return add(b, g);
}
function mustache(b, w = 0.085) {
  const y = Y0 - 0.17;
  lk(b, [V(-0.36, y - 0.1, 0.62), V(-0.22, y - 0.03, 0.7), V(-0.07, y, 0.725), V(0, y - 0.005, 0.73)], w, w * 0.8, { w1: 0.3, tp: 1.2, ref: V(0, 0, 1) });
  lk(b, [V(0.36, y - 0.1, 0.62), V(0.22, y - 0.03, 0.7), V(0.07, y, 0.725), V(0, y - 0.005, 0.73)], w, w * 0.8, { w1: 0.3, tp: 1.2, ref: V(0, 0, 1) });
}
function addBeard(b, type) {
  if (type === "full") { beardShell(b, { vs: vsBeard(-0.62), k: 1.06 }); mustache(b); }
  else if (type === "goatee") beardShell(b, { vs: () => -0.6, u: 0.5, k: 1.07 });
  else if (type === "vandyke") { beardShell(b, { vs: () => -0.6, u: 0.4, k: 1.07 }); mustache(b, 0.075); }
  else if (type === "mustache") mustache(b, 0.1);
  else if (type === "stubble") {
    b.m = hairMat(b.col, { transparent: true, opacity: 0.38, depthWrite: false });
    beardShell(b, { vs: vsBeard(-0.2), k: 1.02 }).renderOrder = 4;
  } else if (type === "chin") beardShell(b, { vs: () => -0.62, ve: -1.15, u: 0.32, k: 1.06 });
}

/* ---------- the style library ---------- */
const H = {};
const S = (k, n, f) => (H[k] = { k, n, f });
const std = (k = 1.065) => (b) => shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.1, Y0 - 0.22), k });
const shortSides = hl(Y0 + 0.52, Y0 + 0.28, Y0 + 0.02);

S("none", "None (cap only)", null);
S("bald", "Bald", null);
S("buzz", "Buzz Cut", (b) => shell(b, { hl: hl(Y0 + 0.52, Y0 + 0.12, Y0 - 0.2), k: 1.03, ke: 1.012 }));
S("crop", "Textured Crop", (b) => { shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.14, Y0 - 0.2), k: 1.06 }); fringe(b, { n: 6, end: 1.12, w: 0.22, k: 1.09, arc: 0.06 }); });
S("sidepart", "Side Part", (b) => { shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.1, Y0 - 0.2), k: 1.07 }); swoop(b, 1); });
S("quiff", "Pompadour Quiff", (b) => {
  shell(b, { hl: hl(Y0 + 0.55, Y0 + 0.2, Y0 - 0.05), k: 1.07 });
  for (let i = 0; i < 7; i++) { const s = (i / 6 - 0.5) * 2; sag(b, s, [[-1.1, 1.05], [-0.5, 1.09], [0, 1.15], [0.4, 1.24], [0.75, 1.32], [1.0 - Math.abs(s) * 0.1, 1.3]], 0.36, 0.26, { sp: 0.62, w1: 0.45 }); }
});
S("slick", "Slicked Back", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.12, Y0 - 0.2), k: 1.06 });
  for (let i = 0; i < 7; i++) { const s = (i / 6 - 0.5) * 2; sag(b, s, [[1.0, 1.05], [0.5, 1.09], [0, 1.1], [-0.6, 1.09], [-1.2, 1.07], [-1.75, 1.05]], 0.24, 0.1, { sp: 0.7, w1: 0.2 }); }
});
S("messy", "Messy Textured", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.1, Y0 - 0.2), k: 1.07 });
  for (let i = 0; i < 14; i++) { const v = 0.75 + b.r() * 0.8, u = b.r() * PI * 2; if (!noFace(u, v) && v < 1.0) { i--; continue; } spike(b, u, v, 0.5 + b.r() * 0.35, { w: 0.2, th: 0.13, rand: 0.9, droop: 1, bias: V(0, 0.15, 0.1) }); }
});
S("curlytop", "Curly Top Fade", (b) => {
  shell(b, { hl: shortSides, k: 1.04 });
  curls(b, 60, { lo: 0.55, r: 0.2, k: 1.1, ok: (u, v) => noFace(u, v) || v > 0.75 });
});
S("afro", "Big Afro", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.2, Y0 - 0.1), k: 1.07 });
  sampleHeads(b, 120, { s0: -0.05, r: 0.42, k: 1.14, ok: noFace });
  sampleHeads(b, 26, { s0: 0.8, r: 0.4, k: 1.24, ok: noFace });
});
S("mohawk", "Spiked Mohawk", (b) => {
  shell(b, { hl: hl(Y0 + 0.45, Y0 + 0.3, Y0 + 0.0), k: 1.012, ke: 1.01 });
  for (let ph = -1.4; ph <= 1.0; ph += 0.15) {
    const p0 = ph >= 0 ? sf(0, PI / 2 - ph, 1) : sf(PI, PI / 2 + ph, 1), n = p0.clone().sub(V(0, Y0, 0)).normalize();
    const Lh = 0.8 - Math.abs(ph + 0.2) * 0.22, d = n.clone().add(V(0, 0, -0.35)).normalize();
    lk(b, [p0.clone().addScaledVector(n, -0.08), p0.clone().addScaledVector(n, 0.12), p0.clone().addScaledVector(d, Lh * 0.6), p0.clone().addScaledVector(d, Lh)], 0.15, 0.085, { ref: V(1, 0, 0), w1: 0.1, tp: 1 });
  }
});
S("spiky", "Anime Spikes", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.1, Y0 - 0.2), k: 1.06 });
  const L = [[0.0, 1.0, 0.95, 0, 0.4, 0.5], [0.5, 0.95, 0.9, 0.3, 0.3, 0.3], [-0.5, 0.95, 0.9, -0.3, 0.3, 0.3], [0.0, 1.3, 1.1, 0, 1, -0.1], [1.0, 1.25, 1.0, 0.6, 0.8, 0], [-1.0, 1.25, 1.0, -0.6, 0.8, 0],
    [2.0, 1.2, 1.0, 0.5, 0.5, -0.5], [-2.0, 1.2, 1.0, -0.5, 0.5, -0.5], [3.14, 1.1, 1.0, 0, 0.2, -0.8], [1.5, 0.7, 0.8, 0.8, 0.1, -0.1], [-1.5, 0.7, 0.8, -0.8, 0.1, -0.1], [0.9, 0.95, 0.85, 0.5, 0.5, 0.3], [-0.9, 0.95, 0.85, -0.5, 0.5, 0.3]];
  L.forEach(([u, v, l, x, y, z]) => spike(b, u, v, l, { w: 0.3, th: 0.3, bias: V(x, y, z), droop: 0.2 }));
});
S("manbun", "Man Bun", (b) => {
  shell(b, { hl: hl(Y0 + 0.52, Y0 + 0.28, Y0 + 0.05), k: 1.04 });
  for (let i = 0; i < 5; i++) { const s = (i / 4 - 0.5) * 2; sag(b, s, [[1.0, 1.05], [0.3, 1.08], [-0.4, 1.1], [-0.9, 1.1]], 0.26, 0.1, { sp: 0.55, w1: 0.4 }); }
  topKnot(b, sf(PI, 1.05, 1.02).add(V(0, 0.3, -0.12)), 0.34, "#222");
});
S("rocker", "Long Wavy Rocker", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.0, Y0 - 0.3), k: 1.08 });
  fall(b, { len: 2.0, ls: 1.7, wave: 0.14, w: 0.28, n: 24 }); curtain(b, { n: 3 });
});
S("dreads", "Dreadlocks", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.1, Y0 - 0.1), k: 1.06 });
  for (let i = 0; i < 30; i++) {
    const u = 0.9 + (i / 29) * (PI * 2 - 1.8), a = Math.abs(wrap(u)), v0 = lerp(0.15, -0.15, b.r()) + (a < 1.3 ? 0.15 : 0);
    const side = Math.sin(u) > 0 ? 1 : -1, front = a < 1.7 && a > 0.85;
    hang(b, u, v0, 1.1 + b.r() * 0.9, { w: 0.085, th: 0.085, wave: 0.05, ph: b.r() * 6, out: 0.14, w1: 0.8, tp: 3, ...(front ? { tx: side * 0.7, tz: 0.8 } : {}) });
  }
});
S("curtains", "90s Curtains", (b) => { shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.1, Y0 - 0.2), k: 1.07 }); curtain(b, { n: 4 }); });
S("undercut", "Undercut Slick Top", (b) => {
  shell(b, { hl: shortSides, k: 1.03, ke: 1.012 });
  for (let i = 0; i < 6; i++) { const s = (i / 5 - 0.5) * 2; sag(b, s, [[1.1, 1.1], [0.6, 1.15], [0, 1.16], [-0.6, 1.13], [-1.1, 1.09], [-1.5, 1.05]], 0.25, 0.14, { sp: 0.5, w1: 0.3 }); }
});
S("mullet", "Mullet", (b) => {
  shell(b, { hl: hl(Y0 + 0.52, Y0 + 0.1, Y0 - 0.35), k: 1.07 });
  fall(b, { len: 1.3, wave: 0.1, n: 16, span: 1.2, ns: 0 });
  for (let i = 0; i < 6; i++) { const s = (i / 5 - 0.5) * 2; sag(b, s, [[0.9, 1.08], [0.3, 1.11], [-0.4, 1.11]], 0.24, 0.1, { sp: 0.5 }); }
});
S("elder", "Wispy Elder", (b) => {
  const g = (u) => sstep(0.7, 1.3, Math.abs(wrap(u)));
  shell(b, { ring: true, vs: (u) => vFor(lerp(Y0 + 0.56, Y0 + 0.36, g(u))), hl: (u) => vFor(lerp(Y0 + 0.55, Y0 - 0.12, g(u))), k: 1.07, ke: 1.015 });
});

// -------- female-leaning styles --------
S("longstraight", "Long Straight", (b) => { shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.0, Y0 - 0.3), k: 1.075 }); fall(b, { len: 2.3, ls: 2.0, wave: 0.03, n: 26 }); curtain(b, { n: 3 }); });
S("longcurtain", "Long + Curtain Bangs", (b) => { shell(b, { hl: hl(Y0 + 0.48, Y0 - 0.02, Y0 - 0.3), k: 1.075 }); fall(b, { len: 2.5, ls: 2.2, wave: 0.05, n: 26 }); curtain(b, { n: 4, drop: 0.1 }); });
S("longwavy", "Long Waves", (b) => { shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.0, Y0 - 0.3), k: 1.09 }); fall(b, { len: 2.1, ls: 1.9, wave: 0.2, n: 26, w: 0.3 }); fringe(b, { n: 7, end: 1.15, arc: 0.12 }); });
S("sweptbangs", "Swept Bangs Long", (b) => { shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.0, Y0 - 0.3), k: 1.08 }); fall(b, { len: 1.9, ls: 1.7, wave: 0.12, n: 24 }); swoop(b, -1); });
S("bob", "Chin Bob + Bangs", (b) => { shell(b, { hl: hl(Y0 + 0.5, Y0 - 0.05, Y0 - 0.3), k: 1.08 }); fall(b, { len: 1.0, ls: 0.78, wave: 0.02, curl: -0.12, n: 24, front: false, w: 0.28, v0: 0.0 }); fringe(b, { n: 8, end: 1.17, arc: 0.08 }); });
S("lob", "Asymmetric Lob", (b) => { shell(b, { hl: hl(Y0 + 0.5, Y0 - 0.02, Y0 - 0.3), k: 1.08 }); fall(b, { len: 1.35, ls: 1.1, wave: 0.05, curl: -0.1, n: 24, front: false, v0: 0.0, dl: (u) => (Math.sin(u) > 0 ? 0.45 : -0.1) }); swoop(b, 1); });
S("pixie", "Pixie Cut", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.14, Y0 - 0.25), k: 1.07 }); swoop(b, -1);
  for (let i = 0; i < 6; i++) spike(b, 2.2 + b.r() * 1.8, 0.3 + b.r() * 0.5, 0.3, { w: 0.18, th: 0.1, droop: 1, bias: V(0, -0.2, -0.2) });
});
S("highpony", "High Ponytail", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.08, Y0 - 0.2), k: 1.07 }); fringe(b, { n: 6, end: 1.1, arc: 0.1 });
  const o = sf(PI, 0.95, 1.07), sp = [o.clone().add(V(0, -0.05, 0)), o.clone().add(V(0, 0.12, -0.2)), o.clone().add(V(0, 0.14, -0.5)), o.clone().add(V(0, -0.2, -0.78)), o.clone().add(V(0, -0.85, -0.86)), o.clone().add(V(0, -1.55, -0.78)), o.clone().add(V(0, -2.1, -0.7))];
  bundle(b, sp, 8, 0.42, 0.2, 0.1, { wave: 0.06 }); tie(b, sp[1].clone().lerp(sp[2], 0.2), sp[2].clone().sub(sp[1]), 0.17, "#ff4f9a");
});
S("lowpony", "Low Side Ponytail", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.05, Y0 - 0.25), k: 1.07 }); swoop(b, 1);
  const o = sf(2.6, 0.05, 1.07), sp = [o.clone(), o.clone().add(V(0.1, -0.1, -0.1)), o.clone().add(V(0.2, -0.6, -0.05)), o.clone().add(V(0.28, -1.3, 0.05)), o.clone().add(V(0.3, -2.0, 0.12))];
  bundle(b, sp, 7, 0.38, 0.2, 0.1, { wave: 0.06 }); tie(b, sp[1], V(0.1, -1, 0), 0.16, "#2f6bff");
});
S("pigtails", "Pigtails", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.1, Y0 - 0.2), k: 1.07 }); fringe(b, { n: 7, end: 1.15, arc: 0.1 });
  for (const s of [-1, 1]) {
    const o = sf(s * 1.95, 0.6, 1.07), sp = [o.clone().add(V(0, 0.05, 0)), o.clone().add(V(s * 0.15, 0.0, -0.05)), o.clone().add(V(s * 0.4, -0.35, -0.1)), o.clone().add(V(s * 0.5, -0.95, -0.05)), o.clone().add(V(s * 0.46, -1.6, 0.05))];
    bundle(b, sp, 6, 0.3, 0.19, 0.1, { wave: 0.06 }); tie(b, sp[1], V(s, 0.2, 0), 0.15, "#ff4f9a");
  }
});
S("spacebuns", "Space Buns", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.1, Y0 - 0.2), k: 1.07 }); fringe(b, { n: 7, end: 1.13, arc: 0.1 });
  for (const s of [-1, 1]) { const c = sf(s * 1.3, 1.0, 1.12).add(V(s * 0.12, 0.28, -0.1)); puff(b, c, 0.34); }
});
S("topbun", "Top Bun + Bangs", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.1, Y0 - 0.2), k: 1.07 }); fringe(b, { n: 7, end: 1.15, arc: 0.1 }); curtain(b, { n: 1 });
  topKnot(b, sf(PI, 1.18, 1.02).add(V(0, 0.34, -0.1)), 0.4, "#2f6bff");
});
S("lowbun", "Low Bun Side Part", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.1, Y0 - 0.25), k: 1.07 }); swoop(b, -1);
  const c = sf(PI, 0.0, 1.05).add(V(0, -0.15, -0.2)); ball(b, c, 0.38, 1, 0.95, 0.9); tie(b, c.clone().add(V(0, 0.22, 0.12)), V(0, 0.6, -1), 0.3, "#d11a40");
});
S("sidebraid", "Side Braid", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.05, Y0 - 0.4), k: 1.07 }); swoop(b, 1);
  braid(b, [sf(2.0, 0.25, 1.06), sf(1.3, 0.05, 1.08).add(V(0.0, 0, 0.1)), V(0.82, 0.1, 0.35), V(0.8, -0.5, 0.72), V(0.72, -1.2, 0.86), V(0.68, -1.9, 0.82), V(0.66, -2.4, 0.8)], 0.17, 22);
  tie(b, V(0.66, -2.35, 0.8), V(0, 1, 0), 0.12, "#ffd23f");
});
S("twinbraids", "Twin Braids", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.0, Y0 - 0.4), k: 1.07 }); curtain(b, { n: 1 });
  for (const s of [-1, 1]) {
    braid(b, [sf(s * 1.9, 0.3, 1.06), sf(s * 1.4, 0.0, 1.08), V(s * 0.83, 0.1, 0.3), V(s * 0.8, -0.5, 0.72), V(s * 0.75, -1.2, 0.86), V(s * 0.72, -1.8, 0.84)], 0.16, 18);
    tie(b, V(s * 0.72, -1.78, 0.84), V(0, 1, 0), 0.115, "#e3302b");
  }
});
S("bigcurls", "Big Bouncy Curls", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.05, Y0 - 0.3), k: 1.08 });
  curls(b, 150, { lo: -0.75, r: 0.25, k: 1.15, pw: 0.9, ok: noFace });
  for (const s of [-1, 1]) for (let j = 0; j < 3; j++) inst(b, [{ p: V(s * (0.82 + j * 0.02), 0.1 - j * 0.35, 0.28 + j * 0.2), sx: 0.26 - j * 0.02 }]);
});
S("afropuffs", "Afro Puffs", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.15, Y0 - 0.15), k: 1.07 });
  for (const s of [-1, 1]) { puff(b, sf(s * 1.25, 0.95, 1.1).add(V(s * 0.3, 0.3, -0.05)), 0.52); }
  fringe(b, { n: 5, end: 1.1, arc: 0.1 });
});
S("wolf", "Layered Wolf Cut", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 - 0.05, Y0 - 0.3), k: 1.09 });
  fall(b, { len: 1.5, ls: 1.2, wave: 0.2, n: 26, span: 1.7, w: 0.3, w1: 0.1, front: false, dl: () => (Math.random() - 0.5) * 0.0 + Math.sin(Math.random() * 9) * 0.25 });
  curtain(b, { n: 3 });
  for (let i = 0; i < 8; i++) spike(b, 2.0 + b.r() * 2.2, 0.6 + b.r() * 0.6, 0.45, { w: 0.2, th: 0.12, droop: 1.5, bias: V(0, 0.1, -0.2) });
});
S("curlybob", "Curly Bob", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 + 0.05, Y0 - 0.3), k: 1.08 });
  curls(b, 110, { lo: -0.45, r: 0.24, k: 1.13, pw: 0.9, ok: noFace });
});
S("halfup", "Half-Up Waves", (b) => {
  shell(b, { hl: hl(Y0 + 0.5, Y0 - 0.02, Y0 - 0.3), k: 1.08 }); fall(b, { len: 2.0, ls: 1.8, wave: 0.16, n: 24 }); fringe(b, { n: 5, end: 1.08, arc: 0.1 });
  topKnot(b, sf(PI, 1.2, 1.02).add(V(0, 0.28, -0.1)), 0.28, "#ff4f9a");
});

export const HAIR = Object.values(H);
export const HAIR_INDEX = Object.fromEntries(HAIR.map((h, i) => [h.k, i]));

// builds a hair + facial-hair group in head-local coordinates
export function buildHair(styleKey, color, beard, seed = 1) {
  const g = new THREE.Group(), st = H[styleKey];
  const b = { g, m: hairMat(color), col: color, r: mulberry(seed * 977 + 13) };
  if (st && st.f) st.f(b);
  if (beard) addBeard(b, beard);
  g.userData.mats = b.m;
  return g;
}

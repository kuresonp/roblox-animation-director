// @ts-nocheck
import * as THREE from "three";
import { G, M, P } from "./geo.js";
import { heart, star } from "./face.js";

export function patTex(p, c) {
  const cv = document.createElement("canvas");
  cv.width = cv.height = 128;
  const x = cv.getContext("2d");
  x.fillStyle = x.strokeStyle = c;
  x.lineWidth = 8;
  x.lineCap = x.lineJoin = "round";
  switch (p) {
    case "band": x.fillRect(0, 50, 128, 28); break;
    case "stripes": for (let y = 14; y < 128; y += 32) x.fillRect(0, y, 128, 14); break;
    case "star": star(x, 64, 66, 50, 22); x.fill(); break;
    case "heart": heart(x, 64, 62, 38); x.fill(); break;
    case "logo": x.fillRect(30, 36, 68, 56); x.fillStyle = "#fff"; x.beginPath(); x.moveTo(56, 52); x.lineTo(82, 64); x.lineTo(56, 76); x.fill(); break;
    case "pocket": x.lineWidth = 6; x.strokeRect(70, 30, 40, 38); break;
    case "badge": star(x, 86, 44, 28, 12); x.fill(); x.strokeStyle = "#9a6b00"; x.lineWidth = 4; x.stroke(); break;
    case "buttons": [26, 62, 98].forEach((y) => { x.beginPath(); x.arc(64, y, 8, 0, 7); x.fill(); }); break;
    case "bolt": x.beginPath(); x.moveTo(78, 8); x.lineTo(40, 68); x.lineTo(62, 68); x.lineTo(50, 120); x.lineTo(92, 54); x.lineTo(68, 54); x.closePath(); x.fill(); break;
    case "tie": x.beginPath(); x.moveTo(54, 4); x.lineTo(74, 4); x.lineTo(70, 32); x.lineTo(84, 98); x.lineTo(64, 122); x.lineTo(44, 98); x.lineTo(58, 32); x.closePath(); x.fill(); break;
    case "smile":
      x.beginPath(); x.arc(64, 64, 42, 0, 7); x.fill();
      x.fillStyle = x.strokeStyle = "#222"; x.fillRect(48, 46, 9, 16); x.fillRect(71, 46, 9, 16);
      x.lineWidth = 6; x.beginPath(); x.arc(64, 66, 22, 0.25, 2.9); x.stroke();
      break;
  }
  return new THREE.CanvasTexture(cv);
}

/* ---------- the Main Character's red cap (from the reference render) ---------- */
const warp = (x, z) => {
  const r = Math.hypot(x, z);
  if (r < 1e-6) return [x, z];
  const c = x / r, s = z / r, f = Math.pow(Math.pow(Math.abs(c), 3) + Math.pow(Math.abs(s), 3), -1 / 3);
  return [x * f, z * f];
};

/* fit a round hat part to the boxy head: squircle footprint, slightly shallower front-to-back */
const fit = (ge, zs = 0.95) => {
  const p = ge.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const [x, z] = warp(p.getX(i), p.getZ(i));
    p.setX(i, x);
    p.setZ(i, z * zs);
  }
  p.needsUpdate = true;
  ge.userData.own = 1;
  return ge;
};

function mainCap(g) {
  const red = P("#e31f27"),
    seam = P("#a8121a"),
    cream = P("#f4ecd0");
  red.side = THREE.DoubleSide;
  red.clearcoat = 0.9;
  red.clearcoatRoughness = 0.12;
  red.roughness = 0.32;
  const R = 0.64, y0 = 0.1, Ht = 0.52, n = 2.5, Y0 = 0.94;
  const dome = (u) => [R * Math.pow(Math.cos(u), 2 / n), y0 + Ht * Math.pow(Math.sin(u), 2 / n)];
  const pts = [
    new THREE.Vector2(0.62, 0), new THREE.Vector2(0.652, 0.012), new THREE.Vector2(0.658, 0.04), new THREE.Vector2(0.648, 0.072),
  ];
  for (let i = 0; i <= 26; i++) {
    const u = (i / 26) * (Math.PI / 2 - 0.001),
      [r, y] = dome(u);
    pts.push(new THREE.Vector2(Math.max(r, 0.0005), y));
  }
  pts.push(new THREE.Vector2(0, y0 + Ht));
  const body = new THREE.Group();
  body.position.y = Y0;
  body.scale.set(1, 1, 0.95);
  const lg = new THREE.LatheGeometry(pts, 72);
  {
    const pp = lg.attributes.position;
    for (let i = 0; i < pp.count; i++) {
      const [wx, wz] = warp(pp.getX(i), pp.getZ(i));
      pp.setX(i, wx);
      pp.setZ(i, wz);
    }
  }
  const shell = M(lg, red);
  shell.geometry.userData.own = 1;
  body.add(shell);
  /* six panel seams */
  for (let k = 0; k < 6; k++) {
    const a = Math.PI / 6 + (k * Math.PI) / 3,
      cp = [];
    for (let i = 0; i <= 22; i++) {
      const [r, y] = dome((i / 22) * 1.5);
      const [wx, wz] = warp(Math.sin(a) * r * 1.004, Math.cos(a) * r * 1.004);
      cp.push(new THREE.Vector3(wx, y, wz));
    }
    const tube = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(cp), 28, 0.0085, 6), seam);
    tube.geometry.userData.own = 1;
    body.add(tube);
  }
  /* button */
  const btn = M(new THREE.SphereGeometry(0.095, 20, 12), cream, 0, y0 + Ht - 0.012, 0);
  btn.scale.set(1, 0.72, 1);
  btn.geometry.userData.own = 1;
  body.add(btn);
  g.add(body);
  /* "V" logo, extruded and tilted to follow the dome */
  const s = new THREE.Shape();
  [[-0.17, 0.16], [-0.058, 0.16], [0, -0.03], [0.058, 0.16], [0.17, 0.16], [0.05, -0.16], [-0.05, -0.16]].forEach(([px, py], i) => (i ? s.lineTo(px, py) : s.moveTo(px, py)));
  const vg = new THREE.ExtrudeGeometry(s, { depth: 0.035, bevelEnabled: true, bevelSize: 0.008, bevelThickness: 0.008, bevelSegments: 2 });
  vg.userData.own = 1;
  const u = 0.38,
    [r1, y1] = dome(u - 0.02),
    [r2, y2] = dome(u + 0.02),
    [rc, yc] = dome(u);
  const V = M(vg, cream);
  V.scale.setScalar(0.9);
  V.rotation.x = -Math.atan2(r1 - r2, y2 - y1);
  V.position.set(0, Y0 + yc, rc * 0.95 - 0.012);
  g.add(V);
  /* curved brim */
  const bg = new THREE.SphereGeometry(1, 56, 22, 0, Math.PI, 0, Math.PI);
  bg.deleteAttribute("uv");
  const p = bg.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i) * 0.72,
      z = p.getZ(i) * 0.84;
    let y = p.getY(i) * 0.055 - 0.16 * x * x - 0.1 * (z / 0.84) * (z / 0.84);
    p.setXYZ(i, x, y, z);
  }
  bg.computeVertexNormals();
  bg.userData.own = 1;
  const brim = M(bg, red, 0, Y0 + 0.05, 0.3);
  brim.castShadow = false;
  g.add(brim);
  shell.castShadow = false;
  V.castShadow = false;
}

export function mkHat(t, c) {
  const g = new THREE.Group();
  if (t === "mcap") {
    mainCap(g);
    return g;
  }
  const m = P(c),
    A = (ge, x = 0, y = 0, z = 0, sc) => {
      const o = M(ge, m, x, y, z);
      if (sc) o.scale.set(...sc);
      g.add(o);
    };
  const Cy = (a, b, h, s = 32) => new THREE.CylinderGeometry(a, b, h, s),
    Sp = (r, half) => new THREE.SphereGeometry(r, 32, 16, 0, Math.PI * 2, 0, half ? Math.PI / 2 : Math.PI),
    Co = (r, h, s = 24) => new THREE.ConeGeometry(r, h, s);
  switch (t) {
    /* every hat bottom sits ~0.93 (like the red cap) so it wraps the head instead of floating above it */
    case "cap":
      A(fit(Sp(0.72, 1)), 0, 1.0, 0, [1, 0.58, 1]); A(fit(Cy(0.72, 0.72, 0.14, 40)), 0, 1.0);
      A(Cy(0.42, 0.42, 0.05, 40), 0, 0.97, 0.68, [1, 1, 0.72]); A(Sp(0.085), 0, 1.42); break;
    case "beanie": A(fit(Sp(0.7, 1)), 0, 1.0, 0, [1, 0.9, 1]); A(fit(Cy(0.71, 0.71, 0.2, 40)), 0, 1.0); A(Sp(0.16), 0, 1.63); break;
    case "top": A(fit(Cy(0.9, 0.9, 0.07, 48)), 0, 1.0); A(fit(Cy(0.64, 0.64, 0.95, 40)), 0, 1.46); break;
    case "crown":
      A(fit(Cy(0.68, 0.68, 0.28, 40)), 0, 1.12);
      for (let k = 0; k < 5; k++) { const a = (k * Math.PI * 2) / 5; A(Co(0.14, 0.4, 8), Math.sin(a) * 0.52, 1.46, Math.cos(a) * 0.5); }
      break;
    case "wizard": A(fit(Cy(0.95, 0.95, 0.05, 48)), 0, 1.0); A(fit(Co(0.7, 1.6, 40)), 0, 1.8); break;
    case "helmet": A(fit(Sp(0.72, 1)), 0, 0.93, 0, [1, 0.82, 1]); break;
    case "band": A(fit(Cy(0.72, 0.72, 0.16, 40)), 0, 1.0); break;
    case "cowboy": A(fit(Cy(1.05, 1.05, 0.06, 48)), 0, 1.0); A(fit(Cy(0.66, 0.72, 0.6, 40)), 0, 1.3); break;
    case "chef": A(fit(Cy(0.62, 0.7, 0.5, 40)), 0, 1.18); A(fit(Sp(0.7)), 0, 1.78, 0, [1, 0.8, 1]); break;
    case "party": A(fit(Co(0.64, 1.1, 40)), 0, 1.55); A(Sp(0.1), 0, 2.1); break;
    case "police": {
      /* band wraps the head (squircle, so the head corners no longer poke through), flared crown on top, brim at the forehead */
      A(fit(Cy(0.73, 0.73, 0.32, 44)), 0, 0.99);
      A(fit(Cy(0.86, 0.8, 0.16, 44)), 0, 1.23);
      A(Cy(0.45, 0.45, 0.05, 40), 0, 0.9, 0.68, [1, 1, 0.7]);
      const b = M(Sp(0.11), P("#ffd23f"), 0, 1.0, 0.69);
      b.scale.set(1, 1, 0.4);
      g.add(b);
      break;
    }
    case "ears": A(G(0.28, 1.1, 0.16, 0.08), -0.3, 1.75); A(G(0.28, 1.1, 0.16, 0.08), 0.3, 1.75); break;
  }
  return g;
}

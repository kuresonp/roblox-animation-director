// @ts-nocheck
export function heart(x, cx, cy, s) {
  x.beginPath();
  x.moveTo(cx, cy + s * 0.9);
  x.bezierCurveTo(cx - s * 1.6, cy - s * 0.2, cx - s * 0.8, cy - s * 1.3, cx, cy - s * 0.4);
  x.bezierCurveTo(cx + s * 0.8, cy - s * 1.3, cx + s * 1.6, cy - s * 0.2, cx, cy + s * 0.9);
  x.closePath();
}
export function star(x, cx, cy, R, r) {
  x.beginPath();
  for (let k = 0; k < 10; k++) {
    const a = -Math.PI / 2 + (k * Math.PI) / 5,
      q = k % 2 ? r : R;
    x.lineTo(cx + Math.cos(a) * q, cy + Math.sin(a) * q);
  }
  x.closePath();
}
const INK = "#17110d",
  PK = "#ff7a9a";
let GLOSS = 0;

function ring(x, ex, ey, r, pu, k) {
  x.fillStyle = INK;
  x.beginPath();
  x.arc(ex, ey, r + 5, 0, 7);
  x.fill();
  const g = x.createRadialGradient(ex - r * 0.3, ey - r * 0.4, 2, ex, ey, r);
  g.addColorStop(0, "#fff");
  g.addColorStop(1, "#c9ccd6");
  x.fillStyle = g;
  x.beginPath();
  x.arc(ex, ey, r, 0, 7);
  x.fill();
  if (pu) {
    const px = ex + k[0] * (r - pu - 3),
      py = ey + k[1] * (r - pu - 3);
    x.fillStyle = INK;
    x.beginPath();
    x.arc(px, py, pu, 0, 7);
    x.fill();
    x.fillStyle = "#fff";
    x.beginPath();
    x.arc(px - pu * 0.3, py - pu * 0.3, pu * 0.28, 0, 7);
    x.fill();
  }
}
function shine(x, ex, ey, ry) {
  x.fillStyle = "rgba(255,255,255,.6)";
  x.beginPath();
  x.ellipse(ex - 3.5, ey - ry * 0.5, 2.6, ry * 0.26, 0.2, 0, 7);
  x.fill();
}
function eye(x, t, ex, ey, sg, k, ec) {
  x.strokeStyle = INK;
  x.fillStyle = ec;
  x.lineWidth = 9;
  x.beginPath();
  switch (t) {
    case "o":
      x.ellipse(ex, ey, 10, 24, 0, 0, 7);
      x.fill();
      if (GLOSS) shine(x, ex, ey, 24);
      break;
    case "d":
      x.ellipse(ex, ey, 9, 13, 0, 0, 7);
      x.fill();
      if (GLOSS) shine(x, ex, ey, 13);
      break;
    case "v":
      x.ellipse(ex, ey, 10.5, 17, 0, 0, 7);
      x.fill();
      shine(x, ex, ey, 17);
      break;
    case "r": ring(x, ex, ey, 23, 0, k); break;
    case "p": ring(x, ex, ey, 23, 10, k); break;
    case "w": ring(x, ex, ey, 28, 5, k); break;
    case "g":
      x.lineWidth = 11;
      x.moveTo(ex - 20 * sg, ey - 19);
      x.lineTo(ex + 17 * sg, ey);
      x.lineTo(ex - 20 * sg, ey + 19);
      x.stroke();
      break;
    case "^":
      x.moveTo(ex - 18, ey + 8);
      x.quadraticCurveTo(ex, ey - 22, ex + 18, ey + 8);
      x.stroke();
      break;
    case "u":
      x.moveTo(ex - 18, ey - 4);
      x.quadraticCurveTo(ex, ey + 20, ex + 18, ey - 4);
      x.stroke();
      break;
    case "-":
      x.moveTo(ex - 17, ey + 2);
      x.lineTo(ex + 17, ey + 2);
      x.stroke();
      break;
    case "h":
      x.save();
      x.rect(ex - 30, ey - 1, 60, 40);
      x.clip();
      x.beginPath();
      x.ellipse(ex, ey, 13, 21, 0, 0, 7);
      x.fill();
      x.restore();
      x.lineWidth = 7;
      x.beginPath();
      x.moveTo(ex - 16, ey - 1);
      x.lineTo(ex + 16, ey - 1);
      x.stroke();
      break;
    case "H": x.fillStyle = "#ff3b6b"; x.lineWidth = 4; heart(x, ex, ey, 14); x.fill(); x.stroke(); break;
    case "S": x.fillStyle = "#ffc400"; x.lineWidth = 4; star(x, ex, ey, 27, 12); x.fill(); x.stroke(); break;
    case "@":
      x.lineWidth = 4;
      for (let a = 0; a < 17; a += 0.3) x.lineTo(ex + Math.cos(a) * a * 1.5, ey + Math.sin(a) * a * 1.5);
      x.stroke();
      break;
    case "e": case "l": case "m": almond(x, t, ex, ey, sg, k, ec); break;
    case "x":
      x.moveTo(ex - 14, ey - 14);
      x.lineTo(ex + 14, ey + 14);
      x.moveTo(ex + 14, ey - 14);
      x.lineTo(ex - 14, ey + 14);
      x.stroke();
  }
}
function almond(x, t, ex, ey, sg, k, ec) {
  const u = t === "e" ? -26 : t === "l" ? -6 : -18,
    d = t === "e" ? 20 : t === "l" ? 14 : 16,
    o = ex - sg * 30,
    i = ex + sg * 30,
    path = () => {
      x.beginPath();
      x.moveTo(o, ey + 2);
      x.quadraticCurveTo(ex, ey + u, i, ey + 2);
      x.quadraticCurveTo(ex, ey + d, o, ey + 2);
      x.closePath();
    };
  if (t === "m") {
    x.fillStyle = "rgba(235,140,155,.5)";
    x.beginPath();
    x.ellipse(ex, ey - 6, 34, 18, 0, 0, 7);
    x.fill();
  }
  path();
  x.fillStyle = "#fff";
  x.fill();
  x.save();
  x.clip();
  const px = ex + k[0] * 8,
    py = ey + 2 + k[1] * 4;
  x.fillStyle = t === "m" ? ec : INK;
  x.beginPath();
  x.arc(px, py, t === "e" ? 14 : t === "l" ? 11 : 13, 0, 7);
  x.fill();
  if (t === "m") {
    x.fillStyle = INK;
    x.beginPath();
    x.arc(px, py, 6, 0, 7);
    x.fill();
  }
  x.fillStyle = "#fff";
  x.beginPath();
  x.arc(px - 4, py - 4, 3.5, 0, 7);
  x.fill();
  x.restore();
  path();
  x.strokeStyle = INK;
  x.lineWidth = t === "m" ? 7 : 5;
  x.stroke();
  if (t === "m") {
    x.beginPath();
    x.moveTo(o, ey + 2);
    x.lineTo(o - sg * 14, ey - 6);
    x.stroke();
  } else {
    x.lineWidth = 3;
    x.beginPath();
    x.moveTo(o, ey - 8);
    x.quadraticCurveTo(ex, ey + u - 14, i, ey - 8);
    x.stroke();
  }
}
/* variable-width stroke along a quadratic curve */
function taper(x, a, c, b, w0, w1) {
  x.lineCap = "round";
  let px = a[0],
    py = a[1];
  for (let i = 1; i <= 22; i++) {
    const t = i / 22,
      m = 1 - t,
      qx = m * m * a[0] + 2 * m * t * c[0] + t * t * b[0],
      qy = m * m * a[1] + 2 * m * t * c[1] + t * t * b[1];
    x.lineWidth = w0 + (w1 - w0) * t;
    x.beginPath();
    x.moveTo(px, py);
    x.lineTo(qx, qy);
    x.stroke();
    px = qx;
    py = qy;
  }
}
function brow(x, t, ex, sg) {
  if (t === "n") return;
  const by = 64,
    o = ex - sg * 24,
    i = ex + sg * 24;
  x.strokeStyle = INK;
  x.lineWidth = t[0] === "z" ? 4 : 9;
  if (t === "ra") return taper(x, [ex - sg * 27, by + 16], [ex - sg * 2, by - 14], [ex + sg * 24, by + 20], 7, 2.5);
  if (t === "rk") return taper(x, [ex + sg * 25, by + 14], [ex, by + 8], [ex - sg * 27, by + 2], 2.5, 7);
  x.beginPath();
  if (t === "f") { x.moveTo(o, by); x.lineTo(i, by); }
  else if (t === "a") { x.moveTo(o, by - 8); x.lineTo(i, by + 9); }
  else if (t === "s") { x.moveTo(o, by + 8); x.lineTo(i, by - 9); }
  else if (t === "u") { x.moveTo(o, by + 4); x.quadraticCurveTo(ex, by - 16, i, by + 4); }
  else if (t === "m" || t === "mr") {
    const h = t === "mr" ? -14 : 0;
    x.lineWidth = 12;
    x.moveTo(o, by + 8 + h);
    x.quadraticCurveTo(ex + sg * 4, by - 16 + h, i, by + 2 + h);
  } else {
    const d = t === "za" ? 1 : -1;
    x.moveTo(o, by - 10 * d);
    x.lineTo(ex - sg * 4, by);
    x.lineTo(ex + sg, by - 4 * d);
    x.lineTo(i, by + 9 * d);
  }
  x.stroke();
}
function FS(x, pth, fill, inner) {
  pth();
  x.fillStyle = fill;
  x.fill();
  x.save();
  x.clip();
  inner && inner();
  x.restore();
  pth();
  x.stroke();
}
function mouth(x, m) {
  const [t, p = 0] = m, mx = 128, my = 172;
  x.lineWidth = 7;
  x.strokeStyle = INK;
  x.beginPath();
  if (t === "tilt") {
    x.save();
    x.translate(mx + 14, my - 3);
    x.rotate(-0.34);
    x.fillStyle = INK;
    x.beginPath();
    x.ellipse(0, 0, 20, 13, 0, 0, 7);
    x.fill();
    x.globalCompositeOperation = "destination-out";
    x.beginPath();
    x.ellipse(1.5, -0.5, 13.5, 6.5, 0.05, 0, 7);
    x.fill();
    x.restore();
  } else if (t === "c") { x.moveTo(mx - 30, my - p * 8); x.quadraticCurveTo(mx, my + p * 30, mx + 30, my - p * 8); x.stroke(); }
  else if (t === "sm") { x.moveTo(mx - 26, my + 4); x.quadraticCurveTo(mx + 6, my + 16, mx + 34, my - 10); x.stroke(); }
  else if (t === "cat") { x.moveTo(mx - 38, my - 2); x.quadraticCurveTo(mx - 19, my + 24, mx, my - 2); x.quadraticCurveTo(mx + 19, my + 24, mx + 38, my - 2); x.stroke(); }
  else if (t === "zig") { x.moveTo(mx - 36, my + 4); for (let i = 1; i <= 6; i++) x.lineTo(mx - 36 + i * 12, my + (i % 2 ? -6 : 6) + 4); x.stroke(); }
  else if (t === "grin")
    FS(x, () => { x.beginPath(); x.moveTo(mx - 42, my - 12); x.quadraticCurveTo(mx, my - 2, mx + 42, my - 12); x.quadraticCurveTo(mx + 34, my + 42, mx, my + 42); x.quadraticCurveTo(mx - 34, my + 42, mx - 42, my - 12); x.closePath(); }, "#4a1313", () => {
      if (p === 1) { x.fillStyle = "#fff"; x.fillRect(mx - 44, my - 16, 88, 17); }
      if (p === 2) { x.fillStyle = "#fff"; [-30, 30].forEach((dx) => { x.beginPath(); x.moveTo(mx + dx - 8, my - 16); x.lineTo(mx + dx + 8, my - 16); x.lineTo(mx + dx, my + 10); x.closePath(); x.fill(); }); }
      x.fillStyle = PK; x.beginPath(); x.ellipse(mx, my + 44, 24, 15, 0, 0, 7); x.fill();
    });
  else if (t === "tongue") {
    x.strokeStyle = "#c93a63"; x.lineWidth = 4;
    FS(x, () => { x.beginPath(); x.moveTo(mx - 40, my - 6); x.lineTo(mx + 34, my + 6); x.quadraticCurveTo(mx + 10, my + 30, mx - 20, my + 28); x.quadraticCurveTo(mx - 44, my + 20, mx - 40, my - 6); x.closePath(); }, PK, () => { x.fillStyle = "rgba(255,255,255,.35)"; x.beginPath(); x.ellipse(mx - 12, my + 4, 16, 5, 0.15, 0, 7); x.fill(); });
  } else if (t === "box")
    FS(x, () => { x.beginPath(); x.moveTo(mx - 28, my - 12); x.lineTo(mx + 28, my - 12); x.quadraticCurveTo(mx + 42, my - 12, mx + 42, my + 2); x.lineTo(mx + 46, my + 22); x.quadraticCurveTo(mx + 48, my + 36, mx + 34, my + 36); x.lineTo(mx - 34, my + 36); x.quadraticCurveTo(mx - 48, my + 36, mx - 46, my + 22); x.lineTo(mx - 42, my + 2); x.quadraticCurveTo(mx - 42, my - 12, mx - 28, my - 12); x.closePath(); }, "#c94e5c", () => { x.fillStyle = "#e87d89"; x.fillRect(mx - 50, my - 16, 100, 26); });
  else if (t === "wavy")
    FS(x, () => { x.beginPath(); x.moveTo(mx - 50, my + 4); x.bezierCurveTo(mx - 30, my - 14, mx - 10, my + 10, mx + 12, my - 2); x.bezierCurveTo(mx + 30, my - 12, mx + 44, my - 8, mx + 50, my - 6); x.bezierCurveTo(mx + 52, my + 24, mx + 20, my + 34, mx, my + 30); x.bezierCurveTo(mx - 30, my + 34, mx - 54, my + 26, mx - 50, my + 4); x.closePath(); }, "#8c141a", () => { x.fillStyle = "rgba(255,255,255,.12)"; x.fillRect(mx - 60, my - 16, 120, 16); });
  else if (t === "o" || t === "talk") {
    const rx = t === "talk" ? 20 : 10 + p * 14, ry = t === "talk" ? 5 + p * 55 : 12 + p * 20;
    FS(x, () => { x.beginPath(); x.ellipse(mx, my + 4 + ry * 0.6, rx, ry, 0, 0, 7); }, "#4a1313", () => { x.fillStyle = PK; x.beginPath(); x.ellipse(mx, my + 4 + ry * 1.4, rx * 0.8, ry * 0.5, 0, 0, 7); x.fill(); });
  } else if (t === "big")
    FS(x, () => { x.beginPath(); x.moveTo(mx - 64, my - 24); x.quadraticCurveTo(mx, my - 4, mx + 64, my - 24); x.quadraticCurveTo(mx + 52, my + 52, mx, my + 54); x.quadraticCurveTo(mx - 52, my + 52, mx - 64, my - 24); x.closePath(); }, "#fff", () => { x.lineWidth = 4; x.beginPath(); x.moveTo(mx - 64, my + 6); x.quadraticCurveTo(mx, my + 22, mx + 64, my + 6); [-2, -1, 0, 1, 2].forEach((i) => { x.moveTo(mx + i * 20, my - 10); x.lineTo(mx + i * 20, my + 10); }); x.stroke(); });
  else if (t === "lips") {
    x.strokeStyle = "#7a0a22"; x.lineWidth = 4;
    FS(x, () => { x.beginPath(); x.moveTo(mx - 50, my + 4); x.quadraticCurveTo(mx - 24, my - 22, mx, my - 10); x.quadraticCurveTo(mx + 30, my - 26, mx + 52, my - 8); x.quadraticCurveTo(mx + 34, my + 34, mx - 4, my + 34); x.quadraticCurveTo(mx - 40, my + 30, mx - 50, my + 4); x.closePath(); }, "#d11a40", () => { x.fillStyle = "#fff"; x.beginPath(); x.moveTo(mx - 38, my + 6); x.quadraticCurveTo(mx, my - 6, mx + 40, my - 2); x.quadraticCurveTo(mx + 28, my + 22, mx - 4, my + 22); x.quadraticCurveTo(mx - 30, my + 20, mx - 38, my + 6); x.fill(); x.fillStyle = "rgba(255,255,255,.55)"; x.beginPath(); x.ellipse(mx - 10, my + 28, 9, 3, 0, 0, 7); x.fill(); });
  } else if (t === "buck") {
    x.moveTo(mx - 30, my - 6); x.quadraticCurveTo(mx, my + 26, mx + 30, my - 6); x.stroke();
    x.fillStyle = "#fff"; x.beginPath(); x.rect(mx - 14, my + 9, 28, 20); x.fill(); x.lineWidth = 5; x.stroke();
    x.beginPath(); x.moveTo(mx, my + 9); x.lineTo(mx, my + 29); x.stroke();
  } else if (t === "sob")
    FS(x, () => { x.beginPath(); x.moveTo(mx - 36, my + 22); x.quadraticCurveTo(mx, my - 24, mx + 36, my + 22); x.quadraticCurveTo(mx, my + 8, mx - 36, my + 22); x.closePath(); }, "#4a1313");
  else if (t === "teeth") {
    x.fillStyle = "#fff"; x.rect(mx - 36, my - 4, 72, 28); x.fill(); x.stroke(); x.lineWidth = 4; x.beginPath();
    x.moveTo(mx - 12, my - 4); x.lineTo(mx - 12, my + 24); x.moveTo(mx + 12, my - 4); x.lineTo(mx + 12, my + 24); x.moveTo(mx - 36, my + 10); x.lineTo(mx + 36, my + 10); x.stroke();
  }
}

/* D = {gl: glasses, lash, fr: freckles, dy: eye vertical offset, gloss} */
export function drawFace(x, E, blink, mo, D = {}) {
  const [, ey, bw, mt, X = {}] = E,
    k = X.k || [0, 0],
    dy = D.dy || 0;
  GLOSS = D.gloss ? 1 : 0;
  x.globalCompositeOperation = "source-over";
  x.clearRect(0, 0, 256, 256);
  x.lineCap = x.lineJoin = "round";
  x.save();
  x.translate(0, dy);
  if (!X.sh)
    [[88, 1], [168, -1]].forEach(([ex, sg], i) => {
      let t = ey[i];
      if (blink && "odrpwhelmv".includes(t)) t = "-";
      eye(x, t, ex, 112, sg, k, X.ec || INK);
      brow(x, bw[i], ex, sg);
      if (D.lash && t !== 0 && t !== "x") {
        x.strokeStyle = INK; x.lineWidth = 5;
        [[10, -14, 27, -25], [13, -6, 32, -10], [11, -20, 22, -33]].forEach(([a, b, c, d]) => { x.beginPath(); x.moveTo(ex - sg * a, 112 + b); x.lineTo(ex - sg * c, 112 + d); x.stroke(); });
      }
    });
  x.restore();
  mouth(x, mo || mt);
  if (D.fr) {
    x.fillStyle = "rgba(150,82,40,.55)";
    [[40, 142], [56, 150], [70, 140], [186, 140], [200, 150], [216, 142], [52, 134], [204, 134]].forEach(([fx, fy]) => { x.beginPath(); x.arc(fx, fy, 3, 0, 7); x.fill(); });
  }
  if (X.bl) { x.fillStyle = "rgba(255,90,110,.5)"; [48, 208].forEach((bx) => { x.beginPath(); x.ellipse(bx, 148, 18, 10, 0, 0, 7); x.fill(); }); }
  x.save();
  x.translate(0, dy);
  if (X.tr) { x.fillStyle = "#5bc8ff"; [88, 168].forEach((bx) => { x.beginPath(); x.ellipse(bx, 146, 7, 13, 0, 0, 7); x.fill(); }); }
  x.restore();
  if (X.jt) { x.fillStyle = "#5bc8ff"; [[34, 96, -0.6], [222, 96, 0.6]].forEach(([bx, by, r]) => { x.beginPath(); x.ellipse(bx, by, 6, 12, r, 0, 7); x.fill(); }); }
  if (X.sw) { x.fillStyle = "#7fd4ff"; x.beginPath(); x.moveTo(214, 40); x.quadraticCurveTo(230, 64, 214, 74); x.quadraticCurveTo(198, 64, 214, 40); x.fill(); }
  if (X.zz) { x.fillStyle = INK; x.font = "bold 34px sans-serif"; x.fillText("Z", 190, 60); x.font = "bold 22px sans-serif"; x.fillText("z", 224, 34); }
  if (X.sl) { x.strokeStyle = "#4a78c9"; x.lineWidth = 6; [[40, 64], [54, 80], [68, 56], [82, 72]].forEach(([lx, ly]) => { x.beginPath(); x.moveTo(lx, 10); x.lineTo(lx, ly); x.stroke(); }); }
  if (X.vn) { x.strokeStyle = "#e8261c"; x.lineWidth = 6; [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([a, b]) => { x.beginPath(); x.moveTo(212 + a * 4, 46 + b * 16); x.quadraticCurveTo(212 + a * 4, 46 + b * 4, 212 + a * 16, 46 + b * 4); x.stroke(); }); }
  x.save();
  x.translate(0, dy);
  if (X.sh) {
    x.fillStyle = X.sh === 1 ? "#111" : X.sh;
    x.fillRect(46, 92, 76, 42); x.fillRect(134, 92, 76, 42); x.fillRect(120, 98, 16, 8);
    x.strokeStyle = "rgba(255,255,255,.5)"; x.lineWidth = 4; x.beginPath();
    x.moveTo(58, 102); x.lineTo(80, 102); x.moveTo(146, 102); x.lineTo(168, 102); x.stroke();
  }
  if (X.ep) { x.fillStyle = x.strokeStyle = INK; x.lineWidth = 6; x.beginPath(); x.moveTo(56, 104); x.lineTo(2, 88); x.moveTo(118, 90); x.lineTo(254, 56); x.stroke(); x.beginPath(); x.ellipse(88, 112, 33, 28, -0.3, 0, 7); x.fill(); }
  if (X.mn) { x.strokeStyle = "#d8a31a"; x.lineWidth = 5; x.beginPath(); x.arc(168, 112, 36, 0, 7); x.stroke(); x.beginPath(); x.moveTo(198, 132); x.quadraticCurveTo(214, 180, 202, 236); x.stroke(); }
  if (D.gl || X.gs) { x.strokeStyle = "#222"; x.lineWidth = 5;[88, 168].forEach((bx) => { x.beginPath(); x.arc(bx, 112, 35, 0, 7); x.stroke(); }); x.beginPath(); x.moveTo(123, 110); x.lineTo(133, 110); x.stroke(); }
  x.restore();
  if (X.ms) { x.fillStyle = INK; x.beginPath(); x.moveTo(128, 150); x.bezierCurveTo(112, 138, 84, 142, 70, 162); x.bezierCurveTo(88, 154, 108, 160, 128, 162); x.bezierCurveTo(148, 160, 168, 154, 186, 162); x.bezierCurveTo(172, 142, 144, 138, 128, 150); x.fill(); }
  if (X.hn) { x.fillStyle = "#d1202a"; x.strokeStyle = INK; x.lineWidth = 4;[[34, 1], [222, -1]].forEach(([hx, s]) => { x.beginPath(); x.moveTo(hx - s * 6, 52); x.lineTo(hx - s * 2, 6); x.lineTo(hx + s * 30, 36); x.closePath(); x.fill(); x.stroke(); }); }
  if (X.ha) { x.strokeStyle = "#ffd23f"; x.lineWidth = 8; x.beginPath(); x.ellipse(128, 16, 46, 11, 0, 0, 7); x.stroke(); }
}

// @ts-nocheck
import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { clamp, PI, V, G, limbGeo, bend, HD, superGeo, superPt, lockGeo } from "./geo";
import { buildHair, HAIR } from "./hair";
import { EM, drawFace, star, heart } from "./face";
import { OU, PO, CH } from "./data";
import "./rig.css";

const { A, B, C, E1, E2, Y0 } = HD;
const sn = Math.sin;
const P = (c, o = {}) => new THREE.MeshPhysicalMaterial({ color: c, roughness: 0.34, clearcoat: 0.6, clearcoatRoughness: 0.2, ...o });
const M = (g, m, x = 0, y = 0, z = 0) => { const o = new THREE.Mesh(g, m); o.position.set(x, y, z); o.castShadow = o.receiveShadow = true; return o; };

/* ---------- pattern textures for shirts ---------- */
function patTex(p, c) {
  const cv = document.createElement("canvas"); cv.width = cv.height = 128;
  const x = cv.getContext("2d"); x.fillStyle = x.strokeStyle = c; x.lineWidth = 8; x.lineCap = x.lineJoin = "round";
  switch (p) {
    case "band": x.fillRect(0, 50, 128, 28); break;
    case "stripes": for (let y = 14; y < 128; y += 32) x.fillRect(0, y, 128, 14); break;
    case "star": star(x, 64, 66, 50, 22); x.fill(); break;
    case "heart": heart(x, 64, 62, 38); x.fill(); break;
    case "logo": x.fillRect(30, 36, 68, 56); x.fillStyle = "#fff"; x.beginPath(); x.moveTo(56, 52); x.lineTo(82, 64); x.lineTo(56, 76); x.fill(); break;
    case "pocket": x.lineWidth = 6; x.strokeRect(70, 30, 40, 38); break;
    case "badge": star(x, 86, 44, 28, 12); x.fill(); x.strokeStyle = "#9a6b00"; x.lineWidth = 4; x.stroke(); break;
    case "buttons": [26, 62, 98].forEach((y) => { x.beginPath(); x.arc(64, y, 8, 0, 7); x.fill(); }); break;
    case "bolt": x.beginPath(); x.moveTo(78, 8); x.lineTo(40, 68); x.lineTo(62, 68); x.lineTo(50, 120); x.lineTo(92, 54); x.lineTo(68, 54); x.closePath(); x.fill(); break;
    case "tie": x.beginPath(); x.moveTo(54, 4); x.lineTo(74, 4); x.lineTo(70, 32); x.lineTo(84, 98); x.lineTo(64, 122); x.lineTo(44, 98); x.lineTo(58, 32); x.closePath(); x.fill(); break;
    case "smile": x.beginPath(); x.arc(64, 64, 42, 0, 7); x.fill(); x.fillStyle = x.strokeStyle = "#222"; x.fillRect(48, 46, 9, 16); x.fillRect(71, 46, 9, 16); x.lineWidth = 6; x.beginPath(); x.arc(64, 66, 22, 0.25, 2.9); x.stroke(); break;
  }
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t;
}

/* ---------- THE RED CAP (main character reference) ---------- */
function mkCap(col, letter) {
  const g = new THREE.Group(), m = P(col, { roughness: 0.28, clearcoat: 0.9, clearcoatRoughness: 0.12, side: THREE.DoubleSide });
  const rimY = Y0 + 0.6, dh = { A: A * 1.07, B: 0.72, C: C * 1.07, E1: 0.6, E2: 0.62, Y0: rimY };
  g.add(M(superGeo({ a: dh.A, b: dh.B, c: dh.C, e1: dh.E1, e2: dh.E2, cy: rimY, vStart: PI / 2, vEnd: -0.06, uSeg: 72, vSeg: 30 }), m));
  // panel seams
  const sm = P(new THREE.Color(col).multiplyScalar(0.72), { roughness: 0.3, clearcoat: 0.5 });
  for (let i = 0; i < 6; i++) {
    const u = (i / 6) * PI * 2 + PI / 6, pts = [];
    for (let j = 0; j <= 8; j++) pts.push(superPt(u, PI / 2 - 0.02 - (j / 8) * (PI / 2 - 0.02), 1.006, dh));
    g.add(M(lockGeo(pts, { w: 0.017, th: 0.017, w1: 1, rad: 6, ref: V(0, 1, 0) }), sm));
  }
  // visor
  const brim = M(superGeo({
    a: 0.94, b: 0.05, c: 0.56, e1: 0.5, e2: 0.88, cy: 0, uSeg: 56, vSeg: 20,
    post: (x, y, z) => { const f = Math.max(0, (z + 0.18) / 0.82); return [x, y - 0.11 * f * f - 0.04 * (x * x), z]; },
  }), m, 0, rimY - 0.05, 0.42);
  g.add(brim);
  // top button
  const btn = M(new THREE.SphereGeometry(1, 20, 14), P("#f3e4a0"), 0, rimY + dh.B + 0.005, 0);
  btn.scale.set(0.15, 0.085, 0.15); g.add(btn);
  // letter on the front panel
  if (letter === "V") {
    const s = new THREE.Shape();
    [[-0.4, 0.5], [-0.17, 0.5], [0, 0.06], [0.17, 0.5], [0.4, 0.5], [0.1, -0.46], [-0.1, -0.46]].forEach(([x, y], i) => (i ? s.lineTo(x, y) : s.moveTo(x, y)));
    const eg = new THREE.ExtrudeGeometry(s, { depth: 0.035, bevelEnabled: true, bevelThickness: 0.014, bevelSize: 0.014, bevelSegments: 3 });
    eg.userData.own = 1;
    const v = M(eg, P("#f6f1e4", { roughness: 0.3 }));
    const vv = 0.4, p = superPt(0, vv, 1.0, dh);
    const ny = Math.pow(Math.sin(vv), 2 - dh.E1) / dh.B, nz = Math.pow(Math.cos(vv), 2 - dh.E1) / dh.C, n = V(0, ny, nz).normalize();
    v.position.copy(p).addScaledVector(n, -0.005); v.quaternion.setFromUnitVectors(V(0, 0, 1), n); v.scale.setScalar(0.44);
    g.add(v);
  }
  return g;
}
// other hats (original designs, re-fitted to the taller head)
function mkHat(t, c, letter) {
  if (t === "cap") return mkCap(c, letter);
  const g = new THREE.Group(), m = P(c), W = new THREE.Group();
  const Ad = (ge, x = 0, y = 0, z = 0, sc) => { const o = M(ge, m, x, y, z); if (sc) o.scale.set(...sc); W.add(o); };
  const Cy = (a, b, h, s = 32) => new THREE.CylinderGeometry(a, b, h, s), Sp = (r, half) => new THREE.SphereGeometry(r, 32, 16, 0, PI * 2, 0, half ? PI / 2 : PI), Co = (r, h, s = 24) => new THREE.ConeGeometry(r, h, s);
  switch (t) {
    case "beanie": Ad(Sp(0.7, 1), 0, 1, 0, [1, 0.85, 1]); Ad(Sp(0.16), 0, 1.6); break;
    case "top": Ad(Cy(0.9, 0.9, 0.08), 0, 1.15); Ad(Cy(0.52, 0.52, 0.95), 0, 1.6); break;
    case "crown": Ad(Cy(0.62, 0.62, 0.28), 0, 1.28); for (let k = 0; k < 5; k++) { const a = (k * PI * 2) / 5; Ad(Co(0.14, 0.4, 8), Math.sin(a) * 0.5, 1.62, Math.cos(a) * 0.5); } break;
    case "wizard": Ad(Cy(0.95, 0.95, 0.05), 0, 1.2); Ad(Co(0.65, 1.6, 32), 0, 2); break;
    case "band": Ad(Cy(0.68, 0.68, 0.16), 0, 1); break;
    case "cowboy": Ad(Cy(1.05, 1.05, 0.06), 0, 1.2); Ad(Cy(0.55, 0.6, 0.55), 0, 1.5); break;
    case "chef": Ad(Cy(0.55, 0.5, 0.5), 0, 1.4); Ad(Sp(0.62), 0, 1.95, 0, [1, 0.8, 1]); break;
    case "party": Ad(Co(0.42, 1.05), 0, 1.7); Ad(Sp(0.1), 0, 2.25); break;
    case "police": Ad(Cy(0.72, 0.72, 0.22), 0, 1.3); Ad(Cy(0.82, 0.78, 0.12), 0, 1.46); Ad(Cy(0.45, 0.45, 0.05, 40), 0, 1.22, 0.66, [1, 1, 0.7]); { const b = M(Sp(0.11), P("#ffd23f"), 0, 1.32, 0.73); b.scale.set(1, 1, 0.4); W.add(b); } break;
    case "ears": Ad(G(0.28, 1.1, 0.16, 0.08), -0.3, 1.75); Ad(G(0.28, 1.1, 0.16, 0.08), 0.3, 1.75); break;
  }
  W.scale.set(1.3, 1.16, 1.16); W.position.y = 0.16; g.add(W);
  return g;
}

/* ---------- scene ---------- */
export function startRig(host) {
  const $ = (s) => host.querySelector(s);
  host.classList.add("rig");
  const scene = new THREE.Scene(), cam = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
  const R = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  R.shadowMap.enabled = true; R.shadowMap.type = THREE.PCFSoftShadowMap;
  host.prepend(R.domElement);
  scene.environment = new THREE.PMREMGenerator(R).fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environmentIntensity = 0.55;
  scene.add(new THREE.HemisphereLight(0xffffff, 0x6a5acd, 0.5));
  const dl = new THREE.DirectionalLight(0xffffff, 1.5); dl.position.set(5, 12, 9); dl.castShadow = true; dl.shadow.mapSize.set(2048, 2048);
  Object.assign(dl.shadow.camera, { left: -9, right: 9, top: 12, bottom: -4, near: 1, far: 45 }); dl.shadow.bias = -0.0004; dl.shadow.camera.updateProjectionMatrix(); scene.add(dl);
  const rim1 = new THREE.DirectionalLight(0x9a5cff, 2.2); rim1.position.set(-7, 6, -8); scene.add(rim1);
  const rim2 = new THREE.DirectionalLight(0x4a8cff, 1.4); rim2.position.set(8, 4, -8); scene.add(rim2);
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.ShadowMaterial({ opacity: 0.38 })); fl.rotation.x = -PI / 2; fl.receiveShadow = true; scene.add(fl);
  const disc = new THREE.Mesh(new THREE.CircleGeometry(3.6, 64), new THREE.MeshBasicMaterial({ color: 0x9b5cff, transparent: true, opacity: 0.22 })); disc.rotation.x = -PI / 2; disc.position.y = 0.01; scene.add(disc);

  const S = { c: 0, e: 0, o: 0, p: 0, h: 0, bd: 0, hc: "#000000", sk: "#f6d321", talk: 0, spin: 0 };
  const cur = new Array(16).fill(0);
  let ch = null;
  const emIdx = Object.fromEntries(EM.map((e, i) => [e[0], i])), ouIdx = Object.fromEntries(OU.map((o, i) => [o[0], i])), poIdx = Object.fromEntries(PO.map((p, i) => [p[0], i]));
  const hIdx = Object.fromEntries(HAIR.map((h, i) => [h.k, i]));
  const BEARDS = [["", "Clean-shaven"], ["stubble", "Stubble"], ["mustache", "Mustache"], ["goatee", "Goatee"], ["vandyke", "Van Dyke"], ["chin", "Soul Patch"], ["full", "Full Beard"]];
  const bdIdx = Object.fromEntries(BEARDS.map((b, i) => [b[0], i]));

  function dispose(root) {
    root.traverse((o) => {
      if (o.material) [].concat(o.material).forEach((m) => { if (m.map && !m.map.userData.keep) m.map.dispose(); m.dispose(); });
      if (o.geometry && o.geometry.userData.own) o.geometry.dispose();
    });
  }

  function build() {
    if (ch) { scene.remove(ch.root); dispose(ch.root); }
    const cd = CH[S.c], opt = cd[10];
    const [, shC, paC, soC, pat, patC, hat, hatC, long, shorts, ex, exC, hatL] = OU[S.o];
    const sx = opt.sx || 1, sy = opt.sy || 1, hz = opt.hz || 1;
    const root = new THREE.Group(), body = new THREE.Group(); root.add(body); root.scale.set(sx * sy, sy, sx * sy);
    const skin = P(S.sk), shirt = P(shC, { roughness: 0.45 }), pants = P(paC, { roughness: 0.5 }), shoe = P(soC);
    body.add(M(G(2, 2, 1, 0.2), shirt, 0, 3, 0));
    if (pat) { const m = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 1.5), new THREE.MeshBasicMaterial({ map: patTex(pat, patC), transparent: true })); m.position.set(0, 3, 0.505); body.add(m); }
    const arm = (x) => { const g = new THREE.Group(), geo = limbGeo(0.98, 1.96, 0.98, 0.2); g.position.set(x, 3.85, 0); g.add(M(geo, [shirt, long ? shirt : skin], 0, -0.93, 0)); g.geo = geo; body.add(g); return g; };
    const leg = (x) => { const g = new THREE.Group(), geo = limbGeo(0.97, 1.8, 0.98, 0.16), k = new THREE.Group(), f = new THREE.Group(); g.position.set(x, 2, 0); k.position.y = -0.9; k.add(M(geo, [pants, shorts ? skin : pants])); f.add(M(G(1, 0.3, 1.08, 0.12), shoe, 0, -0.94, 0)); k.add(f); g.add(k); body.add(g); g.geo = geo; g.foot = f; return g; };
    const la = arm(1.5), ra = arm(-1.5), ll = leg(0.5), rl = leg(-0.5);
    if (ex === "cape") body.add(M(G(1.9, 2.6, 0.12, 0.05), P(exC), 0, 2.8, -0.58));
    if (ex === "pack") body.add(M(G(1.3, 1.5, 0.5, 0.15), P(exC), 0, 3.2, -0.75));
    if (ex === "scarf") body.add(M(G(2.1, 0.4, 1.1, 0.15), P(exC), 0, 3.95, 0));

    // head
    const head = new THREE.Group(); head.position.set(0, 4, 0); head.scale.setScalar(hz); body.add(head);
    head.add(M(superGeo({ a: A, b: B, c: C, e1: E1, e2: E2, cy: Y0, uSeg: 72, vSeg: 44 }), skin));
    // face decal wrapped on the head surface
    const cv = document.createElement("canvas"); cv.width = cv.height = 256;
    const tex = new THREE.CanvasTexture(cv); tex.anisotropy = 8; tex.colorSpace = THREE.SRGBColorSpace;
    const FW = 1.36, FC = Y0 - 0.02;
    const fm = new THREE.Mesh(
      superGeo({ a: A, b: B, c: C, e1: E1, e2: E2, cy: Y0, uMin: -1.05, uMax: 1.05, uSeg: 44, vSeg: 44, vStart: 1.0, vEnd: -0.9, kf: () => 1.004, uvf: (x, y) => [x / FW + 0.5, (y - FC) / FW + 0.5] }),
      new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 }));
    fm.renderOrder = 5; head.add(fm);
    // hair (smooth sculpted hair, no blocks)
    const hs = HAIR[S.h];
    if (hs && (hs.f || BEARDS[S.bd][0])) head.add(buildHair(hs.k, S.hc, BEARDS[S.bd][0], S.c + 1));
    if (hat) head.add(mkHat(hat, hatC, hatL));

    scene.add(root);
    ch = { root, body, head, la, ra, ll, rl, ctx: cv.getContext("2d"), tex, fk: "", gl: !!opt.gl, fem: cd[1] === "F", fr: !!opt.fr };
  }
  function face(t) {
    const E = EM[S.e], bl = t % 3.6 > 3.48 && E[1][0] !== "u";
    let mo = null, q = 0;
    if (S.talk) { q = Math.round((0.12 + 0.35 * Math.abs(sn(t * 9))) * 6) / 6; mo = ["talk", q]; }
    const k = S.e + "|" + (bl ? 1 : 0) + "|" + q;
    if (k === ch.fk) return;
    ch.fk = k; drawFace(ch.ctx, E, bl, mo, { gl: ch.gl, fem: ch.fem, fr: ch.fr }); ch.tex.needsUpdate = true;
  }

  /* ---------- UI ---------- */
  host.insertAdjacentHTML("beforeend", `<div id="hint"></div><button id="uitog" aria-label="Toggle panel">☰</button><div id="ui"></div>`);
  const ui = $("#ui"), hint = $("#hint"), setters = {}, sels = {};
  const fcs = document.createElement("div"); fcs.id = "faces"; ui.appendChild(fcs);
  {
    const tc = document.createElement("canvas"); tc.width = tc.height = 256; const tx = tc.getContext("2d");
    EM.forEach((E, i) => {
      const b = document.createElement("button"), c = document.createElement("canvas"); c.width = c.height = 72;
      b.setAttribute("aria-label", E[0]); b.title = E[0];
      drawFace(tx, E, false, null, {}); c.getContext("2d").drawImage(tc, 0, 0, 72, 72); b.appendChild(c);
      b.onclick = () => setters.e(i); fcs.appendChild(b);
    });
  }
  const mark = () => {
    [...fcs.children].forEach((b, j) => b.classList.toggle("on", j === S.e));
    const b = fcs.children[S.e]; fcs.scrollTo({ left: b.offsetLeft - fcs.offsetLeft - fcs.clientWidth / 2 + b.offsetWidth / 2, behavior: "smooth" });
  };
  const showInfo = () => { const c = CH[S.c]; hint.innerHTML = `<b>${c[0]}</b> <i>${c[1] === "M" ? "♂" : "♀"}</i><span>${c[2]}</span>`; };
  let pending = 0;
  const rebuild = () => { if (pending) return; pending = requestAnimationFrame(() => { pending = 0; build(); }); };

  function applyChar(i) {
    S.c = (i + CH.length) % CH.length;
    const c = CH[S.c];
    S.sk = c[3]; S.hc = c[4]; S.h = hIdx[c[5]] ?? 0; S.bd = bdIdx[c[9]] ?? 0; S.o = ouIdx[c[7]] ?? 0; S.p = poIdx[c[8]] ?? 0; S.e = emIdx[c[6]] ?? 0;
    syncUI(); build(); mark(); showInfo();
  }
  function syncUI() {
    sels.c.value = S.c; sels.e.value = S.e; sels.o.value = S.o; sels.p.value = S.p; sels.h.value = S.h; sels.bd.value = S.bd;
    $("#hc").value = S.hc; $("#sk").value = S.sk;
  }
  const cell = (lab, k, optsHtml, count, extraCls = "") => {
    const d = document.createElement("div"); d.className = extraCls;
    d.innerHTML = `<label>${lab} <span>${count}</span></label><div class="r"><button aria-label="Previous ${lab}">‹</button><select aria-label="${lab}">${optsHtml}</select><button aria-label="Next ${lab}">›</button></div>`;
    const [bp, bn] = d.querySelectorAll("button"), sl = d.querySelector("select"); sels[k] = sl;
    return { d, bp, bn, sl };
  };
  const wire = (k, c, count, set) => {
    c.sl.onchange = () => set(+c.sl.value); c.bp.onclick = () => set(+c.sl.value - 1); c.bn.onclick = () => set(+c.sl.value + 1);
    setters[k] = set;
  };
  const opt = (arr) => arr.map((a, i) => `<option value="${i}">${a}</option>`).join("");
  const grp = (name, from, to) => `<optgroup label="${name}">${CH.slice(from, to).map((c, j) => `<option value="${from + j}">${c[0]}</option>`).join("")}</optgroup>`;
  const row = document.createElement("div"); row.id = "grid"; ui.appendChild(row);
  {
    const c = cell("Character", "c", grp("Main", 0, 1) + grp("Males", 1, 26) + grp("Females", 26, CH.length), CH.length, "wide");
    wire("c", c, CH.length, (i) => applyChar(i)); row.appendChild(c.d);
    const e = cell("Emotion", "e", opt(EM.map((x) => x[0])), EM.length); wire("e", e, 0, (i) => { S.e = (i + EM.length) % EM.length; sels.e.value = S.e; mark(); }); row.appendChild(e.d);
    const o = cell("Outfit", "o", opt(OU.map((x) => x[0])), OU.length); wire("o", o, 0, (i) => { S.o = (i + OU.length) % OU.length; sels.o.value = S.o; build(); }); row.appendChild(o.d);
    const p = cell("Pose", "p", opt(PO.map((x) => x[0])), PO.length); wire("p", p, 0, (i) => { S.p = (i + PO.length) % PO.length; sels.p.value = S.p; }); row.appendChild(p.d);
    const h = cell("Hair style", "h", opt(HAIR.map((x) => x.n)), HAIR.length); wire("h", h, 0, (i) => { S.h = (i + HAIR.length) % HAIR.length; sels.h.value = S.h; build(); }); row.appendChild(h.d);
    const bd = cell("Facial hair", "bd", opt(BEARDS.map((x) => x[1])), BEARDS.length); wire("bd", bd, 0, (i) => { S.bd = (i + BEARDS.length) % BEARDS.length; sels.bd.value = S.bd; build(); }); row.appendChild(bd.d);
    const col = document.createElement("div"); col.className = "wide colors";
    col.innerHTML = `<label>Hair color <input id="hc" type="color" aria-label="Hair color"></label><label>Skin tone <input id="sk" type="color" aria-label="Skin tone"></label>`;
    row.appendChild(col);
  }
  $("#hc").oninput = (e) => { S.hc = e.target.value; rebuild(); };
  $("#sk").oninput = (e) => { S.sk = e.target.value; rebuild(); };
  const bar = document.createElement("div"); bar.id = "bar";
  bar.innerHTML = `<button id="rnd">Randomize</button><button id="tk">Talk</button><button id="sp">Spin</button><button id="cu">Close-up</button>`; ui.appendChild(bar);
  $("#rnd").onclick = () => {
    applyChar((Math.random() * CH.length) | 0); setters.e((Math.random() * EM.length) | 0); setters.p((Math.random() * PO.length) | 0);
    if (Math.random() < 0.5) setters.o((Math.random() * OU.length) | 0);
  };
  [["#tk", "talk"], ["#sp", "spin"]].forEach(([id, key]) => { const b = $(id); b.onclick = () => { S[key] ^= 1; b.classList.toggle("on", !!S[key]); }; });
  let tDist = 22, tTy = 1.1, dist = tDist, ty = tTy;
  $("#cu").onclick = (e) => { const on = e.currentTarget.classList.toggle("on"); tDist = on ? 8 : 22; tTy = on ? 4.9 : 1.1; };
  $("#uitog").onclick = () => ui.classList.toggle("hide");
  window.rig = { state: S, setCharacter: (i) => setters.c(i), setEmotion: (i) => setters.e(i), setOutfit: (i) => setters.o(i), setPose: (i) => setters.p(i), setHair: (i) => setters.h(i), characters: CH.map((c) => c[0]) };

  /* ---------- camera + loop ---------- */
  let th = 0.3, ph = 0.1; const pts = new Map(); let pd = 0; const cvs = R.domElement;
  cvs.onpointerdown = (e) => { cvs.setPointerCapture(e.pointerId); pts.set(e.pointerId, [e.clientX, e.clientY]); };
  cvs.onpointermove = (e) => {
    const o = pts.get(e.pointerId); if (!o) return;
    if (pts.size === 1) { th -= (e.clientX - o[0]) * 0.01; ph = clamp(ph + (e.clientY - o[1]) * 0.006, -0.1, 1.2); }
    pts.set(e.pointerId, [e.clientX, e.clientY]);
    if (pts.size === 2) { const [a, b] = [...pts.values()], d = Math.hypot(a[0] - b[0], a[1] - b[1]); if (pd) tDist = clamp(tDist * pd / d, 4.5, 34); pd = d; }
  };
  cvs.onpointerup = cvs.onpointercancel = (e) => { pts.delete(e.pointerId); pd = 0; };
  cvs.onwheel = (e) => { tDist = clamp(tDist * (1 + e.deltaY * 0.001), 4.5, 34); };
  const resize = () => { R.setPixelRatio(Math.min(devicePixelRatio, 2)); R.setSize(host.clientWidth, host.clientHeight); cam.aspect = host.clientWidth / host.clientHeight; cam.updateProjectionMatrix(); };
  addEventListener("resize", resize); resize();
  applyChar(0);
  let last = 0, raf = 0, stop = false;
  function loop(ms) {
    if (stop) return;
    raf = requestAnimationFrame(loop);
    const t = ms / 1000, dt = Math.min(0.05, t - last); last = t;
    const tg = PO[S.p][1](t), k = Math.min(1, dt * 9);
    for (let i = 0; i < 16; i++) cur[i] += ((tg[i] || 0) - cur[i]) * k;
    const c = ch;
    c.la.rotation.set(cur[0], 0, cur[1]); c.ra.rotation.set(cur[2], 0, cur[3]); c.ll.rotation.x = cur[4]; c.rl.rotation.x = cur[5];
    bend(c.la.geo, Math.min(0, cur[12])); bend(c.ra.geo, Math.min(0, cur[13]));
    c.ll.foot.rotation.x = Math.max(0, cur[14]); bend(c.ll.geo, c.ll.foot.rotation.x);
    c.rl.foot.rotation.x = Math.max(0, cur[15]); bend(c.rl.geo, c.rl.foot.rotation.x);
    c.head.rotation.set(cur[6], cur[7], cur[8]); c.body.position.y = cur[9]; c.body.rotation.x = cur[10]; c.body.rotation.y = cur[11];
    if (S.spin) c.root.rotation.y += dt * 0.9;
    face(t);
    const kk = Math.min(1, dt * 5); dist += (tDist - dist) * kk; ty += (tTy - ty) * kk;
    cam.position.set(dist * Math.sin(th) * Math.cos(ph), ty + dist * Math.sin(ph), dist * Math.cos(th) * Math.cos(ph)); cam.lookAt(0, ty, 0);
    R.render(scene, cam);
  }
  raf = requestAnimationFrame(loop);
  return () => { stop = true; cancelAnimationFrame(raf); removeEventListener("resize", resize); R.dispose(); host.innerHTML = ""; delete window.rig; };
}

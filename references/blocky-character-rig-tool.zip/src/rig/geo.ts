// @ts-nocheck
import * as THREE from "three";

export const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
export const PI = Math.PI;
export const V = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
export const mulberry = (a) => () => {
  a |= 0; a = (a + 0x6d2b79f5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

/* ---------- rounded box (torso, limbs, shoes) ---------- */
export function RB(w, h, d, r = 0.16, s = 12) {
  const g = new THREE.BoxGeometry(w, h, d, s, s, s), p = g.attributes.position, n = g.attributes.normal;
  const hw = w / 2 - r, hh = h / 2 - r, hd = d / 2 - r;
  const rm = (v, half, inner) => {
    const a = Math.abs(v) / half, sg = Math.sign(v);
    return sg * (a <= 0.5 ? (a / 0.5) * inner : inner + ((a - 0.5) / 0.5) * r);
  };
  for (let i = 0; i < p.count; i++) {
    const x = rm(p.getX(i), w / 2, hw), y = rm(p.getY(i), h / 2, hh), z = rm(p.getZ(i), d / 2, hd);
    const cx = clamp(x, -hw, hw), cy = clamp(y, -hh, hh), cz = clamp(z, -hd, hd);
    let dx = x - cx, dy = y - cy, dz = z - cz;
    const L = Math.hypot(dx, dy, dz) || 1;
    dx /= L; dy /= L; dz /= L;
    p.setXYZ(i, cx + dx * r, cy + dy * r, cz + dz * r);
    n.setXYZ(i, dx, dy, dz);
  }
  return g;
}
const gc = {};
export const G = (w, h, d, r) => {
  const k = [w, h, d, r] + "";
  return gc[k] || (gc[k] = RB(w, h, d, r));
};

/* ---------- bendable limb (two material groups: top / bottom half) ---------- */
export function limbGeo(w, h, d, r) {
  const g = RB(w, h, d, r, 24), I = g.index.array, p = g.attributes.position.array, T = [], B = [];
  for (let i = 0; i < I.length; i += 3) {
    ((p[I[i] * 3 + 1] + p[I[i + 1] * 3 + 1] + p[I[i + 2] * 3 + 1]) >= 0 ? T : B).push(I[i], I[i + 1], I[i + 2]);
  }
  g.setIndex(T.concat(B)); g.clearGroups(); g.addGroup(0, T.length, 0); g.addGroup(T.length, B.length, 1);
  g.userData = { own: 1, a: 0, p0: p.slice(), n0: g.attributes.normal.array.slice() };
  return g;
}
export function bend(g, a) {
  const u = g.userData;
  if (Math.abs(a - u.a) < 0.003) return;
  u.a = a;
  const P = g.attributes.position, N = g.attributes.normal;
  for (let i = 0; i < P.count; i++) {
    const j = i * 3, y = u.p0[j + 1], e = Math.min(1, Math.max(0, (y + 0.3) / 0.5)), t = 1 - e * e * (3 - 2 * e);
    const c = Math.cos(a * t), n = Math.sin(a * t);
    P.array[j] = u.p0[j];
    P.array[j + 1] = y * c - u.p0[j + 2] * n;
    P.array[j + 2] = y * n + u.p0[j + 2] * c;
    N.array[j] = u.n0[j];
    N.array[j + 1] = u.n0[j + 1] * c - u.n0[j + 2] * n;
    N.array[j + 2] = u.n0[j + 1] * n + u.n0[j + 2] * c;
  }
  P.needsUpdate = N.needsUpdate = true;
}

/* ---------- the head: a tall, glossy rounded "pill" (superellipsoid) ---------- */
export const HD = { A: 0.8, B: 0.95, C: 0.7, E1: 0.55, E2: 0.6, Y0: 0.91 };
const sp = (x, e) => Math.sign(x) * Math.pow(Math.abs(x), e);

// u: 0 = front (+z), PI/2 = +x, PI = back.  v: PI/2 = top, 0 = equator, -PI/2 = chin
export function superPt(u, v, k = 1, h = HD, out = new THREE.Vector3()) {
  const cv = sp(Math.cos(v), h.E1);
  return out.set(h.A * cv * sp(Math.sin(u), h.E2) * k, h.Y0 + h.B * sp(Math.sin(v), h.E1) * k, h.C * cv * sp(Math.cos(u), h.E2) * k);
}

export function superGeo(o) {
  const { a, b, c, e1, e2, cy = 0, uSeg = 48, vSeg = 32, uMin = 0, uMax = PI * 2, uTiles = 4, vTiles = 1.5 } = o;
  const vEnd = typeof o.vEnd === "function" ? o.vEnd : () => (o.vEnd ?? -PI / 2);
  const vStart = typeof o.vStart === "function" ? o.vStart : () => (o.vStart ?? PI / 2);
  const kf = o.kf || (() => 1), post = o.post;
  const pos = [], nor = [], uv = [], idx = [];
  for (let i = 0; i <= uSeg; i++) {
    const u = uMin + ((uMax - uMin) * i) / uSeg, v0 = vStart(u), v1 = vEnd(u);
    for (let j = 0; j <= vSeg; j++) {
      const t = j / vSeg, v = v0 + (v1 - v0) * t, k = kf(t, u, v);
      const cv = Math.cos(v), sv = Math.sin(v), cu = Math.cos(u), su = Math.sin(u);
      let x = a * sp(cv, e1) * sp(su, e2) * k, y = cy + b * sp(sv, e1) * k, z = c * sp(cv, e1) * sp(cu, e2) * k;
      const nx = sp(cv, 2 - e1) * sp(su, 2 - e2) / a, ny = sp(sv, 2 - e1) / b, nz = sp(cv, 2 - e1) * sp(cu, 2 - e2) / c;
      const L = Math.hypot(nx, ny, nz) || 1;
      if (post) { const q = post(x, y, z); x = q[0]; y = q[1]; z = q[2]; }
      pos.push(x, y, z); nor.push(nx / L, ny / L, nz / L);
      if (o.uvf) { const q = o.uvf(x, y, z); uv.push(q[0], q[1]); } else uv.push((i / uSeg) * uTiles, t * vTiles);
    }
  }
  for (let i = 0; i < uSeg; i++) for (let j = 0; j < vSeg; j++) {
    const a0 = i * (vSeg + 1) + j, b0 = a0 + vSeg + 1;
    idx.push(a0, a0 + 1, b0, b0, a0 + 1, b0 + 1);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("normal", new THREE.Float32BufferAttribute(nor, 3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.userData.own = 1;
  return g;
}

/* ---------- tapered flat/round tube along a curve (hair locks, braids, seams) ---------- */
export function lockGeo(pts, o = {}) {
  const curve = new THREE.CatmullRomCurve3(pts, false, "centripetal");
  const len = curve.getLength();
  const seg = o.seg || Math.max(12, Math.min(48, Math.round(len * 16))), rad = o.rad || 8;
  const w = o.w ?? 0.2, th = o.th ?? 0.1, w1 = o.w1 ?? 0.5, tp = o.tp ?? 1.5;
  const center = new THREE.Vector3(0, HD.Y0, 0);
  const pos = [], nor = [], uv = [], idx = [];
  const T = new THREE.Vector3(), ref = new THREE.Vector3(), Bv = new THREE.Vector3(), N = new THREE.Vector3(), prevB = new THREE.Vector3();
  const tmp = new THREE.Vector3();
  for (let i = 0; i <= seg; i++) {
    const t = i / seg, p = curve.getPointAt(t);
    curve.getTangentAt(t, T);
    if (o.ref) ref.copy(o.ref); else ref.copy(p).sub(center).normalize();
    Bv.crossVectors(T, ref);
    if (Bv.length() < 0.25) { ref.set(p.x, 0, p.z).normalize(); if (ref.lengthSq() < 0.1) ref.set(0, 0, 1); Bv.crossVectors(T, ref); }
    Bv.normalize();
    if (i > 0 && Bv.dot(prevB) < 0) Bv.negate();
    prevB.copy(Bv);
    N.crossVectors(T, Bv).normalize();
    const prof = 1 - (1 - w1) * Math.pow(t, tp);
    const tip = t > 0.93 ? Math.sqrt(Math.max(0, 1 - Math.pow((t - 0.93) / 0.07, 2))) : 1;
    const ww = w * prof * tip, tt = th * prof * tip;
    for (let r = 0; r <= rad; r++) {
      const a = (r / rad) * PI * 2, c = Math.cos(a), s = Math.sin(a);
      pos.push(p.x + Bv.x * c * ww + N.x * s * tt, p.y + Bv.y * c * ww + N.y * s * tt, p.z + Bv.z * c * ww + N.z * s * tt);
      tmp.set(0, 0, 0).addScaledVector(Bv, c * Math.max(tt, 0.004)).addScaledVector(N, s * Math.max(ww, 0.004)).normalize();
      nor.push(tmp.x, tmp.y, tmp.z);
      uv.push((r / rad) * (o.uT ?? 1), t * (o.vT ?? 1.5));
    }
  }
  for (let i = 0; i < seg; i++) for (let r = 0; r < rad; r++) {
    const a0 = i * (rad + 1) + r, b0 = a0 + rad + 1;
    idx.push(a0, a0 + 1, b0, b0, a0 + 1, b0 + 1);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("normal", new THREE.Float32BufferAttribute(nor, 3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.userData.own = 1;
  return g;
}

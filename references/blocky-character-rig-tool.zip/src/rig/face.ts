// @ts-nocheck
/* eyes: o oval, d dot, r ring, p ring+pupil, w wide ring, g > < wink, ^ happy, u closed, - line, h half-lid, H heart, S star, @ spiral, x cross
   brows: n none, f flat, a angry, s sad, u raised, za/zs zigzag, r1/r2 = reference arched pair
   mouths: c curve(p), sm smirk, cat, zig, grin(p=teeth), tongue, box, wavy, o(p=size), sob, teeth, ov = reference tilted oval
   extras: k gaze, ec eye color, bl blush, tr tears, jt joy tears, sw sweat, zz sleep, sl shock lines, vn anger vein, sh shades */
export const EM = [["Curious (Main)", ["o", "o"], ["r1", "r2"], ["ov"]], ["Neutral", ["d", "d"], ["n", "n"], ["c", 0.25]], ["Happy", ["o", "o"], ["u", "u"], ["grin", 0]], ["Talking", ["o", "o"], ["n", "n"], ["talk", 0.3]], ["Scared", ["r", "r"], ["n", "n"], ["wavy"]], ["Worried", ["p", "p"], ["s", "s"], ["zig"], { k: [0, 0.5] }], ["Thinking", ["p", "p"], ["f", "u"], ["c", -0.1], { k: [0.8, -0.8] }], ["Skeptical", ["h", "o"], ["a", "u"], ["sm"]], ["Serious", ["d", "d"], ["f", "f"], ["c", 0]], ["Angry", ["o", "o"], ["a", "a"], ["teeth"], { ec: "#e8261c", vn: 1 }], ["Surprised", ["w", "w"], ["u", "u"], ["o", 1]],
  ["Sad", ["p", "p"], ["s", "s"], ["c", -1], { k: [0, 0.6] }], ["Crying", ["p", "p"], ["s", "s"], ["sob"], { tr: 1, k: [0, 0.6] }], ["Laughing", ["^", "^"], ["u", "u"], ["grin", 1], { jt: 1 }], ["Excited", ["S", "S"], ["u", "u"], ["grin", 1], { bl: 1 }], ["Smirk", ["d", "h"], ["f", "u"], ["sm"]], ["Wink", ["g", "o"], ["n", "n"], ["c", 1]], ["Wink Tongue", ["g", "o"], ["n", "n"], ["tongue"]], ["Sleepy", ["h", "h"], ["f", "f"], ["o", 0.2]], ["Sleeping", ["u", "u"], ["n", "n"], ["c", 0.3], { zz: 1 }], ["Love", ["H", "H"], ["n", "n"], ["grin", 0], { bl: 1 }],
  ["Starstruck", ["S", "S"], ["u", "u"], ["grin", 1]], ["Embarrassed", ["d", "d"], ["s", "s"], ["zig"], { bl: 1, sw: 1, k: [-0.8, 0.5] }], ["Disgusted", ["g", "g"], ["a", "a"], ["zig"]], ["Confused", ["p", "p"], ["u", "s"], ["zig"], { k: [0.7, -0.4] }], ["Bored", ["h", "h"], ["f", "f"], ["c", 0]], ["Smug", ["h", "h"], ["u", "f"], ["sm"], { bl: 1 }], ["Evil", ["h", "h"], ["a", "a"], ["grin", 1], { ec: "#c4141c" }], ["Shocked", ["w", "w"], ["u", "u"], ["box"]], ["Shock Lines", ["p", "p"], ["za", "za"], ["box"], { sl: 1 }], ["Terrified", ["w", "w"], ["zs", "zs"], ["wavy"], { sw: 1 }],
  ["Joyful", ["^", "^"], ["u", "u"], ["grin", 0], { bl: 1 }], ["Silly", ["w", "d"], ["u", "n"], ["tongue"]], ["Tongue Out", ["d", "d"], ["n", "n"], ["tongue"], { bl: 1 }], ["Proud", ["^", "^"], ["u", "u"], ["c", 0.8]], ["Determined", ["o", "o"], ["a", "a"], ["teeth"]], ["Nervous", ["p", "p"], ["zs", "zs"], ["zig"], { sw: 1, k: [0.5, 0.2] }], ["Dizzy", ["@", "@"], ["n", "n"], ["wavy"]], ["Annoyed", ["h", "h"], ["a", "a"], ["c", 0]], ["Jealous", ["h", "h"], ["a", "f"], ["c", -0.6]], ["Hopeful", ["p", "p"], ["s", "s"], ["c", 0.6], { k: [0, -0.7] }], ["Pouting", ["p", "p"], ["s", "s"], ["o", 0.1], { bl: 1 }],
  ["Grumpy", ["h", "h"], ["a", "a"], ["c", -1]], ["Mischievous", ["h", "h"], ["a", "u"], ["cat"]], ["Relieved", ["u", "u"], ["n", "n"], ["c", 1], { bl: 1 }], ["Cool", [0, 0], [0, 0], ["sm"], { sh: 1 }], ["Uncanny Grin", ["e", "e"], ["m", "m"], ["big", 1]], ["Glam", ["m", "m"], ["m", "m"], ["lips"], { ec: "#6b3a22" }], ["Man Face", ["l", "l"], ["mr", "m"], ["big", 0]], ["Dead", ["x", "x"], ["n", "n"], ["tongue"]], ["Devil", ["h", "h"], ["a", "a"], ["grin", 2], { ec: "#c4141c", hn: 1 }], ["Angel", ["d", "d"], ["u", "u"], ["c", 0.8], { ha: 1, bl: 1 }], ["Pirate", ["d", "p"], ["a", "u"], ["grin", 1], { ep: 1 }], ["Fancy", ["d", "p"], ["u", "u"], ["c", 0.3], { ms: 1, mn: 1 }], ["Geek", ["p", "p"], ["u", "u"], ["buck"], { gs: 1 }], ["Scream", ["g", "g"], ["a", "a"], ["o", 1.5]], ["Monster", ["r", "w"], ["a", "a"], ["grin", 2]], ["Rockstar", [0, 0], [0, 0], ["grin", 1], { sh: "#c1121f" }], ["Goofy", ["p", "d"], ["u", "n"], ["buck"], { k: [0.6, 0.2] }], ["Grimace", ["p", "p"], ["zs", "zs"], ["teeth"], { sw: 1 }], ["Yawn", ["u", "u"], ["f", "f"], ["o", 1]]];

function heart(x, cx, cy, s) { x.beginPath(); x.moveTo(cx, cy + s * 0.9); x.bezierCurveTo(cx - s * 1.6, cy - s * 0.2, cx - s * 0.8, cy - s * 1.3, cx, cy - s * 0.4); x.bezierCurveTo(cx + s * 0.8, cy - s * 1.3, cx + s * 1.6, cy - s * 0.2, cx, cy + s * 0.9); x.closePath(); }
export function star(x, cx, cy, R, r) { x.beginPath(); for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, q = k % 2 ? r : R; x.lineTo(cx + Math.cos(a) * q, cy + Math.sin(a) * q); } x.closePath(); }
export { heart };
const INK = "#17110d", PK = "#ff7a9a";
function ring(x, ex, ey, r, pu, k) {
  x.fillStyle = INK; x.beginPath(); x.arc(ex, ey, r + 5, 0, 7); x.fill();
  const g = x.createRadialGradient(ex - r * 0.3, ey - r * 0.4, 2, ex, ey, r); g.addColorStop(0, "#fff"); g.addColorStop(1, "#c9ccd6");
  x.fillStyle = g; x.beginPath(); x.arc(ex, ey, r, 0, 7); x.fill();
  if (pu) { const px = ex + k[0] * (r - pu - 3), py = ey + k[1] * (r - pu - 3); x.fillStyle = INK; x.beginPath(); x.arc(px, py, pu, 0, 7); x.fill(); x.fillStyle = "#fff"; x.beginPath(); x.arc(px - pu * 0.3, py - pu * 0.3, pu * 0.28, 0, 7); x.fill(); }
}
function shine(x, ex, ey, rx, ry) { x.fillStyle = "rgba(255,255,255,.85)"; x.beginPath(); x.ellipse(ex - rx * 0.25, ey - ry * 0.45, rx * 0.28, ry * 0.14, 0, 0, 7); x.fill(); }
function eye(x, t, ex, ey, sg, k, ec) {
  x.strokeStyle = INK; x.fillStyle = ec; x.lineWidth = 9; x.beginPath();
  switch (t) {
    case "o": x.ellipse(ex, ey, 11, 25, 0, 0, 7); x.fill(); shine(x, ex, ey, 11, 25); break;
    case "d": x.ellipse(ex, ey, 9, 13, 0, 0, 7); x.fill(); shine(x, ex, ey, 9, 13); break;
    case "r": ring(x, ex, ey, 23, 0, k); break;
    case "p": ring(x, ex, ey, 23, 10, k); break;
    case "w": ring(x, ex, ey, 28, 5, k); break;
    case "g": x.lineWidth = 11; x.moveTo(ex - 20 * sg, ey - 19); x.lineTo(ex + 17 * sg, ey); x.lineTo(ex - 20 * sg, ey + 19); x.stroke(); break;
    case "^": x.moveTo(ex - 18, ey + 8); x.quadraticCurveTo(ex, ey - 22, ex + 18, ey + 8); x.stroke(); break;
    case "u": x.moveTo(ex - 18, ey - 4); x.quadraticCurveTo(ex, ey + 20, ex + 18, ey - 4); x.stroke(); break;
    case "-": x.moveTo(ex - 17, ey + 2); x.lineTo(ex + 17, ey + 2); x.stroke(); break;
    case "h": x.save(); x.rect(ex - 30, ey - 1, 60, 40); x.clip(); x.beginPath(); x.ellipse(ex, ey, 13, 21, 0, 0, 7); x.fill(); x.restore(); x.lineWidth = 7; x.beginPath(); x.moveTo(ex - 16, ey - 1); x.lineTo(ex + 16, ey - 1); x.stroke(); break;
    case "H": x.fillStyle = "#ff3b6b"; x.lineWidth = 4; heart(x, ex, ey, 14); x.fill(); x.stroke(); break;
    case "S": x.fillStyle = "#ffc400"; x.lineWidth = 4; star(x, ex, ey, 27, 12); x.fill(); x.stroke(); break;
    case "@": x.lineWidth = 4; for (let a = 0; a < 17; a += 0.3) x.lineTo(ex + Math.cos(a) * a * 1.5, ey + Math.sin(a) * a * 1.5); x.stroke(); break;
    case "e": case "l": case "m": almond(x, t, ex, ey, sg, k, ec); break;
    case "x": x.moveTo(ex - 14, ey - 14); x.lineTo(ex + 14, ey + 14); x.moveTo(ex + 14, ey - 14); x.lineTo(ex - 14, ey + 14); x.stroke();
  }
}
function almond(x, t, ex, ey, sg, k, ec) {
  const u = t === "e" ? -26 : t === "l" ? -6 : -18, d = t === "e" ? 20 : t === "l" ? 14 : 16, o = ex - sg * 30, i = ex + sg * 30;
  const path = () => { x.beginPath(); x.moveTo(o, ey + 2); x.quadraticCurveTo(ex, ey + u, i, ey + 2); x.quadraticCurveTo(ex, ey + d, o, ey + 2); x.closePath(); };
  if (t === "m") { x.fillStyle = "rgba(235,140,155,.5)"; x.beginPath(); x.ellipse(ex, ey - 6, 34, 18, 0, 0, 7); x.fill(); }
  path(); x.fillStyle = "#fff"; x.fill(); x.save(); x.clip();
  const px = ex + k[0] * 8, py = ey + 2 + k[1] * 4;
  x.fillStyle = t === "m" ? ec : INK; x.beginPath(); x.arc(px, py, t === "e" ? 14 : t === "l" ? 11 : 13, 0, 7); x.fill();
  if (t === "m") { x.fillStyle = INK; x.beginPath(); x.arc(px, py, 6, 0, 7); x.fill(); }
  x.fillStyle = "#fff"; x.beginPath(); x.arc(px - 4, py - 4, 3.5, 0, 7); x.fill(); x.restore();
  path(); x.strokeStyle = INK; x.lineWidth = t === "m" ? 7 : 5; x.stroke();
  if (t === "m") { x.beginPath(); x.moveTo(o, ey + 2); x.lineTo(o - sg * 14, ey - 6); x.stroke(); }
  else { x.lineWidth = 3; x.beginPath(); x.moveTo(o, ey - 8); x.quadraticCurveTo(ex, ey + u - 14, i, ey - 8); x.stroke(); }
}
function brow(x, t, ex, sg) {
  if (t === "n") return;
  const by = 64, o = ex - sg * 24, i = ex + sg * 24;
  x.strokeStyle = INK; x.lineWidth = t[0] === "z" ? 4 : 7; x.beginPath();
  if (t === "r1") { x.lineWidth = 6.5; x.moveTo(o, by + 4); x.quadraticCurveTo(ex - sg * 2, by - 14, i + sg * 3, by + 8); }
  else if (t === "r2") { x.lineWidth = 6.5; x.moveTo(o, by - 6); x.quadraticCurveTo(ex + sg * 4, by - 2, i + sg * 2, by + 10); }
  else if (t === "f") { x.moveTo(o, by); x.lineTo(i, by); }
  else if (t === "a") { x.moveTo(o, by - 8); x.lineTo(i, by + 9); }
  else if (t === "s") { x.moveTo(o, by + 8); x.lineTo(i, by - 9); }
  else if (t === "u") { x.moveTo(o, by + 4); x.quadraticCurveTo(ex, by - 16, i, by + 4); }
  else if (t === "m" || t === "mr") { const h = t === "mr" ? -14 : 0; x.lineWidth = 12; x.moveTo(o, by + 8 + h); x.quadraticCurveTo(ex + sg * 4, by - 16 + h, i, by + 2 + h); }
  else { const d = t === "za" ? 1 : -1; x.moveTo(o, by - 10 * d); x.lineTo(ex - sg * 4, by); x.lineTo(ex + sg, by - 4 * d); x.lineTo(i, by + 9 * d); }
  x.stroke();
}
function FS(x, pth, fill, inner) { pth(); x.fillStyle = fill; x.fill(); x.save(); x.clip(); inner && inner(); x.restore(); pth(); x.stroke(); }
function mouth(x, m, lip) {
  const [t, p = 0] = m, mx = 128, my = 172; x.lineWidth = 7; x.strokeStyle = lip || INK; x.beginPath();
  if (t === "ov") { x.lineWidth = 7; x.strokeStyle = INK; x.ellipse(mx + 6, my + 6, 18, 10, -0.32, 0, 7); x.stroke(); }
  else if (t === "c") { x.moveTo(mx - 30, my - p * 8); x.quadraticCurveTo(mx, my + p * 30, mx + 30, my - p * 8); x.stroke(); }
  else if (t === "sm") { x.moveTo(mx - 26, my + 4); x.quadraticCurveTo(mx + 6, my + 16, mx + 34, my - 10); x.stroke(); }
  else if (t === "cat") { x.moveTo(mx - 38, my - 2); x.quadraticCurveTo(mx - 19, my + 24, mx, my - 2); x.quadraticCurveTo(mx + 19, my + 24, mx + 38, my - 2); x.stroke(); }
  else if (t === "zig") { x.moveTo(mx - 36, my + 4); for (let i = 1; i <= 6; i++) x.lineTo(mx - 36 + i * 12, my + (i % 2 ? -6 : 6) + 4); x.stroke(); }
  else if (t === "grin") FS(x, () => { x.beginPath(); x.moveTo(mx - 42, my - 12); x.quadraticCurveTo(mx, my - 2, mx + 42, my - 12); x.quadraticCurveTo(mx + 34, my + 42, mx, my + 42); x.quadraticCurveTo(mx - 34, my + 42, mx - 42, my - 12); x.closePath(); }, "#4a1313", () => { if (p === 1) { x.fillStyle = "#fff"; x.fillRect(mx - 44, my - 16, 88, 17); } if (p === 2) { x.fillStyle = "#fff"; [-30, 30].forEach((dx) => { x.beginPath(); x.moveTo(mx + dx - 8, my - 16); x.lineTo(mx + dx + 8, my - 16); x.lineTo(mx + dx, my + 10); x.closePath(); x.fill(); }); } x.fillStyle = PK; x.beginPath(); x.ellipse(mx, my + 44, 24, 15, 0, 0, 7); x.fill(); });
  else if (t === "tongue") { x.strokeStyle = "#c93a63"; x.lineWidth = 4; FS(x, () => { x.beginPath(); x.moveTo(mx - 40, my - 6); x.lineTo(mx + 34, my + 6); x.quadraticCurveTo(mx + 10, my + 30, mx - 20, my + 28); x.quadraticCurveTo(mx - 44, my + 20, mx - 40, my - 6); x.closePath(); }, PK, () => { x.fillStyle = "rgba(255,255,255,.35)"; x.beginPath(); x.ellipse(mx - 12, my + 4, 16, 5, 0.15, 0, 7); x.fill(); }); }
  else if (t === "box") FS(x, () => { x.beginPath(); x.moveTo(mx - 28, my - 12); x.lineTo(mx + 28, my - 12); x.quadraticCurveTo(mx + 42, my - 12, mx + 42, my + 2); x.lineTo(mx + 46, my + 22); x.quadraticCurveTo(mx + 48, my + 36, mx + 34, my + 36); x.lineTo(mx - 34, my + 36); x.quadraticCurveTo(mx - 48, my + 36, mx - 46, my + 22); x.lineTo(mx - 42, my + 2); x.quadraticCurveTo(mx - 42, my - 12, mx - 28, my - 12); x.closePath(); }, "#c94e5c", () => { x.fillStyle = "#e87d89"; x.fillRect(mx - 50, my - 16, 100, 26); });
  else if (t === "wavy") FS(x, () => { x.beginPath(); x.moveTo(mx - 50, my + 4); x.bezierCurveTo(mx - 30, my - 14, mx - 10, my + 10, mx + 12, my - 2); x.bezierCurveTo(mx + 30, my - 12, mx + 44, my - 8, mx + 50, my - 6); x.bezierCurveTo(mx + 52, my + 24, mx + 20, my + 34, mx, my + 30); x.bezierCurveTo(mx - 30, my + 34, mx - 54, my + 26, mx - 50, my + 4); x.closePath(); }, "#8c141a", () => { x.fillStyle = "rgba(255,255,255,.12)"; x.fillRect(mx - 60, my - 16, 120, 16); });
  else if (t === "o" || t === "talk") { const rx = t === "talk" ? 20 : 10 + p * 14, ry = t === "talk" ? 5 + p * 55 : 12 + p * 20; FS(x, () => { x.beginPath(); x.ellipse(mx, my + 4 + ry * 0.6, rx, ry, 0, 0, 7); }, "#4a1313", () => { x.fillStyle = PK; x.beginPath(); x.ellipse(mx, my + 4 + ry * 1.4, rx * 0.8, ry * 0.5, 0, 0, 7); x.fill(); }); }
  else if (t === "big") FS(x, () => { x.beginPath(); x.moveTo(mx - 64, my - 24); x.quadraticCurveTo(mx, my - 4, mx + 64, my - 24); x.quadraticCurveTo(mx + 52, my + 52, mx, my + 54); x.quadraticCurveTo(mx - 52, my + 52, mx - 64, my - 24); x.closePath(); }, "#fff", () => { x.lineWidth = 4; x.beginPath(); x.moveTo(mx - 64, my + 6); x.quadraticCurveTo(mx, my + 22, mx + 64, my + 6); [-2, -1, 0, 1, 2].forEach((i) => { x.moveTo(mx + i * 20, my - 10); x.lineTo(mx + i * 20, my + 10); }); x.stroke(); });
  else if (t === "lips") { x.strokeStyle = "#7a0a22"; x.lineWidth = 4; FS(x, () => { x.beginPath(); x.moveTo(mx - 50, my + 4); x.quadraticCurveTo(mx - 24, my - 22, mx, my - 10); x.quadraticCurveTo(mx + 30, my - 26, mx + 52, my - 8); x.quadraticCurveTo(mx + 34, my + 34, mx - 4, my + 34); x.quadraticCurveTo(mx - 40, my + 30, mx - 50, my + 4); x.closePath(); }, "#d11a40", () => { x.fillStyle = "#fff"; x.beginPath(); x.moveTo(mx - 38, my + 6); x.quadraticCurveTo(mx, my - 6, mx + 40, my - 2); x.quadraticCurveTo(mx + 28, my + 22, mx - 4, my + 22); x.quadraticCurveTo(mx - 30, my + 20, mx - 38, my + 6); x.fill(); x.fillStyle = "rgba(255,255,255,.55)"; x.beginPath(); x.ellipse(mx - 10, my + 28, 9, 3, 0, 0, 7); x.fill(); }); }
  else if (t === "buck") { x.moveTo(mx - 30, my - 6); x.quadraticCurveTo(mx, my + 26, mx + 30, my - 6); x.stroke(); x.fillStyle = "#fff"; x.beginPath(); x.rect(mx - 14, my + 9, 28, 20); x.fill(); x.lineWidth = 5; x.stroke(); x.beginPath(); x.moveTo(mx, my + 9); x.lineTo(mx, my + 29); x.stroke(); }
  else if (t === "sob") FS(x, () => { x.beginPath(); x.moveTo(mx - 36, my + 22); x.quadraticCurveTo(mx, my - 24, mx + 36, my + 22); x.quadraticCurveTo(mx, my + 8, mx - 36, my + 22); x.closePath(); }, "#4a1313");
  else if (t === "teeth") { x.fillStyle = "#fff"; x.rect(mx - 36, my - 4, 72, 28); x.fill(); x.stroke(); x.lineWidth = 4; x.beginPath(); x.moveTo(mx - 12, my - 4); x.lineTo(mx - 12, my + 24); x.moveTo(mx + 12, my - 4); x.lineTo(mx + 12, my + 24); x.moveTo(mx - 36, my + 10); x.lineTo(mx + 36, my + 10); x.stroke(); }
}

// o: { gl: glasses, fem: lashes + lip tint, fr: freckles }
export function drawFace(x, E, blink, mo, o = {}) {
  const [, ey, bw, mt, X = {}] = E, k = X.k || [0, 0];
  x.clearRect(0, 0, 256, 256); x.lineCap = x.lineJoin = "round";
  if (!X.sh) [[88, 1], [168, -1]].forEach(([ex, sg], i) => {
    let t = ey[i]; if (blink && "odrpwhelm".includes(t)) t = "-";
    eye(x, t, ex, 112, sg, k, X.ec || INK); brow(x, bw[i], ex, sg);
    if (o.fem && t !== "-" && t !== 0 && !"u^gx".includes(t)) {
      x.strokeStyle = INK; x.lineWidth = 5;
      [[9, -20, 25, -31], [12, -9, 30, -17], [12, 2, 29, -3]].forEach(([a, b, c, d]) => { x.beginPath(); x.moveTo(ex - sg * a, 112 + b); x.lineTo(ex - sg * c, 112 + d); x.stroke(); });
    }
  });
  mouth(x, mo || mt, o.fem ? "#7a1030" : null);
  if (X.bl) { x.fillStyle = "rgba(255,90,110,.5)"; [48, 208].forEach((bx) => { x.beginPath(); x.ellipse(bx, 148, 18, 10, 0, 0, 7); x.fill(); }); }
  if (o.fem && !X.bl) { x.fillStyle = "rgba(255,110,130,.22)"; [50, 206].forEach((bx) => { x.beginPath(); x.ellipse(bx, 150, 20, 11, 0, 0, 7); x.fill(); }); }
  if (o.fr) { x.fillStyle = "rgba(150,80,40,.55)"; [[56, 138], [66, 148], [76, 136], [84, 148], [180, 136], [190, 148], [200, 138], [172, 148]].forEach(([fx, fy]) => { x.beginPath(); x.arc(fx, fy, 2.6, 0, 7); x.fill(); }); }
  if (X.tr) { x.fillStyle = "#5bc8ff"; [88, 168].forEach((bx) => { x.beginPath(); x.ellipse(bx, 146, 7, 13, 0, 0, 7); x.fill(); }); }
  if (X.jt) { x.fillStyle = "#5bc8ff"; [[34, 96, -0.6], [222, 96, 0.6]].forEach(([bx, by, r]) => { x.beginPath(); x.ellipse(bx, by, 6, 12, r, 0, 7); x.fill(); }); }
  if (X.sw) { x.fillStyle = "#7fd4ff"; x.beginPath(); x.moveTo(214, 40); x.quadraticCurveTo(230, 64, 214, 74); x.quadraticCurveTo(198, 64, 214, 40); x.fill(); }
  if (X.zz) { x.fillStyle = INK; x.font = "bold 34px sans-serif"; x.fillText("Z", 190, 60); x.font = "bold 22px sans-serif"; x.fillText("z", 224, 34); }
  if (X.sl) { x.strokeStyle = "#4a78c9"; x.lineWidth = 6;[[40, 64], [54, 80], [68, 56], [82, 72]].forEach(([lx, ly]) => { x.beginPath(); x.moveTo(lx, 10); x.lineTo(lx, ly); x.stroke(); }); }
  if (X.vn) { x.strokeStyle = "#e8261c"; x.lineWidth = 6;[[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([a, b]) => { x.beginPath(); x.moveTo(212 + a * 4, 46 + b * 16); x.quadraticCurveTo(212 + a * 4, 46 + b * 4, 212 + a * 16, 46 + b * 4); x.stroke(); }); }
  if (X.sh) { x.fillStyle = X.sh === 1 ? "#111" : X.sh; x.fillRect(46, 92, 76, 42); x.fillRect(134, 92, 76, 42); x.fillRect(120, 98, 16, 8); x.strokeStyle = "rgba(255,255,255,.5)"; x.lineWidth = 4; x.beginPath(); x.moveTo(58, 102); x.lineTo(80, 102); x.moveTo(146, 102); x.lineTo(168, 102); x.stroke(); }
  if (X.ms) { x.fillStyle = INK; x.beginPath(); x.moveTo(128, 150); x.bezierCurveTo(112, 138, 84, 142, 70, 162); x.bezierCurveTo(88, 154, 108, 160, 128, 162); x.bezierCurveTo(148, 160, 168, 154, 186, 162); x.bezierCurveTo(172, 142, 144, 138, 128, 150); x.fill(); }
  if (X.ep) { x.fillStyle = x.strokeStyle = INK; x.lineWidth = 6; x.beginPath(); x.moveTo(56, 104); x.lineTo(2, 88); x.moveTo(118, 90); x.lineTo(254, 56); x.stroke(); x.beginPath(); x.ellipse(88, 112, 33, 28, -0.3, 0, 7); x.fill(); }
  if (X.mn) { x.strokeStyle = "#d8a31a"; x.lineWidth = 5; x.beginPath(); x.arc(168, 112, 36, 0, 7); x.stroke(); x.beginPath(); x.moveTo(198, 132); x.quadraticCurveTo(214, 180, 202, 236); x.stroke(); }
  if (X.hn) { x.fillStyle = "#d1202a"; x.strokeStyle = INK; x.lineWidth = 4;[[34, 1], [222, -1]].forEach(([hx, s]) => { x.beginPath(); x.moveTo(hx - s * 6, 52); x.lineTo(hx - s * 2, 6); x.lineTo(hx + s * 30, 36); x.closePath(); x.fill(); x.stroke(); }); }
  if (X.ha) { x.strokeStyle = "#ffd23f"; x.lineWidth = 8; x.beginPath(); x.ellipse(128, 16, 46, 11, 0, 0, 7); x.stroke(); }
  if (o.gl || X.gs) { x.strokeStyle = "#222"; x.lineWidth = 5;[88, 168].forEach((bx) => { x.beginPath(); x.arc(bx, 112, 35, 0, 7); x.stroke(); }); x.beginPath(); x.moveTo(123, 110); x.lineTo(133, 110); x.stroke(); }
}

// @ts-nocheck
import * as THREE from "three";

export const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
export const sn = Math.sin;

/* Rounded box with smooth normals */
export function RB(w, h, d, r = 0.16, s = 12) {
  const g = new THREE.BoxGeometry(w, h, d, s, s, s),
    p = g.attributes.position,
    n = g.attributes.normal,
    hw = w / 2 - r,
    hh = h / 2 - r,
    hd = d / 2 - r;
  const rm = (v, half, inner) => {
    const a = Math.abs(v) / half,
      sg = Math.sign(v);
    return sg * (a <= 0.5 ? (a / 0.5) * inner : inner + ((a - 0.5) / 0.5) * r);
  };
  for (let i = 0; i < p.count; i++) {
    const x = rm(p.getX(i), w / 2, hw),
      y = rm(p.getY(i), h / 2, hh),
      z = rm(p.getZ(i), d / 2, hd);
    const cx = clamp(x, -hw, hw),
      cy = clamp(y, -hh, hh),
      cz = clamp(z, -hd, hd);
    let dx = x - cx,
      dy = y - cy,
      dz = z - cz;
    const L = Math.hypot(dx, dy, dz) || 1;
    dx /= L;
    dy /= L;
    dz /= L;
    p.setXYZ(i, cx + dx * r, cy + dy * r, cz + dz * r);
    n.setXYZ(i, dx, dy, dz);
  }
  return g;
}

const gc = {};
export const G = (w, h, d, r) => {
  const k = [w, h, d, r] + "";
  return gc[k] || (gc[k] = RB(w, h, d, r));
};

/* Limb that can bend at its middle (elbow / knee) */
export function limbGeo(w, h, d, r) {
  const g = RB(w, h, d, r, 24),
    I = g.index.array,
    p = g.attributes.position.array,
    T = [],
    B = [];
  for (let i = 0; i < I.length; i += 3) {
    (p[I[i] * 3 + 1] + p[I[i + 1] * 3 + 1] + p[I[i + 2] * 3 + 1] >= 0 ? T : B).push(I[i], I[i + 1], I[i + 2]);
  }
  g.setIndex(T.concat(B));
  g.clearGroups();
  g.addGroup(0, T.length, 0);
  g.addGroup(T.length, B.length, 1);
  g.userData = { own: 1, a: 0, p0: p.slice(), n0: g.attributes.normal.array.slice() };
  return g;
}

export function bend(g, a) {
  const u = g.userData;
  if (Math.abs(a - u.a) < 0.003) return;
  u.a = a;
  const P = g.attributes.position,
    N = g.attributes.normal;
  for (let i = 0; i < P.count; i++) {
    const j = i * 3,
      y = u.p0[j + 1],
      e = Math.min(1, Math.max(0, (y + 0.3) / 0.5)),
      t = 1 - e * e * (3 - 2 * e),
      c = Math.cos(a * t),
      n = Math.sin(a * t);
    P.array[j] = u.p0[j];
    P.array[j + 1] = y * c - u.p0[j + 2] * n;
    P.array[j + 2] = y * n + u.p0[j + 2] * c;
    N.array[j] = u.n0[j];
    N.array[j + 1] = u.n0[j + 1] * c - u.n0[j + 2] * n;
    N.array[j + 2] = u.n0[j + 1] * n + u.n0[j + 2] * c;
  }
  P.needsUpdate = N.needsUpdate = true;
}

export const P = (c) =>
  new THREE.MeshPhysicalMaterial({ color: c, roughness: 0.4, clearcoat: 0.5, clearcoatRoughness: 0.25 });

export const M = (g, m, x = 0, y = 0, z = 0) => {
  const o = new THREE.Mesh(g, m);
  o.position.set(x, y, z);
  o.castShadow = o.receiveShadow = true;
  return o;
};

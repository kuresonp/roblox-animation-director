// @ts-nocheck
/* Smooth, organic hair system (no blocks).
   Hair = scalp shell that tapers onto the skin (clean hairline) + curtain sheets for long hair
   + tapered locks / curls / braids / buns / ponytails, all merged into a few meshes.
   Coordinates are head-local: face toward +z, head centre (0,.62,0), top y = 1.2. */
import * as THREE from "three";
import { RB } from "./geo.js";

const V = (x, y, z) => new THREE.Vector3(x, y, z);
const lerp = (a, b, t) => a + (b - a) * t;
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const sm = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};
const CY = 0.62;
const C0 = V(0, CY, -0.04);
const PI = Math.PI;
const hl = (a, hf, hs, hb) => hf + (hs - hf) * sm(0.5, 1.3, a) + (hb - hs) * sm(1.7, 2.7, a);
const mb = (a) => () => {
  a |= 0;
  a = (a + 0x6d2b79f5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

/* rounded-box SDF of the head */
function sdf(x, y, z) {
  const qx = Math.abs(x) - 0.27,
    qy = Math.abs(y - CY) - 0.24,
    qz = Math.abs(z) - 0.24;
  return (
    Math.hypot(Math.max(qx, 0), Math.max(qy, 0), Math.max(qz, 0)) + Math.min(Math.max(qx, qy, qz), 0) - 0.34
  );
}
/* point on (offset) head surface by azimuth th (0 = front, + = viewer right) and elevation psi */
export function on(th, psi, off = 0.03) {
  const dx = Math.sin(th) * Math.cos(psi),
    dy = Math.sin(psi),
    dz = Math.cos(th) * Math.cos(psi);
  let lo = 0,
    hi = 1.8;
  for (let i = 0; i < 24; i++) {
    const m = (lo + hi) / 2;
    if (sdf(dx * m, CY + dy * m, dz * m) < off) lo = m;
    else hi = m;
  }
  return V(dx * lo, CY + dy * lo, dz * lo);
}
const halfW = (y) => {
  const d = Math.min(1.2 - y, y - 0.04);
  if (d >= 0.34) return 0.61;
  if (d <= 0) return 0.27;
  const k = 0.34 - d;
  return 0.27 + Math.sqrt(Math.max(0, 0.34 * 0.34 - k * k));
};
const pl = (sx, sz, A, B) => {
  const r = Math.pow(Math.pow(Math.abs(sx / A), 3) + Math.pow(Math.abs(sz / B), 3), -1 / 3);
  return [sx * r, sz * r];
};

/* ---------- geometry builders ---------- */
function paint(g, k) {
  const n = g.attributes.position.count,
    c = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    if (Array.isArray(k)) {
      c[i * 3] = k[0];
      c[i * 3 + 1] = k[1];
      c[i * 3 + 2] = k[2];
    } else c[i * 3] = c[i * 3 + 1] = c[i * 3 + 2] = k;
  }
  g.setAttribute("color", new THREE.BufferAttribute(c, 3));
  return g;
}

function weld(g) {
  g.computeVertexNormals();
  const P = g.attributes.position,
    N = g.attributes.normal,
    m = new Map(),
    key = (i) =>
      Math.round(P.getX(i) * 2000) + "," + Math.round(P.getY(i) * 2000) + "," + Math.round(P.getZ(i) * 2000);
  for (let i = 0; i < P.count; i++) {
    const k = key(i),
      e = m.get(k) || [0, 0, 0];
    e[0] += N.getX(i);
    e[1] += N.getY(i);
    e[2] += N.getZ(i);
    m.set(k, e);
  }
  for (let i = 0; i < P.count; i++) {
    const e = m.get(key(i)),
      L = Math.hypot(e[0], e[1], e[2]) || 1;
    N.setXYZ(i, e[0] / L, e[1] / L, e[2] / L);
  }
}

function shellGeo(o, cut) {
  const { hf = 0.56, hs = 0.2, hb = -0.2, t = 0.065, vol = null, dark = 1, lines = 0, region = null } = o;
  const hat = cut < Infinity;
  const g = RB(1.22, 1.16, 1.16, 0.34, 44),
    P = g.attributes.position,
    N = g.attributes.normal,
    n = P.count,
    S = new Float32Array(n),
    col = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    const x = P.getX(i),
      y = P.getY(i),
      z = P.getZ(i),
      yw = y + CY,
      r = Math.hypot(x, y, z) || 1,
      psi = Math.asin(clamp(y / r, -1, 1)),
      th = Math.atan2(x, z),
      a = Math.abs(th);
    let s = region ? region(x, yw, z, psi, th, a) : 0.62 * (psi - hl(a, hf, hs, hb));
    if (hat) s = Math.min(s, (cut - yw) * 1.2);
    S[i] = s;
    let w = lerp(-0.05, t, sm(-0.02, 0.06, s));
    if (vol && !hat) w += vol(x, yw, z, psi, th, a) * sm(0, 0.12, s);
    P.setXYZ(i, x + N.getX(i) * w, yw + N.getY(i) * w, z + N.getZ(i) * w);
    const st = lines ? 0.5 + 0.5 * Math.sin(x * 34 + Math.sin(z * 4) * 2) : 0.5 + 0.5 * Math.sin(th * 24 + yw * 3),
      st2 = 0.5 + 0.5 * Math.sin(th * 57 + yw * 7);
    const k = (0.74 + 0.26 * (0.6 * st + 0.4 * st2)) * lerp(0.7, 1, sm(0, 0.2, s)) * dark;
    col[i * 3] = col[i * 3 + 1] = col[i * 3 + 2] = k;
  }
  const I = g.index.array,
    keep = [];
  for (let i = 0; i < I.length; i += 3) {
    if (Math.max(S[I[i]], S[I[i + 1]], S[I[i + 2]]) > -0.1) keep.push(I[i], I[i + 1], I[i + 2]);
  }
  g.setIndex(keep);
  g.setAttribute("color", new THREE.BufferAttribute(col, 3));
  g.deleteAttribute("uv");
  weld(g);
  return g;
}

function lockGeo(pts, o = {}) {
  const { w0 = 0.12, w1 = 0, th = 0.75, bulge = 0, seg = 16, ring = 8, pw = 1, hint = null, b0 = 1, b1 = 0.85 } = o;
  const cv = new THREE.CatmullRomCurve3(pts, false, "catmullrom", 0.5);
  cv.arcLengthDivisions = 60;
  const pos = [],
    col = [],
    idx = [];
  let last = null;
  for (let i = 0; i <= seg; i++) {
    const t = i / seg,
      Pp = cv.getPointAt(t),
      T = cv.getTangentAt(t);
    const Hh = hint ? hint.clone() : Pp.clone().sub(C0);
    if (Hh.lengthSq() < 1e-4) Hh.set(0, 1, 0);
    Hh.normalize();
    const S = new THREE.Vector3().crossVectors(T, Hh);
    if (S.lengthSq() < 1e-4) S.set(1, 0, 0);
    S.normalize();
    const B = new THREE.Vector3().crossVectors(S, T).normalize();
    let w = lerp(w0, w1, Math.pow(t, pw)) * (1 + bulge * Math.sin(PI * t));
    if (i === seg && w1 === 0) w = 0.001;
    const h = w * th,
      k = lerp(b0, b1, t);
    for (let j = 0; j < ring; j++) {
      const a = (j / ring) * PI * 2,
        c = Math.cos(a),
        s = Math.sin(a);
      pos.push(Pp.x + S.x * c * w + B.x * s * h, Pp.y + S.y * c * w + B.y * s * h, Pp.z + S.z * c * w + B.z * s * h);
      col.push(k, k, k);
    }
    last = Pp;
  }
  for (let i = 0; i < seg; i++)
    for (let j = 0; j < ring; j++) {
      const a = i * ring + j,
        b = i * ring + ((j + 1) % ring),
        c = a + ring,
        d = b + ring;
      idx.push(a, c, b, b, c, d);
    }
  if (w1 > 0) {
    const ci = pos.length / 3,
      base = seg * ring;
    pos.push(last.x, last.y, last.z);
    col.push(b1, b1, b1);
    for (let j = 0; j < ring; j++) idx.push(ci, base + ((j + 1) % ring), base + j);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("color", new THREE.Float32BufferAttribute(col, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

function blobGeo(c, r, o = {}) {
  const g = new THREE.SphereGeometry(1, 14, 10);
  g.deleteAttribute("uv");
  const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(...(o.rot || [0, 0, 0])));
  g.applyMatrix4(new THREE.Matrix4().compose(c, q, V(r[0], r[1], r[2])));
  return paint(g, o.k ?? 1);
}
function torusGeo(c, r, o = {}) {
  const g = new THREE.TorusGeometry(1, 0.26, 8, 24);
  g.deleteAttribute("uv");
  const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(...(o.rot || [PI / 2, 0, 0])));
  g.applyMatrix4(new THREE.Matrix4().compose(c, q, V(r, r, r * (o.sq ?? 1))));
  return paint(g, o.k ?? 1);
}

function sheetGeo(o) {
  const { bot = -1.4, phi = 1.95, top = 0.88, out = 0.055, flare = 0.04, wave = 0, tipUp = 0.35, jag = 0, kf = 1 } = o;
  const nu = 60,
    nv = 30,
    pos = [],
    col = [],
    idx = [];
  for (let i = 0; i <= nu; i++) {
    const u = (i / nu) * 2 - 1,
      end = bot + tipUp * u * u + jag * Math.abs(Math.sin(u * 10.5));
    for (let j = 0; j <= nv; j++) {
      const v = j / nv,
        y = lerp(top, end, v),
        ph = u * phi + wave * 0.1 * Math.sin(v * 6 + u * 2.3 + 1),
        yy = clamp(y, 0.38, 1.2),
        a = halfW(yy),
        b = (a * 0.58) / 0.61,
        k = kf * sm(0.35, -0.25, y),
        o2 =
          out +
          flare * sm(0.2, 1, v) +
          wave * 0.04 * Math.sin(v * 8 + u * 3) +
          0.012 * Math.sin(ph * 38 + Math.sin(v * 5) * 2),
        A = lerp(a + o2, 1.0 + o2 * 0.2, k),
        B = lerp(b + o2, 0.7, k),
        [x, z] = pl(Math.sin(ph), -Math.cos(ph), A, B);
      pos.push(x, y, z);
      const c =
        (0.72 + 0.28 * (0.5 + 0.5 * Math.sin(ph * 40 + Math.sin(v * 6) * 2))) * lerp(0.75, 1, sm(0, 0.3, v));
      col.push(c, c, c);
    }
  }
  for (let i = 0; i < nu; i++)
    for (let j = 0; j < nv; j++) {
      const a = i * (nv + 1) + j,
        b = a + 1,
        c = a + nv + 1,
        d = c + 1;
      idx.push(a, b, c, b, d, c);
    }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("color", new THREE.Float32BufferAttribute(col, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

function merge(list) {
  let nv = 0,
    ni = 0;
  list.forEach((g) => {
    nv += g.attributes.position.count;
    ni += g.index.count;
  });
  const Pp = new Float32Array(nv * 3),
    Nn = new Float32Array(nv * 3),
    Cc = new Float32Array(nv * 3),
    I = new Uint32Array(ni);
  let vo = 0,
    io = 0;
  list.forEach((g) => {
    Pp.set(g.attributes.position.array, vo * 3);
    Nn.set(g.attributes.normal.array, vo * 3);
    Cc.set(g.attributes.color.array, vo * 3);
    const ix = g.index.array;
    for (let i = 0; i < ix.length; i++) I[io + i] = ix[i] + vo;
    vo += g.attributes.position.count;
    io += ix.length;
    g.dispose();
  });
  const m = new THREE.BufferGeometry();
  m.setAttribute("position", new THREE.BufferAttribute(Pp, 3));
  m.setAttribute("normal", new THREE.BufferAttribute(Nn, 3));
  m.setAttribute("color", new THREE.BufferAttribute(Cc, 3));
  m.setIndex(new THREE.BufferAttribute(I, 1));
  m.userData.own = 1;
  return m;
}

/* ---------- builder ---------- */
export const HAT_CUT = {
  cap: 0.96, mcap: 0.97, beanie: 0.93, top: 1.02, crown: 1.01, wizard: 1.0, helmet: 0.96,
  cowboy: 1.02, chef: 0.96, party: 1.03, police: 0.86,
};

export function buildHair(style, color, cut = Infinity) {
  const fn = STY[style];
  if (!fn) return null;
  const hat = cut < Infinity;
  const rnd = mb([...(style + color)].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7));
  const base = new THREE.Color(color);
  const tint = (hex) => {
    const c = new THREE.Color(hex);
    return [c.r / Math.max(base.r, 0.05), c.g / Math.max(base.g, 0.05), c.b / Math.max(base.b, 0.05)].map((v) =>
      Math.min(v, 8)
    );
  };
  const mat = new THREE.MeshPhysicalMaterial({
    color: base, roughness: 0.42, clearcoat: 0.55, clearcoatRoughness: 0.3, vertexColors: true,
  });
  const matD = mat.clone();
  matD.side = THREE.DoubleSide;
  const grp = { main: { piv: V(0, 0, 0), w: 0, s: [], d: [] } };
  const H = { hat, cut, R: rnd, on, V, sm, lerp, hl, PI };
  H.group = (n, piv, w) => {
    grp[n] = grp[n] || { piv, w, s: [], d: [] };
  };
  H.add = (g, o = {}) => {
    if (hat && o.top) return g.dispose();
    if (hat && g.index) {
      /* trim anything above the hat line so hair never pokes through the hat */
      const Pp = g.attributes.position, I = g.index.array, keep = [];
      for (let i = 0; i < I.length; i += 3) {
        if ((Pp.getY(I[i]) + Pp.getY(I[i + 1]) + Pp.getY(I[i + 2])) / 3 <= cut) keep.push(I[i], I[i + 1], I[i + 2]);
      }
      if (!keep.length) return g.dispose();
      g.setIndex(keep);
    }
    grp[o.g || "main"][o.dbl ? "d" : "s"].push(g);
  };
  H.shell = (o, a) => H.add(shellGeo(o, cut), a);
  H.lock = (pts, o, a) => H.add(lockGeo(pts, o), a);
  H.blob = (c, r, o, a) => H.add(blobGeo(c, r, o), a);
  H.sheet = (o, a) => H.add(sheetGeo(o), { ...a, dbl: true });
  H.tie = (c, r, o = {}, a) => H.add(torusGeo(c, r, { ...o, k: tint(o.color || "#ff5d8f") }), a);
  H.spike = (th, psi, len, bt = 0, bp = 0.15, w = 0.17, a = { top: 1 }) => {
    const b = on(th, psi, 0.02),
      d = b.clone().sub(C0).normalize(),
      sd = V(Math.cos(th), 0, -Math.sin(th)),
      tip = b.clone().addScaledVector(d, len).addScaledVector(sd, bt * len).add(V(0, bp * len, 0)),
      mid = b.clone().lerp(tip, 0.5).addScaledVector(d, 0.04);
    H.lock([b, mid, tip], { w0: w, w1: 0, th: 0.9, pw: 0.8, seg: 8, ring: 6 }, a);
  };
  H.cloud = (n, r0, r1, o = {}, a = { top: 1 }) => {
    const { hf = 0.5, hs = 0.25, hb = 0, off = 0.1, m = 0.04, lo = -0.35 } = o;
    for (let i = 0; i < n; i++) {
      const yv = lerp(1, lo, (i + 0.5) / n),
        psi = Math.asin(yv),
        az = ((i * 2.39996 + PI) % (PI * 2)) - PI;
      if (psi < hl(Math.abs(az), hf, hs, hb) + m) continue;
      const c = on(az, psi, off + (rnd() - 0.5) * 0.05),
        r = lerp(r0, r1, rnd());
      H.blob(c, [r, r * 0.92, r], { k: 0.8 + rnd() * 0.25 }, a);
    }
  };
  H.curl = (start, dir, len, R, turns, o = {}, a) => {
    const d = dir.clone().normalize(),
      u = new THREE.Vector3().crossVectors(d, V(0, 0, 1));
    if (u.lengthSq() < 0.1) u.crossVectors(d, V(1, 0, 0));
    u.normalize();
    const v = new THREE.Vector3().crossVectors(d, u),
      pts = [],
      ph = o.ph || 0;
    for (let i = 0; i <= 28; i++) {
      const t = i / 28,
        rr = R * (1 - 0.3 * t),
        an = PI * 2 * turns * t + ph;
      pts.push(
        start.clone().addScaledVector(d, len * t).addScaledVector(u, Math.cos(an) * rr).addScaledVector(v, Math.sin(an) * rr)
      );
    }
    H.lock(pts, { w0: o.w0 || 0.075, w1: o.w1 || 0.04, th: 1, seg: 40, ring: 6, b0: 0.95, b1: 0.8, hint: o.hint }, a);
  };
  H.braid = (pts, o = {}, a) => {
    const cv = new THREE.CatmullRomCurve3(pts),
      n = o.n || 10,
      r = o.r || 0.16;
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1),
        p = cv.getPointAt(t),
        T = cv.getTangentAt(t),
        S = new THREE.Vector3().crossVectors(T, V(0, 0, 1));
      if (S.lengthSq() < 0.05) S.crossVectors(T, V(1, 0, 0));
      S.normalize();
      const rr = r * (1 - 0.55 * t),
        sg = i % 2 ? 1 : -1;
      H.blob(p.addScaledVector(S, sg * 0.03), [rr * 1.05, rr * 1.2, rr], { rot: [0, 0, sg * 0.55], k: 0.85 + 0.15 * (i % 2) }, a);
    }
    const e = cv.getPointAt(1);
    H.tie(e, (o.r || 0.16) * 0.5, { color: o.tie || "#ff5d8f", rot: [PI / 2, 0, 0] }, a);
  };
  /* tail built from parallel locks */
  H.tail = (pts, o = {}, a) => {
    const { n = 3, spread = 0.08, w0 = 0.2, w1 = 0, bulge = 0.3, off = V(1, 0, 0) } = o;
    for (let k = 0; k < n; k++) {
      const s = (k - (n - 1) / 2) * spread;
      H.lock(pts.map((p, i) => p.clone().addScaledVector(off, s * (i === 0 ? 0.4 : 1))), { w0, w1, th: 0.9, bulge, seg: 24, pw: 0.9, b0: 0.95, b1: 0.8 }, a);
    }
  };
  /* straight blunt bangs */
  H.bangs = (n = 9, span = 0.85, endPsi = 0.58, w = 0.12) => {
    for (let i = 0; i < n; i++) {
      const u = (i / (n - 1)) * 2 - 1,
        th = u * span,
        ep = endPsi + 0.08 * Math.abs(u) + rnd() * 0.03;
      H.lock([on(th * 0.3, 1.3, 0.05), on(th * 0.8, 0.95, 0.1), on(th * 0.95, ep + 0.2, 0.115), on(th, ep, 0.12)], {
        w0: w * 1.2, w1: w * 0.85, th: 0.7, seg: 10, ring: 6,
      }, { top: 1 });
    }
  };
  /* bangs falling to both sides */
  H.curtainBangs = (n = 4, reach = 1) => {
    [-1, 1].forEach((sx) => {
      for (let k = 0; k < n; k++) {
        const f = k / Math.max(1, n - 1);
        H.lock([
          on(sx * 0.12, 1.3, 0.06),
          on(sx * (0.35 + 0.1 * f), 1.0, 0.115),
          on(sx * (0.8 + 0.15 * f) * reach, 0.62 + 0.1 * f, 0.125),
          on(sx * (1.15 + 0.1 * f), 0.3 + 0.1 * f, 0.1),
        ], { w0: 0.18, w1: 0, th: 0.6, pw: 0.85, seg: 14 }, { top: 1 });
      }
    });
  };
  /* side-swept fringe: part on side sg, sweeps over to the other */
  H.sweep = (sg = 1, o = {}) => {
    const { n = 7, wd = 0.19, low = 0.55, reach = 1, part = 0.62 } = o;
    for (let i = 0; i < n; i++) {
      const f = i / (n - 1);
      H.lock([
        on(sg * part, 1.38, 0.06),
        on(sg * (part * 0.5 - f * 0.15), 1.12, 0.11 + 0.01 * i),
        on(-sg * (0.3 + f * 0.5 * reach), 0.84 + 0.1 * f, 0.14),
        on(-sg * (0.85 + 0.35 * f) * reach, low + 0.1 * f, 0.13),
      ], { w0: wd, w1: 0, th: 0.65, pw: 0.85, seg: 14 }, { top: 1 });
    }
  };
  /* locks that fall over the shoulder in front */
  H.drape = (sx, L, o = {}) => {
    const { n = 2, w = 0.2, wave = 0, blunt = 0 } = o;
    for (let k = 0; k < n; k++) {
      const wv = (a) => wave * Math.sin(a + k) * 0.06;
      H.lock([
        on(sx * 1.2, 0.32, 0.05),
        on(sx * (1.45 - 0.05 * k), -0.3, 0.11),
        V(sx * (0.8 - 0.04 * k), 0.02, 0.54 + 0.03 * k),
        V(sx * (0.76 + wv(1)), -L * 0.4, 0.64 + 0.03 * k),
        V(sx * (0.74 + wv(3)), -L * 0.75, 0.65 + 0.03 * k),
        V(sx * (0.74 + wv(5)), -L, 0.64 + 0.03 * k),
      ], { w0: w, w1: blunt ? w * 0.6 : 0, th: 0.5, seg: 28, pw: 1.3, b0: 1, b1: 0.8 });
    }
  };
  /* long hair back curtain */
  H.long = (o = {}) => {
    H.shell({ t: 0.07, hf: o.hf ?? 0.56, hs: -0.1, hb: -0.9 });
    H.sheet({ bot: o.bot ?? -1.4, phi: o.phi ?? 1.95, flare: o.flare ?? 0.05, wave: o.wave || 0, tipUp: o.tipUp ?? 0.45, jag: o.jag || 0, kf: o.kf ?? 1 });
  };
  /* fin for mohawks */
  H.fins = (n, len, w, th = 0.5, spanFront = 0.6, spanBack = 0.0) => {
    for (let i = 0; i < n; i++) {
      const s = i / (n - 1),
        front = s < 0.5,
        az = front ? 0 : PI,
        psi = front ? lerp(spanFront, 1.5, s * 2) : lerp(1.5, spanBack, (s - 0.5) * 2),
        b = on(az, psi, 0.02),
        d = b.clone().sub(C0).normalize(),
        L = len * (0.7 + 0.5 * Math.sin(s * PI)) * (0.9 + rnd() * 0.2),
        tip = b.clone().addScaledVector(d, L).add(V(0, 0.05, front ? 0.05 : -0.05));
      H.lock([b, b.clone().lerp(tip, 0.5), tip], { w0: w, w1: 0, th, hint: V(1, 0, 0), seg: 8, ring: 6, pw: 0.9 }, { top: 1 });
    }
  };

  fn(H);

  const root = new THREE.Group(),
    sway = [];
  for (const g of Object.values(grp)) {
    const go = new THREE.Group();
    go.position.copy(g.piv);
    root.add(go);
    [[g.s, mat], [g.d, matD]].forEach(([list, m]) => {
      if (!list.length) return;
      list.forEach((x) => x.translate(-g.piv.x, -g.piv.y, -g.piv.z));
      const mesh = new THREE.Mesh(merge(list), m);
      mesh.castShadow = true;
      go.add(mesh);
    });
    if (g.w) sway.push({ g: go, w: g.w });
  }
  return { group: root, sway };
}

/* ================= STYLES ================= */
const STY = {};
const quiffLocks = (H, span, n, hgt = 1) => {
  for (let i = 0; i < n; i++) {
    const th = (i / (n - 1) - 0.5) * 2 * span;
    H.lock([on(th, 0.6, 0.07), on(th, 0.92, 0.17 * hgt), on(th * 0.8, 1.24, 0.3 * hgt), on(th * 0.4, 1.45, 0.3 * hgt), on(th * 0.2 + PI, 1.35, 0.22)], {
      w0: 0.17, w1: 0, th: 0.8, seg: 18, pw: 0.8,
    }, { top: 1 });
  }
};
const ponyLow = (H, c = "#2a2a32") => {
  H.group("tail", V(0, 0.65, -0.58), 1);
  H.tail([V(0, 0.75, -0.5), V(0, 0.5, -0.78), V(0, 0, -0.84), V(0, -0.7, -0.78), V(0, -0.95, -0.76)], { n: 3, w0: 0.17, bulge: 0.3 }, { g: "tail" });
  H.tie(V(0, 0.68, -0.6), 0.17, { color: c, rot: [0.4, 0, 0] }, { g: "tail" });
};

/* ----- male / neutral ----- */
STY.buzz = (H) => H.shell({ t: 0.03, hf: 0.64, hs: 0.32, hb: 0.12, dark: 0.95 });
STY.crop = (H) => {
  H.shell({ t: 0.06, hf: 0.6, hs: 0.28, hb: 0.0, vol: (x, y, z, p) => 0.035 * sm(0.9, 1.4, p) });
  for (let i = 0; i < 9; i++) {
    const u = i / 4 - 1, th = u * 0.95;
    H.lock([on(th * 0.3, 1.3, 0.05), on(th * 0.75, 0.98, 0.1), on(th, 0.62 + 0.12 * Math.abs(u) + H.R() * 0.05, 0.12)], {
      w0: 0.115, w1: 0, th: 0.8, seg: 6, ring: 6,
    }, { top: 1 });
  }
};
STY.sidepart = (H) => {
  H.shell({ t: 0.065, hf: 0.58, hs: 0.22, hb: -0.05, vol: (x, y, z, p, th) => 0.07 * sm(0.3, 1, Math.cos(th)) * sm(0.6, 1.3, p) });
  H.sweep(1, { n: 7 });
};
STY.quiff = (H) => {
  H.shell({ t: 0.065, hf: 0.6, hs: 0.3, hb: 0.05, vol: (x, y, z, p, th) => 0.1 * sm(0.3, 0.9, Math.cos(th)) * sm(0.5, 1.1, p) });
  quiffLocks(H, 0.55, 8);
};
STY.slick = (H) => H.shell({ t: 0.06, hf: 0.64, hs: 0.3, hb: 0.0, lines: 1, vol: (x, y, z, p, th) => 0.045 * sm(0.2, 1, Math.cos(th)) * sm(0.7, 1.3, p) });
STY.spikes = (H) => {
  H.shell({ t: 0.06, hf: 0.56, hs: 0.22, hb: 0.0 });
  for (let i = 0; i < 20; i++) {
    const th = i * 2.4, az = ((th + PI) % (PI * 2)) - PI, psi = lerp(1.45, 0.65, Math.pow(i / 20, 0.8));
    if (psi < hl(Math.abs(az), 0.56, 0.22, 0) + 0.08) continue;
    H.spike(az, psi, 0.38 + H.R() * 0.22, (H.R() - 0.5) * 0.5, 0.15);
  }
};
STY.undercut = (H) => {
  H.shell({ t: 0.022, hf: 0.3, hs: -0.15, hb: -0.35, dark: 0.7 });
  H.shell({ t: 0.09, region: (x, y, z, p, th, a) => 0.62 * (p - lerp(0.52, 0.88, sm(0.3, 1.4, a))), vol: (x, y, z, p, th) => 0.08 * sm(0.3, 0.9, Math.cos(th)) });
  quiffLocks(H, 0.45, 6, 0.8);
};
STY.curlytop = (H) => {
  H.shell({ t: 0.06, hf: 0.55, hs: 0.28, hb: 0.0 });
  H.cloud(54, 0.16, 0.22, { hf: 0.5, hs: 0.3, hb: 0.08, off: 0.1 });
};
STY.afro = (H) => {
  H.shell({ t: 0.1, hf: 0.5, hs: 0.2, hb: -0.2, vol: () => 0.22 });
  H.cloud(110, 0.27, 0.36, { hf: 0.45, hs: 0.1, hb: -0.2, off: 0.36, lo: -0.3 });
};
STY.manbun = (H) => {
  H.shell({ t: 0.06, hf: 0.62, hs: 0.34, hb: 0.2, lines: 1 });
  H.blob(V(0, 1.42, -0.28), [0.27, 0.24, 0.27], {}, { top: 1 });
  H.tie(V(0, 1.3, -0.26), 0.2, { color: "#2a2a32", rot: [0.35, 0, 0] }, { top: 1 });
};
STY.surfer = (H) => {
  H.shell({ t: 0.075, hf: 0.56, hs: 0.0, hb: -0.45 });
  H.sheet({ bot: -0.3, phi: 1.8, flare: 0.1, wave: 1, tipUp: 0.3 });
  H.curtainBangs(4, 1);
  [-1, 1].forEach((s) => H.drape(s, 0.55, { n: 2, w: 0.18, wave: 1 }));
};
STY.mohawk = (H) => {
  H.shell({ t: 0.02, hf: 0.3, hs: -0.1, hb: -0.3, dark: 0.7 });
  H.shell({ t: 0.09, region: (x, y, z, p) => Math.min((0.17 - Math.abs(x)) * 3, 0.62 * (p + 0.1)) });
  H.fins(13, 0.5, 0.16, 0.55);
};
STY.fauxhawk = (H) => {
  H.shell({ t: 0.05, hf: 0.58, hs: 0.3, hb: 0.1, dark: 0.9 });
  H.shell({ t: 0.09, region: (x, y, z, p) => Math.min((0.3 - Math.abs(x)) * 2.4, 0.62 * (p - 0.5)) });
  H.fins(9, 0.32, 0.2, 0.8, 0.75, 0.3);
};
STY.bowl = (H) => {
  H.shell({ t: 0.1, hf: 0.55, hs: -0.02, hb: -0.1 });
  H.bangs(9, 0.85, 0.58, 0.12);
};
STY.ponylow = (H) => {
  H.shell({ t: 0.06, hf: 0.6, hs: 0.25, hb: -0.1, lines: 1, vol: (x, y, z, p, th) => 0.04 * sm(0.2, 1, Math.cos(th)) * sm(0.7, 1.3, p) });
  ponyLow(H);
  H.sweep(-1, { n: 5, wd: 0.17, low: 0.62, reach: 0.8 });
};
STY.dreads = (H) => {
  H.shell({ t: 0.07, hf: 0.56, hs: 0.25, hb: 0.05, vol: () => 0.03 });
  for (let i = 0; i < 24; i++) {
    const az = (i / 24) * (PI * 2 - 1.4) + 0.7 - PI + PI, a = ((az + PI) % (PI * 2)) - PI, aa = Math.abs(a);
    if (aa < 0.7) continue;
    const psi = lerp(0.55, 0.15, aa / PI),
      b = on(a, psi, 0.04),
      back = aa > 2.3,
      ye = back ? -0.9 + H.R() * 0.4 : 0.05 - H.R() * 0.1,
      ex = b.x * 1.12 + (H.R() - 0.5) * 0.1;
    let ez = b.z * 1.12;
    if (back) ez = Math.min(ez, -0.64);
    H.lock([b, V(b.x * 1.06, b.y - 0.12, b.z * 1.06), V(ex, lerp(b.y, ye, 0.6), ez), V(ex * 1.02, ye, ez * 1.02)], { w0: 0.075, w1: 0.055, th: 1, seg: 14, ring: 7 });
  }
  H.cloud(18, 0.12, 0.17, { hf: 0.6, hs: 0.5, hb: 0.3, off: 0.08, lo: 0.2 });
};
STY.comb = (H) => {
  H.shell({ t: 0.05, region: (x, y, z, p, th, a) => Math.min(0.62 * (0.7 - p), 0.62 * (p + 0.22), (a - 0.9) * 0.5) });
  [-1, 1].forEach((s) => H.blob(V(s * 0.63, 0.78, -0.05), [0.1, 0.14, 0.2], {}, {}));
  for (let k = 0; k < 4; k++)
    H.lock([on(-1.45, 0.9, 0.04), on(-1.0, 1.35 + k * 0.01, 0.06 + 0.005 * k), on(-0.1 * k, 1.52, 0.05), on(1.0, 1.3, 0.06), on(1.45, 0.85, 0.05)], {
      w0: 0.05, w1: 0.02, th: 0.5, seg: 22, ring: 5, b0: 0.9, b1: 0.9,
    }, { top: 1 });
};
STY.anime = (H) => {
  H.shell({ t: 0.06, hf: 0.58, hs: 0.25, hb: 0.0 });
  for (let i = 0; i < 12; i++) {
    const az = ((i * 2.1 + PI) % (PI * 2)) - PI, psi = lerp(1.4, 0.7, i / 12);
    if (psi < hl(Math.abs(az), 0.58, 0.25, 0) + 0.1) continue;
    H.spike(az, psi, 0.6 + H.R() * 0.25, (H.R() - 0.5) * 0.9, 0.12, 0.23);
  }
  [-0.62, -0.22, 0.22, 0.62].forEach((th, i) =>
    H.lock([on(th * 0.5, 1.2, 0.1), on(th, 0.88, 0.18), on(th * 1.1 + (i < 2 ? -0.06 : 0.06), 0.58, 0.17)], { w0: 0.19, w1: 0, th: 0.7, seg: 10 }, { top: 1 })
  );
};
STY.topknot = (H) => {
  H.shell({ t: 0.05, hf: 0.64, hs: 0.36, hb: 0.2, lines: 1 });
  H.blob(V(0, 1.5, -0.12), [0.2, 0.2, 0.2], {}, { top: 1 });
  H.lock([V(0, 1.4, -0.1), V(0, 1.75, -0.12), V(-0.08, 1.95, -0.2)], { w0: 0.11, w1: 0, th: 1, seg: 8, ring: 6, hint: V(0, 0, 1) }, { top: 1 });
  H.tie(V(0, 1.36, -0.1), 0.15, { color: "#c1121f", rot: [PI / 2, 0, 0] }, { top: 1 });
};
STY.messy = (H) => {
  H.shell({ t: 0.07, hf: 0.56, hs: 0.22, hb: 0.0 });
  for (let i = 0; i < 18; i++) {
    const az = ((i * 2.4 + PI) % (PI * 2)) - PI, psi = lerp(1.45, 0.7, Math.pow(i / 18, 0.8));
    if (psi < hl(Math.abs(az), 0.56, 0.22, 0) + 0.08) continue;
    H.spike(az, psi, 0.34 + H.R() * 0.18, (H.R() - 0.5) * 1.1, 0.0, 0.22);
  }
  for (let i = 0; i < 6; i++) {
    const th = (i / 5 - 0.5) * 1.5;
    H.lock([on(th * 0.3, 1.3, 0.07), on(th * 0.8, 0.98, 0.13), on(th + (H.R() - 0.5) * 0.3, 0.62 + H.R() * 0.12, 0.14)], { w0: 0.15, w1: 0, th: 0.8, seg: 8 }, { top: 1 });
  }
};
STY.mullet = (H) => {
  H.shell({ t: 0.065, hf: 0.58, hs: 0.2, hb: -0.55, vol: (x, y, z, p, th) => 0.05 * sm(0.3, 0.9, Math.cos(th)) * sm(0.6, 1.2, p) });
  H.sheet({ bot: -0.7, phi: 1.3, flare: 0.08, wave: 0.5, tipUp: 0.3 });
  for (let i = 0; i < 7; i++) {
    const th = (i / 6 - 0.5) * 1.6;
    H.lock([on(th * 0.3, 1.3, 0.05), on(th * 0.8, 0.98, 0.12), on(th * 1.05, 0.6 + H.R() * 0.1, 0.14)], { w0: 0.15, w1: 0, th: 0.8, seg: 8 }, { top: 1 });
  }
};
STY.emo = (H) => {
  H.shell({ t: 0.07, hf: 0.58, hs: 0.0, hb: -0.3 });
  H.sheet({ bot: 0.1, phi: 1.75, flare: 0.1, tipUp: 0.2 });
  H.sweep(1, { n: 9, wd: 0.22, low: 0.32, reach: 1.15 });
  [-1, 1].forEach((s) => H.drape(s, 0.1, { n: 1, w: 0.2, blunt: 0 }));
};

/* ----- female ----- */
STY.longstraight = (H) => {
  H.long({ bot: -1.45 });
  H.curtainBangs(4);
  [-1, 1].forEach((s) => H.drape(s, 1.3, { n: 3, w: 0.17 }));
};
STY.hime = (H) => {
  H.long({ bot: -1.5, tipUp: 0.3 });
  H.bangs(11, 0.8, 0.6, 0.11);
  [-1, 1].forEach((s) => H.drape(s, 1.0, { n: 2, w: 0.2, blunt: 1 }));
};
STY.curtain = (H) => {
  H.long({ bot: -1.0, wave: 0.4 });
  H.curtainBangs(5);
  [-1, 1].forEach((s) => H.drape(s, 0.85, { n: 2, w: 0.18, wave: 0.4 }));
};
STY.longwavy = (H) => {
  H.long({ bot: -1.4, wave: 1.1, flare: 0.1 });
  H.curtainBangs(4);
  [-1, 1].forEach((s) => H.drape(s, 1.25, { n: 3, w: 0.17, wave: 1.5 }));
};
STY.longcurly = (H) => {
  H.long({ bot: -0.9, wave: 1.7, flare: 0.12 });
  H.curtainBangs(3);
  [-0.85, -0.5, -0.15, 0.15, 0.5, 0.85].forEach((p, i) =>
    H.curl(V(0.98 * Math.sin(p), -0.2, -0.74 * Math.cos(p) - 0.04), V(0, -1, -0.05), 1.0 + (i % 2) * 0.2, 0.11, 3.2, { ph: i })
  );
  [-1, 1].forEach((s) => {
    H.curl(V(s * 0.74, 0.1, 0.56), V(0, -1, 0.1), 1.1, 0.1, 3.4, { ph: s });
    H.curl(V(s * 0.8, 0.12, 0.54), V(0, -1, 0.1), 0.9, 0.09, 3, { ph: s + 2 });
  });
};
const bobBase = (H, bot, flare) => {
  H.shell({ t: 0.075, hf: 0.56, hs: 0.0, hb: -0.6 });
  H.sheet({ bot, phi: 1.75, flare, kf: 0.35, tipUp: 0.12 });
  [-1, 1].forEach((s) =>
    H.lock([on(s * 1.2, 0.3, 0.05), on(s * 1.5, -0.2, 0.14), on(s * 1.25, bot + 0.0 - 0.02 + 0.1, 0.2), on(s * 0.95, bot - 0.06, 0.22)], {
      w0: 0.2, w1: 0.12, th: 0.6, seg: 14, pw: 1.4,
    })
  );
};
STY.bob = (H) => {
  bobBase(H, 0.05, 0.12);
  H.sweep(1, { n: 6, wd: 0.18, low: 0.6, reach: 0.9, part: 0.55 });
};
STY.bangsbob = (H) => {
  bobBase(H, 0.05, 0.12);
  H.bangs(9, 0.85, 0.58, 0.12);
};
STY.lobbob = (H) => {
  bobBase(H, -0.4, 0.2);
  H.curtainBangs(3);
};
STY.pixie = (H) => {
  H.shell({ t: 0.06, hf: 0.58, hs: 0.3, hb: 0.1 });
  H.sweep(-1, { n: 6, wd: 0.15, low: 0.62, reach: 0.7 });
  [-1, 1].forEach((s) => H.lock([on(s * 1.25, 0.5, 0.05), on(s * 1.4, 0.3, 0.1), on(s * 1.45, 0.1, 0.11)], { w0: 0.13, w1: 0.07, th: 0.7, seg: 8 }));
  for (let i = 0; i < 4; i++) H.spike(PI + (i - 1.5) * 0.35, 0.05, 0.22, 0.2, -0.1, 0.12, {});
};
STY.shag = (H) => {
  H.shell({ t: 0.075, hf: 0.56, hs: 0.0, hb: -0.5 });
  H.sheet({ bot: -0.15, phi: 1.9, flare: 0.12, wave: 0.6, tipUp: 0.25, jag: 0.2 });
  H.curtainBangs(5, 0.9);
  for (let i = 0; i < 5; i++) {
    const s = i % 2 ? 1 : -1;
    H.lock([on(s * 1.2, 0.4, 0.05), on(s * 1.4, 0.1, 0.14), on(s * 1.55, -0.2 - i * 0.04, 0.2)], { w0: 0.13, w1: 0, th: 0.6, seg: 8 });
  }
};
STY.highpony = (H) => {
  H.shell({ t: 0.06, hf: 0.62, hs: 0.34, hb: 0.28, lines: 1 });
  const hp = H.hat ? [0.78, 0.8, 0.5, 0.1, -0.5] : [1.0, 1.22, 0.85, 0.15, -0.5];
  H.group("pony", V(0, hp[0] + 0.02, -0.52), 1);
  H.tail([V(0, hp[0], -0.5), V(0, hp[1], -0.82), V(0, hp[2], -1.08), V(0, hp[3], -1.08), V(0, hp[4], -0.98)], { n: 4, w0: 0.2, bulge: 0.35 }, { g: "pony" });
  H.tie(V(0, hp[0] + 0.02, -0.54), 0.2, { color: "#ff5d8f", rot: [0.9, 0, 0] }, { g: "pony" });
  H.curtainBangs(3, 0.8);
  [-1, 1].forEach((s) => H.lock([on(s * 1.15, 0.45, 0.05), on(s * 1.4, 0.0, 0.1), on(s * 1.35, -0.3, 0.13)], { w0: 0.07, w1: 0, th: 0.6, seg: 8 }));
};
STY.pigtails = (H) => {
  H.shell({ t: 0.065, hf: 0.58, hs: 0.15, hb: -0.1 });
  [-1, 1].forEach((s) => {
    const dy = H.hat ? -0.25 : 0;
    H.group("pt" + s, V(s * 0.62, 0.95 + dy, -0.1), 1);
    H.tail([V(s * 0.6, 0.95 + dy, -0.1), V(s * 0.92, 0.85 + dy, -0.15), V(s * 1.08, 0.5, -0.1), V(s * 1.12, 0.12, 0), V(s * 1.18, -0.05, 0.1)], { n: 2, spread: 0.1, w0: 0.22, bulge: 0.3, off: V(0, 0, 1) }, { g: "pt" + s });
    H.tie(V(s * 0.72, 0.93 + dy, -0.12), 0.17, { color: "#ff4f9a", rot: [0, 0, 1.2 * s] }, { g: "pt" + s });
  });
  H.bangs(7, 0.7, 0.6, 0.12);
};
STY.spacebuns = (H) => {
  H.shell({ t: 0.06, hf: 0.58, hs: 0.28, hb: 0.05 });
  [-1, 1].forEach((s) => {
    H.blob(V(s * 0.5, 1.32, -0.1), [0.3, 0.3, 0.3], {}, { top: 1 });
    H.tie(V(s * 0.46, 1.2, -0.1), 0.22, { color: "#ff5d8f", rot: [0.2, 0, 0.6 * s] }, { top: 1 });
  });
  H.curtainBangs(3, 0.9);
};
STY.topbun = (H) => {
  H.shell({ t: 0.06, hf: 0.58, hs: 0.28, hb: 0.1, lines: 1 });
  H.blob(V(0, 1.52, -0.12), [0.34, 0.3, 0.34], {}, { top: 1 });
  H.tie(V(0, 1.34, -0.1), 0.25, { color: "#ff5d8f", rot: [0.15, 0, 0] }, { top: 1 });
  H.curtainBangs(3, 0.9);
};
STY.lowbun = (H) => {
  H.shell({ t: 0.06, hf: 0.6, hs: 0.3, hb: 0.15, lines: 1 });
  H.blob(V(0, 0.52, -0.7), [0.3, 0.3, 0.26], {});
  H.tie(V(0, 0.52, -0.6), 0.24, { color: "#7a5a8a", rot: [0, 0, 0] });
  H.curtainBangs(3, 0.85);
};
STY.halfup = (H) => {
  H.long({ bot: -1.4, hf: 0.6 });
  H.blob(V(0, 1.44, -0.14), [0.24, 0.22, 0.24], {}, { top: 1 });
  H.tie(V(0, 1.3, -0.1), 0.2, { color: "#ff5d8f", rot: [0.2, 0, 0] }, { top: 1 });
  H.curtainBangs(3, 0.9);
  [-1, 1].forEach((s) => H.drape(s, 1.2, { n: 2, w: 0.17 }));
};
const braidSide = (H, s, tie) => {
  H.group("br" + s, V(s * 0.6, 0.55, -0.1), 0.5);
  H.braid([V(s * 0.6, 0.55, -0.1), V(s * 0.82, 0.2, 0.2), V(s * 0.74, -0.3, 0.6), V(s * 0.66, -0.85, 0.63), V(s * 0.62, -1.3, 0.63)], { n: 12, r: 0.17, tie }, { g: "br" + s });
};
STY.twinbraids = (H) => {
  H.shell({ t: 0.07, hf: 0.58, hs: 0.0, hb: -0.4 });
  H.sheet({ bot: 0.1, phi: 1.7, flare: 0.05, kf: 0.4, tipUp: 0.1 });
  braidSide(H, -1, "#ff5d8f");
  braidSide(H, 1, "#ff5d8f");
  H.curtainBangs(3, 0.9);
};
STY.sidebraid = (H) => {
  H.shell({ t: 0.07, hf: 0.58, hs: 0.0, hb: -0.5 });
  H.sheet({ bot: -0.15, phi: 1.75, flare: 0.06, kf: 0.5, tipUp: 0.2 });
  braidSide(H, 1, "#f5d34a");
  H.sweep(-1, { n: 6, wd: 0.19, low: 0.58, reach: 0.9 });
  H.drape(-1, 0.6, { n: 1, w: 0.17 });
};
STY.sidesweep = (H) => {
  H.long({ bot: -1.1, wave: 0.8, hf: 0.58 });
  H.sweep(-1, { n: 9, wd: 0.22, low: 0.5, reach: 1.1 });
  [-1, 1].forEach((s) => H.drape(s, 0.95, { n: 2, w: 0.18, wave: 0.8 }));
};
STY.ringlets = (H) => {
  H.shell({ t: 0.075, hf: 0.56, hs: 0.0, hb: -0.3 });
  H.sheet({ bot: 0.0, phi: 1.8, flare: 0.1, kf: 0.5, tipUp: 0.2, wave: 0.6 });
  for (let i = 0; i < 9; i++) {
    const p = (i / 8 - 0.5) * 1.8;
    H.curl(V(0.9 * Math.sin(p), 0.1, -0.74 * Math.cos(p) - 0.04), V(0, -1, -0.05), 0.85 + (i % 3) * 0.12, 0.1, 3, { ph: i * 1.3 });
  }
  [-1, 1].forEach((s) => {
    H.curl(V(s * 0.74, 0.15, 0.5), V(0, -1, 0.12), 0.9, 0.1, 3, { ph: s });
    H.curl(V(s * 0.66, 0.3, 0.3), V(s * 0.1, -1, 0.2), 0.7, 0.09, 2.6, { ph: s * 2 });
  });
  H.curtainBangs(3, 0.9);
};
STY.afropuffs = (H) => {
  H.shell({ t: 0.075, hf: 0.52, hs: 0.2, hb: -0.1 });
  [-1, 1].forEach((s) => {
    const c = V(s * 0.52, 1.3, -0.1);
    for (let i = 0; i < 24; i++) {
      const y = 1 - 2 * ((i + 0.5) / 24), r = Math.sqrt(1 - y * y), a = i * 2.39996, rr = 0.17 + H.R() * 0.05;
      H.blob(c.clone().add(V(Math.cos(a) * r * 0.36, y * 0.34, Math.sin(a) * r * 0.36)), [rr, rr, rr], { k: 0.8 + H.R() * 0.25 }, { top: 1 });
    }
    H.blob(c, [0.34, 0.32, 0.34], {}, { top: 1 });
    H.tie(V(s * 0.5, 1.02, -0.1), 0.2, { color: "#ffd23f", rot: [0.2, 0, 0.5 * s] }, { top: 1 });
  });
};
STY.curlybob = (H) => {
  H.shell({ t: 0.08, hf: 0.55, hs: 0.0, hb: -0.5 });
  H.cloud(110, 0.17, 0.23, { hf: 0.48, hs: -0.25, hb: -0.5, off: 0.16, lo: -0.62 });
};
STY.ponyside = (H) => {
  H.shell({ t: 0.065, hf: 0.58, hs: 0.2, hb: -0.2, lines: 1 });
  H.group("sp", V(-0.6, 0.9, -0.1), 1);
  H.tail([V(-0.6, 0.9, -0.1), V(-0.95, 0.78, -0.15), V(-1.0, 0.36, 0.05), V(-0.9, -0.0, 0.3), V(-0.82, -0.18, 0.42)], { n: 3, spread: 0.08, w0: 0.2, bulge: 0.3, off: V(0, 0, 1) }, { g: "sp" });
  H.tie(V(-0.7, 0.88, -0.12), 0.18, { color: "#ff5d8f", rot: [0, 0, -1] }, { g: "sp" });
  H.sweep(1, { n: 5, wd: 0.17, low: 0.6, reach: 0.9 });
};

export const HAIR_STYLES = Object.keys(STY);

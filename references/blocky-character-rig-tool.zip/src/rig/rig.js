// @ts-nocheck
import * as THREE from "three";
import { clamp, sn, G, limbGeo, bend, P, M } from "./geo.js";
import { CH, OU, EM, PO } from "./data.js";
import { drawFace } from "./face.js";
import { patTex, mkHat } from "./hats.js";
import { buildHair, HAT_CUT } from "./hair.js";

const idx = (arr, n) => Math.max(0, arr.findIndex((a) => a[0] === n));
CH.forEach((c) => {
  c.oi = c.o ? idx(OU, c.o) : -1;
  c.ei = c.e ? idx(EM, c.e) : -1;
  c.pi = c.p ? idx(PO, c.p) : -1;
});

export function initRig(host) {
  const $ = (s) => host.querySelector(s);
  host.innerHTML = `<div id="hint"><b id="who"></b><span id="what"></span><i>Tap a face below · drag to orbit · pinch to zoom</i></div><div id="ui"></div>`;

  const scene = new THREE.Scene(),
    cam = new THREE.PerspectiveCamera(40, 1, 0.1, 100),
    R = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  R.shadowMap.enabled = true;
  R.shadowMap.type = THREE.PCFSoftShadowMap;
  host.prepend(R.domElement);
  scene.add(new THREE.HemisphereLight(0xffffff, 0x8899bb, 0.85));
  const dl = new THREE.DirectionalLight(0xffffff, 0.85);
  dl.position.set(5, 12, 8);
  dl.castShadow = true;
  dl.shadow.mapSize.set(1024, 1024);
  Object.assign(dl.shadow.camera, { left: -8, right: 8, top: 10, bottom: -4, near: 1, far: 40 });
  dl.shadow.camera.updateProjectionMatrix();
  scene.add(dl);
  const rim = new THREE.DirectionalLight(0x9b5cff, 1.0);
  rim.position.set(-6, 6, -9);
  rim.visible = false;
  scene.add(rim);
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.ShadowMaterial({ opacity: 0.28 }));
  fl.rotation.x = -Math.PI / 2;
  fl.receiveShadow = true;
  scene.add(fl);
  const disc = new THREE.Mesh(new THREE.CircleGeometry(3.4, 48), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.3 }));
  disc.rotation.x = -Math.PI / 2;
  disc.position.y = 0.01;
  scene.add(disc);

  const S = { c: 0, e: 0, o: 0, p: 0, talk: 0, spin: 0 },
    cur = new Array(16).fill(0);
  let ch = null;

  /* ---------- BUILD ---------- */
  function build() {
    if (ch) {
      scene.remove(ch.root);
      ch.root.traverse((o) => {
        if (o.material) [].concat(o.material).forEach((m) => { m.map && m.map.dispose(); m.dispose(); });
        o.geometry && o.geometry.userData.own && o.geometry.dispose();
      });
    }
    const C = CH[S.c],
      [, shC, paC, soC, pat, patC, outHat, outHatC, long, shorts, ex, exC, bare] = OU[S.o];
    /* the red cap is exclusive to Main Character; nobody else can wear it */
    let hat = outHat === "mcap" ? "" : outHat,
      hatC = outHatC;
    if (C.cap && !hat) { hat = C.cap; hatC = C.capC; }
    const root = new THREE.Group(),
      body = new THREE.Group();
    root.add(body);
    root.scale.set(C.w * C.h, C.h, C.w * C.h);
    const skin = P(C.skin),
      shirt = P(shC),
      pants = P(paC),
      shoe = P(soC);
    body.add(M(G(2, 2, 1, 0.2), shirt, 0, 3, 0));
    if (pat) {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 1.5), new THREE.MeshBasicMaterial({ map: patTex(pat, patC), transparent: true }));
      m.position.set(0, 3, 0.505);
      body.add(m);
    }
    const arm = (x) => {
      const g = new THREE.Group(),
        geo = limbGeo(0.98, 1.96, 0.98, 0.2);
      g.position.set(x, 3.85, 0);
      g.add(M(geo, bare ? [skin, skin] : [shirt, long ? shirt : skin], 0, -0.93, 0));
      g.geo = geo;
      body.add(g);
      return g;
    };
    const leg = (x) => {
      const g = new THREE.Group(),
        geo = limbGeo(0.97, 1.8, 0.98, 0.16),
        k = new THREE.Group(),
        f = new THREE.Group();
      g.position.set(x, 2, 0);
      k.position.y = -0.9;
      k.add(M(geo, [pants, shorts ? skin : pants]));
      f.add(M(G(1, 0.3, 1.08, 0.12), shoe, 0, -0.94, 0));
      k.add(f);
      g.add(k);
      body.add(g);
      g.geo = geo;
      g.foot = f;
      return g;
    };
    const la = arm(1.5), ra = arm(-1.5), ll = leg(0.5), rl = leg(-0.5);
    if (ex === "cape") body.add(M(G(1.9, 2.6, 0.12, 0.05), P(exC), 0, 2.8, -0.58));
    if (ex === "pack") body.add(M(G(1.3, 1.5, 0.5, 0.15), P(exC), 0, 3.2, -0.75));
    if (ex === "scarf") body.add(M(G(2.1, 0.4, 1.1, 0.15), P(exC), 0, 3.95, 0));
    const head = new THREE.Group();
    head.position.set(0, 4, 0);
    head.scale.setScalar(C.hz);
    body.add(head);
    head.add(M(G(1.22, 1.16, 1.16, 0.34), skin, 0, 0.62, 0));
    const cv = document.createElement("canvas");
    cv.width = cv.height = 256;
    const tex = new THREE.CanvasTexture(cv);
    tex.anisotropy = 4;
    const fm = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false }));
    fm.position.set(0, 0.58, 0.585);
    head.add(fm);
    let hair = null;
    if (C.style !== "none") {
      hair = buildHair(C.style, C.hair, hat ? HAT_CUT[hat] ?? Infinity : Infinity);
      if (hair) head.add(hair.group);
    }
    if (C.mus) {
      const hm = P(C.hair);
      [-1, 1].forEach((s) => {
        const mu = M(G(0.28, 0.09, 0.1, 0.04), hm, s * 0.14, 0.5, 0.62);
        mu.rotation.z = -s * 0.25;
        head.add(mu);
      });
    }
    if (hat) head.add(mkHat(hat, hatC));
    fcs.style.setProperty("--sk", C.skin);
    scene.add(root);
    ch = { root, body, head, la, ra, ll, rl, ctx: cv.getContext("2d"), tex, fk: "", gl: ex === "glasses", sway: hair ? hair.sway : [], C };
    host.classList.toggle("mainbg", !!C.main);
    rim.visible = !!C.main;
    disc.material.color.set(C.main ? 0xb27bff : 0xffffff);
    disc.material.opacity = C.main ? 0.22 : 0.3;
    $("#who").textContent = C.n;
    $("#what").textContent = C.t;
  }
  function face(t) {
    const E = EM[S.e],
      bl = t % 3.6 > 3.48 && E[1][0] !== "u";
    let mo = null,
      q = 0;
    if (S.talk) {
      q = Math.round((0.12 + 0.35 * Math.abs(sn(t * 9))) * 6) / 6;
      mo = ["talk", q];
    }
    const k = S.e + "|" + (bl ? 1 : 0) + "|" + q;
    if (k === ch.fk) return;
    ch.fk = k;
    const C = ch.C;
    drawFace(ch.ctx, E, bl, mo, { gl: ch.gl, lash: C.lash, fr: C.fr, dy: C.dy, gloss: C.gloss });
    ch.tex.needsUpdate = true;
  }

  /* ---------- UI ---------- */
  const ui = $("#ui"),
    setters = {},
    sels = {};
  const fcs = document.createElement("div");
  fcs.id = "faces";
  ui.appendChild(fcs);
  {
    const tc = document.createElement("canvas");
    tc.width = tc.height = 256;
    const tx = tc.getContext("2d");
    EM.forEach((E, i) => {
      const b = document.createElement("button"),
        c = document.createElement("canvas");
      c.width = c.height = 72;
      b.setAttribute("aria-label", E[0]);
      b.title = E[0];
      drawFace(tx, E, false, null, i === 0 ? { dy: -24, gloss: 1 } : {});
      c.getContext("2d").drawImage(tc, 0, 0, 72, 72);
      b.appendChild(c);
      b.onclick = () => setters.e(i);
      fcs.appendChild(b);
    });
  }
  const mark = () => {
    [...fcs.children].forEach((b, j) => b.classList.toggle("on", j === S.e));
    const b = fcs.children[S.e];
    fcs.scrollTo({ left: b.offsetLeft - fcs.offsetLeft - fcs.clientWidth / 2 + b.offsetWidth / 2, behavior: "smooth" });
  };
  const GROUPS = { Classic: "Classic rig (24)", Guys: "Guys (25)", Girls: "Girls (25)" };
  [["Character", CH, "c"], ["Emotion", EM, "e"], ["Outfit", OU, "o"], ["Pose", PO, "p"]].forEach(([lab, arr, k]) => {
    const d = document.createElement("div");
    let opts;
    if (k === "c") {
      opts = Object.keys(GROUPS)
        .map((g) => `<optgroup label="${GROUPS[g]}">${arr.map((a, i) => (a.g === g ? `<option value="${i}">${a.n}</option>` : "")).join("")}</optgroup>`)
        .join("");
    } else opts = arr.map((a, i) => `<option value="${i}">${a[0]}</option>`).join("");
    d.innerHTML = `<label>${lab} <span>${arr.length}</span></label><div class="r"><button aria-label="Previous ${lab}">‹</button><select aria-label="${lab}">${opts}</select><button aria-label="Next ${lab}">›</button></div>`;
    const [bp, bn] = d.querySelectorAll("button"),
      sl = d.querySelector("select");
    sels[k] = sl;
    const set = (i, quiet) => {
      S[k] = (i + arr.length) % arr.length;
      sl.value = S[k];
      if (k === "c") {
        const C = CH[S.c];
        if (C.oi >= 0) S.o = C.oi;
        if (C.ei >= 0) S.e = C.ei;
        if (C.pi >= 0) S.p = C.pi;
        sels.o.value = S.o;
        sels.e.value = S.e;
        sels.p.value = S.p;
        mark();
      }
      if (k === "c" || k === "o") build();
      if (k === "e") mark();
    };
    sl.onchange = () => set(+sl.value);
    bp.onclick = () => set(S[k] - 1);
    bn.onclick = () => set(S[k] + 1);
    setters[k] = set;
    ui.appendChild(d);
  });
  const bar = document.createElement("div");
  bar.id = "bar";
  bar.innerHTML = `<button id="rnd">Randomize</button><button id="tk">Talk</button><button id="sp">Spin</button>`;
  ui.appendChild(bar);
  $("#rnd").onclick = () => {
    setters.o((Math.random() * OU.length) | 0);
    setters.c((Math.random() * CH.length) | 0);
    if (Math.random() < 0.5) setters.e((EM.length * Math.random()) | 0);
    if (Math.random() < 0.5) setters.p((Math.random() * 10) | 0);
  };
  [["#tk", "talk"], ["#sp", "spin"]].forEach(([id, key]) => {
    const b = $(id);
    b.onclick = () => {
      S[key] ^= 1;
      b.classList.toggle("on", !!S[key]);
    };
  });
  window.rig = {
    state: S,
    setCharacter: (i) => setters.c(i),
    setEmotion: (i) => setters.e(i),
    setOutfit: (i) => setters.o(i),
    setPose: (i) => setters.p(i),
    setCamera: (t, p, d, y = 0.6) => { th = t; ph = p; dist = d; ty = y; },
    characters: CH,
  };

  /* ---------- CAMERA + LOOP ---------- */
  let th = 0.35, ph = 0.12, dist = 19, ty = 0.6, pd = 0, raf = 0, last = 0;
  const pts = new Map(),
    cvs = R.domElement;
  cvs.onpointerdown = (e) => { cvs.setPointerCapture(e.pointerId); pts.set(e.pointerId, [e.clientX, e.clientY]); };
  cvs.onpointermove = (e) => {
    const o = pts.get(e.pointerId);
    if (!o) return;
    if (pts.size === 1) {
      th -= (e.clientX - o[0]) * 0.01;
      ph = clamp(ph + (e.clientY - o[1]) * 0.006, -0.1, 1.2);
    }
    pts.set(e.pointerId, [e.clientX, e.clientY]);
    if (pts.size === 2) {
      const [a, b] = [...pts.values()],
        d = Math.hypot(a[0] - b[0], a[1] - b[1]);
      if (pd) dist = clamp((dist * pd) / d, 5, 32);
      pd = d;
    }
  };
  cvs.onpointerup = cvs.onpointercancel = (e) => { pts.delete(e.pointerId); pd = 0; };
  cvs.onwheel = (e) => { dist = clamp(dist * (1 + e.deltaY * 0.001), 5, 32); };
  function resize() {
    R.setPixelRatio(Math.min(devicePixelRatio, 2));
    R.setSize(innerWidth, innerHeight);
    cam.aspect = innerWidth / innerHeight;
    cam.updateProjectionMatrix();
  }
  addEventListener("resize", resize);
  resize();
  setters.c(0);

  const hs = { x: 0, vx: 0, z: 0, vz: 0 };
  let prevY = 0, prevYaw = 0;
  function loop(ms) {
    raf = requestAnimationFrame(loop);
    const t = ms / 1000,
      dt = Math.min(0.05, t - last) || 0.016;
    last = t;
    const tg = PO[S.p][1](t),
      k = Math.min(1, dt * 9);
    for (let i = 0; i < 16; i++) cur[i] += ((tg[i] || 0) - cur[i]) * k;
    const c = ch;
    c.la.rotation.set(cur[0], 0, cur[1]);
    c.ra.rotation.set(cur[2], 0, cur[3]);
    c.ll.rotation.x = cur[4];
    c.rl.rotation.x = cur[5];
    bend(c.la.geo, Math.min(0, cur[12]));
    bend(c.ra.geo, Math.min(0, cur[13]));
    c.ll.foot.rotation.x = Math.max(0, cur[14]);
    bend(c.ll.geo, c.ll.foot.rotation.x);
    c.rl.foot.rotation.x = Math.max(0, cur[15]);
    bend(c.rl.geo, c.rl.foot.rotation.x);
    c.head.rotation.set(cur[6], cur[7], cur[8]);
    c.body.position.y = cur[9];
    c.body.rotation.x = cur[10];
    c.body.rotation.y = cur[11];
    if (S.spin) c.root.rotation.y += dt * 0.9;
    /* hair secondary motion (spring) */
    if (c.sway.length) {
      const vy = (cur[9] - prevY) / dt,
        vyaw = (cur[11] - prevYaw) / dt;
      prevY = cur[9];
      prevYaw = cur[11];
      const tx = clamp(-vy * 0.02 - cur[6] * 0.5 - cur[10] * 0.4, -0.7, 0.7),
        tz = clamp(-cur[8] * 0.9 - vyaw * 0.04, -0.7, 0.7);
      hs.vx += (70 * (tx - hs.x) - 8 * hs.vx) * dt;
      hs.x += hs.vx * dt;
      hs.vz += (70 * (tz - hs.z) - 8 * hs.vz) * dt;
      hs.z += hs.vz * dt;
      c.sway.forEach((s, i) => {
        s.g.rotation.x = (hs.x + 0.05 * sn(t * 2 + i)) * s.w;
        s.g.rotation.z = hs.z * s.w + 0.03 * sn(t * 1.7 + i * 2) * s.w;
      });
    }
    face(t);
    cam.position.set(dist * Math.sin(th) * Math.cos(ph), ty + dist * Math.sin(ph), dist * Math.cos(th) * Math.cos(ph));
    cam.lookAt(0, ty, 0);
    R.render(scene, cam);
  }
  raf = requestAnimationFrame(loop);

  return () => {
    cancelAnimationFrame(raf);
    removeEventListener("resize", resize);
    R.dispose();
    host.innerHTML = "";
    delete window.rig;
  };
}

import { useEffect, useMemo, useRef, useState } from 'react';
import { Showroom, ViewMode } from './engine/showroom';
import { CATALOG } from './engine/catalog';

const VIEWS: { id: ViewMode; label: string }[] = [
  { id: 'orbit', label: '3/4' }, { id: 'front', label: 'Front' }, { id: 'side', label: 'Side' },
  { id: 'rear', label: 'Rear' }, { id: 'top', label: 'Top' }, { id: 'cabin', label: 'Cabin' }, { id: 'driver', label: 'Driver' },
];

export default function App() {
  const host = useRef<HTMLDivElement>(null);
  const show = useRef<Showroom | null>(null);
  const [idx, setIdx] = useState(0);
  const [speed, setSpeed] = useState(0);
  const [steer, setSteer] = useState(0);
  const [left, setLeft] = useState(false);
  const [right, setRight] = useState(false);
  const [lights, setLights] = useState(false);
  const [view, setView] = useState<ViewMode>('orbit');
  const [auto, setAuto] = useState(false);
  const [q, setQ] = useState('');
  const [menu, setMenu] = useState(true);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const s = new Showroom(host.current!);
    show.current = s;
    (window as any).__s = s;
    (window as any).__cat = CATALOG;
    return () => { s.dispose(); };
  }, []);

  useEffect(() => {
    const s = show.current;
    if (!s) return;
    setBusy(true);
    const t = setTimeout(() => {
      try { s.load(CATALOG[idx].make()); } catch (e) { console.error('build failed', CATALOG[idx].name, e); }
      setBusy(false);
    }, 30);
    return () => clearTimeout(t);
  }, [idx]);

  useEffect(() => { const s = show.current; if (s) { s.targetSpeed = speed; s.state.steer = steer; s.state.doorL = left ? 1 : 0; s.state.doorR = right ? 1 : 0; s.state.lights = lights; s.autoRotate = auto; } }, [speed, steer, left, right, lights, auto]);
  useEffect(() => { show.current?.setView(view); }, [view]);
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).tagName === 'INPUT') return;
      if (e.key === 'ArrowRight') setIdx((i) => (i + 1) % CATALOG.length);
      if (e.key === 'ArrowLeft') setIdx((i) => (i + CATALOG.length - 1) % CATALOG.length);
      if (e.key === 'l') setLeft((v) => !v);
      if (e.key === 'r') setRight((v) => !v);
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, []);

  const cats = useMemo(() => {
    const m = new Map<string, typeof CATALOG>();
    CATALOG.filter((e) => e.name.toLowerCase().includes(q.toLowerCase()) || String(e.id) === q).forEach((e) => { if (!m.has(e.cat)) m.set(e.cat, []); m.get(e.cat)!.push(e); });
    return [...m.entries()];
  }, [q]);
  const cur = CATALOG[idx];
  const btn = (on: boolean) => `px-3 py-1.5 rounded-lg text-sm font-medium transition border ${on ? 'bg-cyan-500 text-black border-cyan-300' : 'bg-white/5 text-white border-white/15 hover:bg-white/15'}`;

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-black text-white select-none">
      <div ref={host} className="absolute inset-0" />
      {busy && <div className="absolute inset-0 grid place-items-center bg-black/40 text-lg pointer-events-none">Building {cur.name}…</div>}

      <div className="absolute top-3 left-3 right-3 flex items-start gap-3 pointer-events-none">
        <button onClick={() => setMenu((m) => !m)} className="pointer-events-auto px-3 py-2 rounded-lg bg-black/60 border border-white/15 backdrop-blur text-sm">☰ {menu ? 'Hide' : 'Garage'}</button>
        <div className="pointer-events-auto flex items-center gap-2 bg-black/60 border border-white/15 backdrop-blur rounded-xl px-3 py-2">
          <button onClick={() => setIdx((i) => (i + CATALOG.length - 1) % CATALOG.length)} className="px-2 text-xl hover:text-cyan-300">‹</button>
          <div className="text-center min-w-48">
            <div className="text-[11px] uppercase tracking-widest text-cyan-300">{cur.cat} · {cur.id}/{CATALOG.length}</div>
            <div className="text-lg font-semibold leading-tight">{cur.name}</div>
          </div>
          <button onClick={() => setIdx((i) => (i + 1) % CATALOG.length)} className="px-2 text-xl hover:text-cyan-300">›</button>
        </div>
        <div className="ml-auto pointer-events-auto bg-black/60 border border-white/15 backdrop-blur rounded-xl px-4 py-2 text-right">
          <div className="text-3xl font-bold tabular-nums leading-none">{speed}<span className="text-sm font-normal text-white/60 ml-1">km/h</span></div>
        </div>
      </div>

      {menu && (
        <div className="absolute top-16 left-3 bottom-40 w-64 bg-black/70 border border-white/15 backdrop-blur rounded-xl flex flex-col overflow-hidden">
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search 100 vehicles…" className="m-2 px-3 py-2 rounded-lg bg-white/10 outline-none text-sm placeholder:text-white/40" />
          <div className="overflow-y-auto px-2 pb-2 text-sm">
            {cats.map(([c, list]) => (
              <div key={c} className="mb-2">
                <div className="sticky top-0 bg-black/80 text-[11px] uppercase tracking-widest text-cyan-300 py-1">{c}</div>
                {list.map((e) => (
                  <button key={e.id} onClick={() => setIdx(e.id - 1)} className={`w-full text-left px-2 py-1 rounded flex gap-2 ${e.id - 1 === idx ? 'bg-cyan-500/30 text-white' : 'text-white/80 hover:bg-white/10'}`}>
                    <span className="w-6 text-white/40 tabular-nums">{e.id}</span><span className="truncate">{e.name}</span>
                  </button>
                ))}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="absolute bottom-3 left-3 right-3 bg-black/65 border border-white/15 backdrop-blur rounded-xl p-3 flex flex-wrap gap-x-6 gap-y-3 items-center justify-center">
        <div className="flex items-center gap-2">
          <span className="text-xs text-white/60 w-12">Speed</span>
          <input type="range" min={0} max={250} value={speed} onChange={(e) => setSpeed(+e.target.value)} className="w-48 accent-cyan-400" />
          <button onClick={() => setSpeed(0)} className={btn(false)}>Stop</button>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-white/60 w-12">Steer</span>
          <input type="range" min={-1} max={1} step={0.05} value={steer} onChange={(e) => setSteer(+e.target.value)} className="w-32 accent-cyan-400" />
        </div>
        <div className="flex gap-2">
          <button onClick={() => setLeft((v) => !v)} className={btn(left)}>Left door</button>
          <button onClick={() => setRight((v) => !v)} className={btn(right)}>Right door</button>
          <button onClick={() => { const v = !(left && right); setLeft(v); setRight(v); }} className={btn(left && right)}>Both</button>
          <button onClick={() => setLights((v) => !v)} className={btn(lights)}>Lights</button>
          <button onClick={() => setAuto((v) => !v)} className={btn(auto)}>Spin</button>
        </div>
        <div className="flex gap-1 flex-wrap">
          {VIEWS.map((v) => <button key={v.id} onClick={() => setView(v.id)} className={btn(view === v.id)}>{v.label}</button>)}
        </div>
      </div>
    </div>
  );
}

import * as THREE from 'three';
import { CarSpec, Ctx, Vehicle } from './types';
import { buildBody, DoorRig, DoorSpec, HoleSpec, WindowSpec, MB } from './loft';
import { makeMats, pchip, plateTexture, grilleTexture, lerp, clamp } from './util';
import { rbox, box, cyl, tube, at, add, makeWheel, makeMirror, makeHandle, makeExhaustTip } from './parts';
import { buildInterior } from './interior';
import { EXTRAS } from './extras';

const mirrorZ = <T extends THREE.Object3D>(o: T): T => { const c = o.clone() as T; c.scale.z = -1; return c; };

export function ringMesh(x0: number, x1: number, wOut: number, wIn: number, inX0: number, inX1: number, y: number, depth: number, mat: THREE.Material) {
  const sh = new THREE.Shape();
  sh.moveTo(x0, -wOut); sh.lineTo(x1, -wOut); sh.lineTo(x1, wOut); sh.lineTo(x0, wOut); sh.closePath();
  const h = new THREE.Path();
  h.moveTo(inX0, -wIn); h.lineTo(inX0, wIn); h.lineTo(inX1, wIn); h.lineTo(inX1, -wIn); h.closePath();
  sh.holes.push(h);
  const g = new THREE.ExtrudeGeometry(sh, { depth, bevelEnabled: true, bevelSize: 0.006, bevelThickness: 0.006, bevelSegments: 2 });
  g.rotateX(Math.PI / 2);
  const m = new THREE.Mesh(g, mat);
  m.position.y = y;
  m.castShadow = true;
  return m;
}

export function buildCar(spec: CarSpec): Vehicle {
  const v = new Vehicle();
  const m = makeMats(spec.color, spec.interior, { color2: spec.color2, matte: spec.matte, metal: spec.metal, trim2: spec.trim2 });
  v.mats = m;
  const L = spec.L;
  const xmin = -L / 2, xmax = L / 2;
  const halfW = spec.W / 2;
  const H = spec.H;
  const clr = spec.clr ?? 0.17;
  const fo = spec.fo ?? (L - spec.wb) * 0.46;
  const ro = L - spec.wb - fo;
  const axleF = xmax - fo, axleR = xmin + ro;
  const xCowl = xmax - spec.hoodLen;
  const xRoofF = xCowl - spec.screen;
  const xRoofR = xRoofF - spec.roofLen;
  const xRw = xRoofR - spec.rwRun;
  const tailH = spec.tailH ?? spec.deckH - 0.08;
  const beltH = spec.beltH;

  // ---- silhouette
  const raw: [number, number][] = [
    [xmin, tailH], [xmin + 0.05, spec.deckH], [xRw, spec.deckH], [xRoofR, H - 0.015], [(xRoofR + xRoofF) / 2, H + 0.006],
    [xRoofF, H - 0.015], [xCowl, spec.hoodH], [lerp(xCowl, xmax, 0.5), spec.hoodH - 0.3 * (spec.hoodH - spec.noseH)],
    [xmax - 0.06, spec.noseH + 0.025], [xmax, spec.noseH],
  ];
  const pts: [number, number][] = [];
  raw.forEach((p) => { if (p[0] >= xmin - 1e-6 && (!pts.length || p[0] > pts[pts.length - 1][0] + 0.03)) pts.push(p); });
  if (pts[pts.length - 1][0] < xmax - 1e-6) pts.push([xmax, spec.noseH]);
  const top = pchip(pts.map((p) => p[0]), pts.map((p) => p[1]));
  const a = Math.min(0.9, L * 0.18);
  const bot = pchip([xmin, xmin + a * 0.45, xmin + a, xmax - a, xmax - a * 0.4, xmax], [clr + 0.1, clr + 0.02, clr, clr, clr + 0.02, clr + 0.1]);
  const belt = pchip([xmin, xCowl, xmax], [beltH + 0.02, beltH, beltH - 0.03]);

  // ---- doors
  const dn = spec.doorsN ?? 4;
  const doors: DoorSpec[] = [];
  let quarterStart = xmin + 0.3;
  if (spec.doorsAt) doors.push(...spec.doorsAt);
  else if (dn > 0) {
    const fl = spec.doorLen ?? (dn === 2 ? 1.2 : 1.0);
    const RR = spec.rearR ?? spec.R;
    const fx1 = Math.min(xCowl - 0.14 + (spec.doorShift ?? 0), spec.wheels ? 1e9 : axleF - spec.R - 0.1);
    const fx0 = Math.max(fx1 - fl, dn === 2 && !spec.wheels ? axleR + RR + 0.1 : -1e9);
    for (const side of ['L', 'R'] as const) doors.push({ side, x0: fx0, x1: fx1, hinge: 'front', win: [fx0 + 0.12, fx1 - 0.05], winRows: spec.opts?.winRows });
    quarterStart = fx0 - 0.1;
    if (spec.opts?.sliding) {
      const sl = spec.opts.sliding as number;
      doors.push({ side: 'R', x0: fx0 - 0.05 - sl, x1: fx0 - 0.05, hinge: 'slide', win: spec.opts.slideWin === false ? null : [fx0 - sl + 0.1, fx0 - 0.15], winRows: spec.opts?.winRows });
      quarterStart = fx0 - sl - 0.15;
    }
    if (dn >= 4) {
      const rl = spec.rearDoorLen ?? 0.95;
      const rx1 = fx0, rx0 = Math.max(rx1 - rl, spec.wheels ? -1e9 : axleR + RR + 0.1);
      for (const side of ['L', 'R'] as const) doors.push({ side, x0: rx0, x1: rx1, hinge: spec.slideRear ? 'slide' : spec.rearHinge ? 'rear' : 'front', win: [rx0 + 0.17, rx1 - 0.12], winRows: spec.opts?.winRows });
      quarterStart = rx0 - 0.1;
    }
  }
  const qEnd = spec.quarterEnd ?? lerp(xRw, xRoofR, 0.5);
  const windows: WindowSpec[] = spec.windows ?? (quarterStart - Math.max(qEnd, xmin + 0.05) > 0.12 && spec.open !== 'bed' && spec.open !== 'convertible' ? [{ x0: Math.max(qEnd, xmin + 0.05), x1: quarterStart, rows: spec.opts?.winRows }] : []);
  const topGlass: [number, number][] = [];
  if (spec.frontGlass !== false && spec.open !== 'convertible') topGlass.push([xRoofF, xCowl]);
  if (spec.rearGlass !== false && xRoofR - Math.max(xRw, xmin + 0.05) > 0.08 && spec.open !== 'convertible' && spec.open !== 'bed') topGlass.push([Math.max(xRw, xmin + 0.05), xRoofR]);
  if (spec.open === 'bed') topGlass.push([Math.max(xRw, xmin + 0.05), xRoofR]);

  const bandT = spec.bandT ?? [0.07, 0.35, 0.7, 1.0];
  const iBelt = 17;
  const iBandEnd = iBelt + bandT.length;
  const holes: HoleSpec[] = [];
  if (spec.open === 'convertible') holes.push({ x0: spec.openX?.[0] ?? xRw + 0.1, x1: spec.openX?.[1] ?? xCowl - 0.02, rowFrom: iBelt + 1 });
  if (spec.open === 'bed') holes.push({ x0: spec.openX?.[0] ?? xmin + 0.12, x1: spec.openX?.[1] ?? xRw - 0.04, rowFrom: iBelt + 1 });
  if (spec.open === 'targa') holes.push({ x0: spec.openX?.[0] ?? xRoofR + 0.25, x1: spec.openX?.[1] ?? xRoofF - 0.05, rowFrom: iBandEnd + 2 });

  const wheelXs: { x: number; R: number; tw: number; steer: boolean }[] = spec.wheels
    ? spec.wheels.map((w) => ({ x: w.x, R: w.R ?? spec.R, tw: w.tw ?? spec.tw, steer: !!w.steer }))
    : [{ x: axleF, R: spec.R, tw: spec.tw, steer: true }, { x: axleR, R: spec.rearR ?? spec.R, tw: spec.rearTw ?? spec.tw, steer: false }];

  const body = buildBody({
    xmin, xmax, top, bottom: bot, belt, halfW,
    wMul: spec.hoodNarrow ? (x: number) => lerp(1, spec.hoodNarrow!, clamp((x - (xCowl - 0.2)) / 0.6, 0, 1)) : undefined, rl: spec.rl ?? 0.1, rs: spec.rs ?? 0.06, rr: spec.rr ?? 0.055,
    roofRatio: spec.roofRatio ?? 0.82, bulge: spec.bulge ?? 0.008, crown: spec.crown ?? 0.02, hoodCrown: spec.hoodCrown ?? 0.03,
    planN: spec.planN ?? 2.6, rfF: spec.rfF ?? 0.55, rfR: spec.rfR ?? 0.42, bandT, cabinH: Math.max(0.08, H - beltH),
    arches: wheelXs.filter((w, i) => !(spec.noArchRear && i > 0)).map((w) => ({ x: w.x, R: w.R })),
    doors, windows, topGlass, holes, cladding: spec.cladding ?? 0, roofTwoTone: spec.roofTwoTone, roofX: spec.roofX, M: m,
  });
  v.group.add(body.group);
  v.doors = body.doors;
  v.size = { L, W: spec.W, H };

  const floorY = clr + 0.14;
  const interior = new THREE.Group();
  v.group.add(interior);
  const steerX = xCowl - 0.68;
  const c: Ctx = {
    spec, m, body, v, g: v.group, xmin, xmax, halfW, H, xCowl, xRoofF, xRoofR, xRw, floorY, clr,
    steerX, seatX: steerX - 0.42, axleF, axleR, topAt: top, doors: body.doors, interior,
  };
  buildInterior(c);

  // ---- wheels & arches
  const wheelStyle = spec.wheel ?? 'multi';
  const rimMat = new THREE.MeshStandardMaterial({ color: spec.rimColor ?? '#c9ced4', metalness: 0.95, roughness: 0.18 });
  wheelXs.forEach((w, wi) => {
    for (const s of [-1, 1]) {
      const rimR = (w.R / spec.R) * spec.rimR;
      const zWall = body.wallZ(w.x);
      const zC = zWall - 0.028 - w.tw / 2;
      const hub = new THREE.Group();
      hub.position.set(w.x, w.R, s * zC);
      const wh = makeWheel(m, { R: w.R, tw: w.tw, rimR, style: wheelStyle, rimMat, caliper: spec.caliper, lugs: spec.lugs, whitewall: spec.whitewall });
      const spinG = new THREE.Group();
      const flipS = new THREE.Group();
      flipS.rotation.y = s < 0 ? Math.PI : 0;
      flipS.add(wh.spin);
      spinG.add(flipS);
      const flipF = new THREE.Group();
      flipF.rotation.y = s < 0 ? Math.PI : 0;
      flipF.add(wh.fixed);
      hub.add(spinG, flipF);
      v.group.add(hub);
      v.wheels.push({ steer: w.steer ? hub : null, spin: spinG, R: w.R, side: s });
      if (spec.noArchRear && wi > 0) continue;
      // arch dressing
      const zr = s * (zWall + 0.004);
      const paintRing = new THREE.Mesh(new THREE.RingGeometry(w.R + 0.04, w.R + 0.14, 56, 1, -0.17, Math.PI + 0.34), spec.cladding ? m.black : m.paint);
      paintRing.position.set(w.x, w.R, zr);
      const lip = new THREE.Mesh(new THREE.RingGeometry(w.R + 0.018, w.R + 0.042, 56, 1, -0.17, Math.PI + 0.34), m.black);
      lip.position.set(w.x, w.R, zr + s * 0.001);
      const inner = zC - w.tw / 2 - 0.05;
      const depth = zWall - inner;
      const tubG = new THREE.CylinderGeometry(w.R + 0.035, w.R + 0.035, depth, 48, 1, true, Math.PI / 2 - 0.2, Math.PI + 0.4);
      tubG.rotateX(Math.PI / 2);
      const tubM = new THREE.Mesh(tubG, m.under);
      tubM.position.set(w.x, w.R, s * (inner + depth / 2));
      const back = new THREE.Mesh(new THREE.CircleGeometry(w.R + 0.035, 40, 0, Math.PI), m.under);
      back.position.set(w.x, w.R, s * inner);
      add(v.group, paintRing, lip, tubM, back);
    }
  });

  // ---- lights, grille, plates
  const lampMat = new THREE.MeshStandardMaterial({ color: 0x07080a, metalness: 1, roughness: 0.25 });
  const lp = spec.lamp ?? { y0: spec.noseH - 0.22, y1: spec.noseH - 0.07, z0: halfW * 0.34, z1: halfW * 0.9 };
  const headG = new THREE.Group();
  if (spec.round) {
    const yc = (lp.y0 + lp.y1) / 2;
    const zc = (lp.z0 + lp.z1) / 2;
    const r = Math.min((lp.y1 - lp.y0) * 0.5, 0.11);
    const p = body.endPoint('front', zc, yc, 0.0);
    const bez = new THREE.Mesh(new THREE.TorusGeometry(r, r * 0.12, 12, 40), m.chrome);
    bez.rotation.y = Math.PI / 2;
    const dome = new THREE.Mesh(new THREE.SphereGeometry(r * 0.96, 28, 16), m.lens);
    dome.scale.x = 0.55;
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(r * 0.5, 20, 12), m.headLamp);
    bulb.scale.x = 0.5;
    const grp = new THREE.Group();
    grp.add(bez, dome, bulb);
    grp.position.copy(p);
    grp.position.x -= 0.02;
    headG.add(grp, mirrorZ(grp));
  } else {
    const housing = body.endPatch('front', lp.z0 - 0.02, lp.z1 + 0.02, lp.y0 - 0.015, lp.y1 + 0.01, 0.003, lampMat, 16, 6);
    const drl = body.endPatch('front', lp.z0 + 0.03, lp.z1 - 0.02, lp.y1 - 0.045, lp.y1 - 0.025, 0.008, m.headLamp, 16, 1);
    const lens = body.endPatch('front', lp.z0 - 0.02, lp.z1 + 0.02, lp.y0 - 0.015, lp.y1 + 0.01, 0.016, m.lens, 16, 6);
    const pc = body.endPoint('front', lerp(lp.z0, lp.z1, 0.38), (lp.y0 + lp.y1) / 2 - 0.015, 0.008);
    const proj = new THREE.Mesh(new THREE.SphereGeometry((lp.y1 - lp.y0) * 0.2, 20, 12), m.headLamp);
    proj.position.copy(pc);
    const projRing = new THREE.Mesh(new THREE.TorusGeometry((lp.y1 - lp.y0) * 0.22, 0.004, 8, 24), m.chrome);
    projRing.position.copy(pc);
    projRing.rotation.y = Math.PI / 2;
    const pc2 = body.endPoint('front', lerp(lp.z0, lp.z1, 0.72), (lp.y0 + lp.y1) / 2 - 0.015, 0.008);
    const proj2 = proj.clone();
    proj2.position.copy(pc2);
    proj2.scale.setScalar(0.75);
    const grp = new THREE.Group();
    grp.add(housing, drl, lens, proj, projRing, proj2);
    headG.add(grp, mirrorZ(grp));
  }
  v.group.add(headG);
  const tl = spec.tail ?? { y0: spec.deckH - 0.2, y1: spec.deckH - 0.04, z0: halfW * 0.4, z1: halfW * 0.93 };
  const tailG = new THREE.Group();
  {
    const t1 = body.endPatch('rear', tl.z0, tl.z1, tl.y0, tl.y1, 0.004, m.tailLamp, 14, 4);
    const t2 = body.endPatch('rear', tl.z0 - 0.01, tl.z1 + 0.01, tl.y0 - 0.01, tl.y1 + 0.01, 0.002, lampMat, 14, 4);
    const t3 = body.endPatch('rear', tl.z0, tl.z1, tl.y0, tl.y1, 0.012, new THREE.MeshPhysicalMaterial({ color: 0xff2030, transparent: true, opacity: 0.35, roughness: 0.05, depthWrite: false }), 14, 4);
    const grp = new THREE.Group();
    grp.add(t2, t1, t3);
    tailG.add(grp, mirrorZ(grp));
    if (tl.bar) {
      const bar = body.endPatch('rear', 0, tl.z0, (tl.y0 + tl.y1) / 2 - 0.012, (tl.y0 + tl.y1) / 2 + 0.012, 0.006, m.tailLamp, 6, 1);
      tailG.add(bar, mirrorZ(bar));
    }
  }
  if (!spec.noRear) v.group.add(tailG);
  if (spec.grille !== 'none') {
    const gz = spec.grilleW ?? halfW * 0.34;
    const gy = spec.grilleY ?? [spec.noseH - 0.27, spec.noseH - 0.07];
    const gm = new THREE.MeshStandardMaterial({ map: grilleTexture(spec.grille ?? 'honey'), metalness: 0.7, roughness: 0.45, side: THREE.DoubleSide });
    const gp = body.endPatch('front', 0, gz, gy[0], gy[1], 0.005, gm, 12, 4);
    const gf = body.endPatch('front', 0, gz + 0.025, gy[0] - 0.022, gy[1] + 0.022, 0.002, spec.chromeGrille ? m.chrome : m.black, 12, 4);
    const gg = new THREE.Group();
    gg.add(gf, gp);
    v.group.add(gg, mirrorZ(gg));
    const badge = new THREE.Mesh(new THREE.SphereGeometry(0.03, 20, 12), m.chrome);
    badge.scale.set(0.2, 1, 1.3);
    badge.position.copy(body.endPoint('front', 0, gy[1] - 0.005, 0.008));
    v.group.add(badge);
    if (spec.noseH - clr > 0.46) {
      const li = new THREE.MeshStandardMaterial({ map: grilleTexture('mesh'), metalness: 0.5, roughness: 0.5, side: THREE.DoubleSide });
      const lo = body.endPatch('front', 0, halfW * 0.6, clr + 0.07, Math.min(clr + 0.2, gy[0] - 0.07), 0.004, li, 16, 3);
      const lg = new THREE.Group();
      lg.add(lo);
      v.group.add(lg, mirrorZ(lg));
    }
  }
  // plates
  const plateMat = (face: number) => {
    const mats = Array.from({ length: 6 }, () => new THREE.MeshStandardMaterial({ color: 0xdddddd, roughness: 0.5 }));
    mats[face] = new THREE.MeshStandardMaterial({ map: plateTexture(spec.plate ?? 'VEH-' + (spec.name.length * 37 % 900 + 100)), roughness: 0.4 });
    return mats;
  };
  const rp = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.11, 0.52), plateMat(1));
  rp.position.copy(body.endPoint('rear', 0, lerp(bot(xmin) + 0.04, tailH - 0.06, 0.36), 0.0)).add(new THREE.Vector3(-0.004, 0, 0));
  rp.position.z = 0;
  const fp = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.11, 0.52), plateMat(0));
  fp.position.set(xmax + 0.002, clr + 0.2, 0);
  if (!spec.noRear) v.group.add(rp);
  if (spec.noseH - clr > 0.4) v.group.add(fp);

  // ---- doors: handles, mirrors, interior trim
  const doorWorld = new THREE.Vector3();
  body.doors.forEach((d, i) => {
    const s = d.side;
    const spc = d.spec;
    const xmid = (spc.x0 + spc.x1) / 2;
    const handleX = spc.hinge === 'front' ? spc.x0 + 0.17 : spc.x1 - 0.17;
    const hy = beltH - 0.1;
    const handle = makeHandle(m, m.paint);
    handle.position.set(handleX - d.px, hy, body.zAt(handleX, hy) * s + s * 0.002 - d.pz);
    if (s < 0) handle.scale.z = -1;
    d.pivot.add(handle);
    // interior fixtures
    const zi = -s * 0.1;
    const arm = rbox(Math.min(0.62, spc.x1 - spc.x0 - 0.2), 0.065, 0.075, 0.025, m.trim);
    arm.position.set(xmid - d.px, beltH - 0.15, zi);
    const pull = tube([new THREE.Vector3(-0.1, 0, 0.0), new THREE.Vector3(-0.05, 0.035, -s * 0.025), new THREE.Vector3(0.1, 0.035, -s * 0.025), new THREE.Vector3(0.14, 0, 0)].map((p) => p.add(new THREE.Vector3(xmid - d.px, beltH - 0.2, zi))), 0.009, m.chrome, false, 20);
    const sw = rbox(0.14, 0.014, 0.06, 0.006, m.black);
    sw.position.set(xmid - d.px - (spc.hinge === 'front' ? -0.12 : 0.12), beltH - 0.115, zi);
    const spk = cyl(0.07, 0.07, 0.014, m.black, 'z', 28);
    spk.position.set(xmid - d.px, beltH - 0.45, -s * 0.085);
    const pocket = rbox(0.4, 0.14, 0.05, 0.02, m.trim2);
    pocket.position.set(xmid - d.px, beltH - 0.58, zi);
    const lockPin = cyl(0.005, 0.005, 0.05, m.black, 'y', 6);
    lockPin.position.set(xmid - d.px + (spc.hinge === 'front' ? -0.25 : 0.25), beltH - 0.04, -s * 0.07);
    const grabNone = new THREE.Group();
    add(d.pivot, arm, pull, sw, spk, pocket, lockPin, grabNone);
    // mirror on front doors
    if (i < 2 || (spc.hinge === 'front' && spc.x1 > xCowl - 0.5 && !spec.noMirror)) {
      if (spc.x1 > xCowl - 0.6) {
        const mir = makeMirror(m, m.paint, !!spec.heavy);
        const mx = spc.x1 - 0.12;
        const my = beltH + 0.07;
        mir.position.set(mx - d.px, my, s * (body.zAt(mx, beltH) + 0.0) - d.pz);
        if (s < 0) mir.scale.z = -1;
        d.pivot.add(mir);
      }
    }
    doorWorld.set(0, 0, 0);
  });

  // ---- convertible / bed / targa details
  const sec0 = body.sec((xRw + xCowl) / 2);
  const wS = sec0.w - (spec.rs ?? 0.06);
  if (spec.open === 'convertible') {
    const hx0 = holes[0].x0, hx1 = holes[0].x1;
    v.group.add(ringMesh(hx0, hx1, wS + 0.008, wS * 0.76, hx0 + 0.04, hx1 - 0.14, beltH + 0.006, 0.03, m.paint));
    for (const sg of [-1, 1]) {
      const wall = rbox(hx1 - hx0 - 0.1, beltH - floorY - 0.05, 0.03, 0.01, m.trim, 1);
      wall.position.set((hx0 + hx1) / 2 - 0.05, floorY + (beltH - floorY) / 2 - 0.02, sg * wS * 0.74);
      v.group.add(wall);
    }
    const bulk = rbox(0.12, 0.5, wS * 1.5, 0.05, m.trim);
    bulk.position.set(hx0 + 0.02, beltH - 0.06, 0);
    v.group.add(bulk);
    // windscreen
    const wsH = spec.opts?.wsH ?? 0.3;
    const wsRun = spec.opts?.wsRun ?? 0.26;
    const xb = xCowl - 0.02, xt = xb - wsRun;
    const yb = beltH + 0.01;
    const wb2 = wS * 0.96, wt = wS * 0.84;
    const gm = new MB();
    const q = [gm.v(xb, yb, -wb2), gm.v(xb, yb, wb2), gm.v(xt, yb + wsH, wt), gm.v(xt, yb + wsH, -wt)];
    gm.q(q[0], q[1], q[2], q[3], 'g');
    const wsGlass = gm.build({ g: m.glass }, false);
    v.group.add(wsGlass);
    const frame = (p: number[][], r = 0.012) => tube(p.map((q2) => new THREE.Vector3(q2[0], q2[1], q2[2])), r, m.black, false, 12);
    v.group.add(frame([[xb, yb, wb2], [xt, yb + wsH, wt]]), frame([[xb, yb, -wb2], [xt, yb + wsH, -wt]]), frame([[xt, yb + wsH, -wt], [xt, yb + wsH, wt]], 0.016));
    if (spec.opts?.rollBars) for (const sg of [-1, 1]) {
      const rb = cyl(0.03, 0.03, 0.4, m.chrome, 'y', 16);
      rb.position.set(hx0 + 0.25, beltH + 0.18, sg * 0.3);
      v.group.add(rb);
    }
  }
  if (spec.open === 'bed') {
    const hx0 = holes[0].x0, hx1 = holes[0].x1;
    const bedFloor = spec.opts?.bedFloor ?? beltH - 0.32;
    v.group.add(ringMesh(hx0, hx1, wS + 0.008, wS - 0.075, hx0 + 0.06, hx1 - 0.06, beltH + 0.012, 0.035, m.black));
    const floor = rbox(hx1 - hx0, 0.05, 2 * wS - 0.1, 0.01, m.black, 1);
    floor.position.set((hx0 + hx1) / 2, bedFloor, 0);
    v.group.add(floor);
    for (let i = 0; i < 9; i++) {
      const rib = box(hx1 - hx0 - 0.1, 0.02, 0.05, m.black);
      rib.position.set((hx0 + hx1) / 2, bedFloor + 0.03, -wS + 0.18 + (i * (2 * wS - 0.36)) / 8);
      v.group.add(rib);
    }
    for (const sg of [-1, 1]) {
      const well = rbox(0.75, 0.22, 0.2, 0.06, m.black);
      well.position.set(axleR, bedFloor + 0.13, sg * (wS - 0.12));
      v.group.add(well);
      const rail = rbox(hx1 - hx0, 0.05, 0.04, 0.015, m.chrome);
      rail.position.set((hx0 + hx1) / 2, beltH - 0.1, sg * (wS - 0.06));
      v.group.add(rail);
    }
    for (const sg of [-1, 1]) for (const xx of [hx0 + 0.15, hx1 - 0.15]) {
      const hook = cyl(0.012, 0.012, 0.05, m.steel, 'y', 8);
      hook.position.set(xx, beltH - 0.15 - 0.15, sg * (wS - 0.025));
      v.group.add(hook);
    }
  }

  // ---- undercarriage
  const zA = body.wallZ(axleF) - 0.1;
  if (!spec.noUnder) {
  for (const [ax, R] of [[axleF, wheelXs[0].R], [axleR, wheelXs[wheelXs.length - 1].R]] as [number, number][]) {
    const axle = cyl(0.028, 0.028, 2 * zA, m.darkMetal, 'z', 14);
    axle.position.set(ax, R, 0);
    v.group.add(axle);
  }
  const diff = rbox(0.3, 0.2, 0.34, 0.06, m.darkMetal);
  diff.position.set(axleR, wheelXs[wheelXs.length - 1].R, 0);
  v.group.add(diff);
  const shaft = cyl(0.04, 0.04, axleF - axleR - 0.5, m.darkMetal, 'x', 12);
  shaft.position.set((axleF + axleR) / 2, clr + 0.06, 0);
  v.group.add(shaft);
  const exX = -spec.W * 0.2;
  const muffler = cyl(0.09, 0.09, 0.75, m.steel, 'x', 20);
  muffler.position.set(axleR - 0.55, clr + 0.03, exX);
  const pipe = cyl(0.035, 0.035, axleF - axleR, m.steel, 'x', 12);
  pipe.position.set((axleF + axleR) / 2 - 0.3, clr + 0.03, exX);
  v.group.add(muffler, pipe);
  const tipCount = spec.opts?.quadTips ? 4 : 2;
  for (let k = 0; k < tipCount; k++) {
    const t = makeExhaustTip(m, tipCount === 4 ? 0.04 : 0.043, 0.12);
    const zz = tipCount === 4 ? [-0.42, -0.3, 0.3, 0.42][k] * halfW / 0.9 : (k ? 1 : -1) * 0.42 * halfW / 0.9;
    t.position.set(xmin + 0.01, clr + 0.07, zz);
    v.group.add(t);
    const mp = cyl(0.02, 0.02, 0.6, m.steel, 'x', 8);
    mp.position.set(xmin + 0.5, clr + 0.07, zz);
    v.group.add(mp);
  }

  }
  // ---- headlight beams
  for (const sg of [-1, 1]) {
    const sp = new THREE.SpotLight(0xfff0d0, 90, 22, 0.55, 0.7, 1.4);
    sp.position.set(xmax - 0.25, spec.noseH - 0.12, sg * halfW * 0.6);
    sp.target.position.set(xmax + 10, 0.2, sg * halfW * 0.6);
    sp.visible = false;
    v.group.add(sp, sp.target);
    v.lightObjs.push(sp);
  }
  v.lightMats = { head: [m.headLamp], tail: [m.tailLamp], amber: [m.amber] };

  // ---- extras
  (spec.extras ?? []).forEach((name) => {
    const [fn, arg] = name.split(':');
    if (EXTRAS[fn]) EXTRAS[fn](c, arg);
    else console.warn('missing extra', fn);
  });

  v.group.traverse((o) => { if ((o as THREE.Mesh).isMesh) { o.castShadow = true; } });
  return v;
}

export { clamp };
export type { DoorRig };

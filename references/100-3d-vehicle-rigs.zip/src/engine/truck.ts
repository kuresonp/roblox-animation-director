import * as THREE from 'three';
import { CarSpec, Vehicle } from './types';
import { buildCar } from './carBuilder';
import { Mats, canvasTex } from './util';
import { rbox, box, cyl, tube, at, add, makeWheel } from './parts';

const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
const std = (c: number | string, r = 0.5, m = 0) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, side: THREE.DoubleSide });

function ribTex(color: string, rib = '#00000022', n = 28) {
  return canvasTex(512, 256, (g, w, h) => {
    g.fillStyle = color; g.fillRect(0, 0, w, h);
    g.fillStyle = rib;
    for (let i = 0; i < n; i++) g.fillRect((i * w) / n, 0, 3, h);
    g.fillStyle = '#ffffff18'; g.fillRect(0, 0, w, 6);
  }, [1, 1]);
}
function shutterTex(frame = '#8d1111') {
  return canvasTex(256, 256, (g, w, h) => {
    g.fillStyle = frame; g.fillRect(0, 0, w, h);
    g.fillStyle = '#b8bcc2'; g.fillRect(10, 10, w - 20, h - 20);
    g.fillStyle = '#8c9096';
    for (let y = 14; y < h - 10; y += 10) g.fillRect(10, y, w - 20, 3);
    g.fillStyle = '#222'; g.fillRect(w / 2 - 20, h - 28, 40, 6);
  });
}

export function buildTruck(spec: CarSpec, cargoBuilder?: (s: CarSpec) => Vehicle): Vehicle {
  const cabSpec: CarSpec = { ...spec, kind: 'car', noRear: true, noUnder: true, heavy: true, wheels: [{ x: spec.L / 2 - (spec.fo ?? 0.6), steer: true }], extras: [...(spec.extras ?? [])] };
  const v = buildCar(cabSpec);
  const m = v.mats;
  const g = v.group;
  const o = spec.opts ?? {};
  const xmin = -spec.L / 2, xmax = spec.L / 2;
  const frameH = spec.frameH ?? 0.95;
  const axleF = xmax - (spec.fo ?? 0.6);
  const W = o.bodyW ?? 2.5;
  const yb = frameH + 0.14;
  const len = spec.rearLen ?? 5;
  const x0 = xmin - 0.14;
  const xEnd = x0 - len;
  const rimMat = new THREE.MeshStandardMaterial({ color: '#c8ccd2', metalness: 0.9, roughness: 0.3 });
  const body2 = spec.color2 ?? '#e8e8e8';
  const bodyMat = new THREE.MeshStandardMaterial({ color: body2, roughness: 0.35, metalness: 0.3, side: THREE.DoubleSide });

  // ---- chassis
  for (const s of [-1, 1]) {
    const rail = rbox(xmax - xEnd - 0.4, 0.22, 0.12, 0.02, m.black);
    at(rail, (xmax + xEnd) / 2 - 0.1, frameH, s * 0.55);
    g.add(rail);
  }
  for (let x = xEnd + 0.4; x < xmax - 0.4; x += 0.9) { const cm = box(0.1, 0.12, 1.1, m.black); at(cm, x, frameH, 0); g.add(cm); }
  const bump = rbox(0.14, 0.2, spec.W * 0.96, 0.05, m.chrome);
  at(bump, xmax + 0.05, 0.55, 0);
  const bump2 = rbox(0.1, 0.16, W * 0.9, 0.03, m.black);
  at(bump2, xEnd - 0.05, frameH - 0.15, 0);
  g.add(bump, bump2);
  const axles: number[] = (spec.axles ?? [4.2]).map((d) => axleF - d);
  const R = spec.R, tw = spec.tw;
  const pair = (x: number, zc: number, steer: boolean, regUp: boolean) => {
    for (const s of [-1, 1]) {
      const hub = new THREE.Group();
      hub.position.set(x, R, s * zc);
      const w = makeWheel(m, { R, tw, rimR: spec.rimR, style: 'truck', rimMat, brake: true, caliper: '#555' });
      const spinG = new THREE.Group(); const fl = new THREE.Group(); fl.rotation.y = s < 0 ? Math.PI : 0; fl.add(w.spin); spinG.add(fl);
      hub.add(spinG);
      g.add(hub);
      if (regUp) v.wheels.push({ steer: steer ? hub : null, spin: spinG, R, side: s });
    }
  };
  axles.forEach((x) => {
    const dual = spec.opts?.dual !== false;
    pair(x, o.zr ?? 1.0, false, true);
    if (dual) pair(x, (o.zr ?? 1.0) - 0.36, false, true);
    const ax = cyl(0.07, 0.07, 2.0, m.darkMetal, 'z', 14); at(ax, x, R, 0); g.add(ax);
    const dif = rbox(0.5, 0.4, 0.5, 0.12, m.darkMetal); at(dif, x, R, 0); g.add(dif);
    for (const s of [-1, 1]) {
      const sp = rbox(1.1, 0.07, 0.1, 0.02, m.darkMetal); at(sp, x, R + 0.3, s * 0.6); g.add(sp);
      const guard = new THREE.Mesh(new THREE.CylinderGeometry(R + 0.12, R + 0.12, 0.62, 28, 1, true, Math.PI / 2 - 0.8, Math.PI + 1.6), m.black);
      guard.rotation.x = Math.PI / 2; guard.position.set(x, R, s * 0.86); g.add(guard);
      const flap = box(0.03, 0.4, 0.5, m.black); at(flap, x - R - 0.22, 0.4, s * 0.86); g.add(flap);
    }
  });
  // fuel tanks / air tanks
  const tx = (axleF + axles[0]) / 2 + 0.2;
  for (const s of [-1]) { const t = cyl(0.3, 0.3, 1.2, m.steel, 'x', 28); at(t, tx, frameH - 0.18, s * 0.95); g.add(t); const st = box(0.5, 0.04, 0.04, m.black); at(st, tx, frameH - 0.18, s * 0.95); g.add(st); }
  const bat = rbox(0.5, 0.3, 0.3, 0.03, m.black); at(bat, tx, frameH - 0.15, 0.92); g.add(bat);
  if (o.stacks) for (const s of [-1, 1]) { const st = cyl(0.07, 0.07, 2.6, m.chrome, 'y', 16); at(st, xmin - 0.08, 2.0, s * 1.0); g.add(st); }
  // rear lights
  for (const s of [-1, 1]) { const l = box(0.04, 0.16, 0.3, m.tailLamp); at(l, xEnd - 0.02, frameH + 0.35, s * (W / 2 - 0.2)); g.add(l); }
  v.lightMats.tail.push(m.tailLamp);

  // ---- rear modules
  const mod = spec.truck ?? 'box';
  const mid = (x0 + xEnd) / 2;
  const sideMud = () => { };
  void sideMud;
  const walls = (h: number, thick = 0.08, mat: THREE.Material = bodyMat) => {
    for (const s of [-1, 1]) { const w = rbox(len, h, thick, 0.02, mat); at(w, mid, yb + h / 2, s * (W / 2 - thick / 2)); g.add(w); }
  };
  const tilt = (pivot: THREE.Group, max: number, pivotX: number) => {
    pivot.position.set(pivotX, yb, 0);
    g.add(pivot);
    let cur = 0;
    v.anims.push((dt, s) => { const tg = (s.doorL + s.doorR) / 2; cur += (tg - cur) * Math.min(1, dt * 1.5); pivot.rotation.z = cur * max; });
  };
  if (mod === 'box' || mod === 'reefer') {
    const h = o.boxH ?? 2.4;
    const mat = new THREE.MeshStandardMaterial({ map: ribTex(body2), roughness: 0.4, metalness: 0.2 });
    const bx = rbox(len, h, W, 0.05, mat); at(bx, mid, yb + h / 2 + 0.12, 0); g.add(bx);
    const base = rbox(len, 0.2, W - 0.1, 0.03, m.black); at(base, mid, yb + 0.05, 0); g.add(base);
    for (const s of [-1, 1]) { const e = box(0.05, h - 0.1, 0.04, m.chrome); at(e, xEnd + 0.02, yb + h / 2 + 0.12, s * (W / 2 - 0.02)); g.add(e); }
    const seam = box(0.02, h - 0.2, 0.02, m.black); at(seam, xEnd - 0.005, yb + h / 2 + 0.12, 0); g.add(seam);
    for (const k of [0.3, 0.7]) { const hd = box(0.03, 0.9, 0.04, m.chrome); at(hd, xEnd - 0.02, yb + 1.0, (k - 0.5) * W * 0.9); g.add(hd); }
    if (mod === 'reefer') {
      const u = rbox(0.45, 0.9, W * 0.7, 0.06, m.white); at(u, x0 + 0.15, yb + h - 0.25, 0); g.add(u);
      const gr = box(0.02, 0.5, W * 0.5, m.black); at(gr, x0 + 0.38, yb + h - 0.25, 0); g.add(gr);
      const unit = std(0x44ccff, 0.3, 0); const fr = cyl(0.25, 0.25, 0.02, m.black, 'x', 24); at(fr, x0 + 0.385, yb + h - 0.15, 0); g.add(fr); void unit;
    }
  } else if (mod === 'flatbed') {
    const deck = rbox(len, 0.16, W, 0.03, std('#8a6a43', 0.85)); at(deck, mid, yb + 0.08, 0); g.add(deck);
    const hb = rbox(0.12, 1.1, W, 0.03, m.darkMetal); at(hb, x0 - 0.05, yb + 0.6, 0); g.add(hb);
    for (const s of [-1, 1]) {
      const rail = rbox(len, 0.1, 0.07, 0.02, m.darkMetal); at(rail, mid, yb + 0.02, s * (W / 2 + 0.01)); g.add(rail);
      for (let x = x0 - 0.4; x > xEnd + 0.2; x -= 0.9) { const st = box(0.06, 0.5, 0.06, m.darkMetal); at(st, x, yb + 0.35, s * (W / 2 - 0.03)); g.add(st); }
    }
    const cols = [0xb77b3d, 0x6b8fb3, 0xc9b27a];
    for (let i = 0; i < 4; i++) { const c = rbox(1.1, 0.9, 1.0, 0.04, std(cols[i % 3], 0.8)); at(c, x0 - 1.0 - i * 1.15, yb + 0.6, (i % 2 ? 0.55 : -0.55)); g.add(c); }
  } else if (mod === 'dump') {
    const piv = new THREE.Group();
    const bedLen = len - 0.2;
    const px = xEnd + 0.1;
    const mat = bodyMat;
    const cx = (x0 - px) / 2 - 0.05;
    const fl = rbox(bedLen, 0.12, W, 0.03, mat); at(fl, cx, 0.12, 0);
    const fw = rbox(0.12, 1.6, W, 0.03, mat); at(fw, cx + bedLen / 2 - 0.06, 0.85, 0);
    const can = rbox(0.9, 0.08, W * 0.96, 0.02, mat); at(can, cx + bedLen / 2 + 0.2, 1.65, 0); can.rotation.z = 0.25;
    const tg = rbox(0.1, 1.0, W, 0.03, mat); at(tg, cx - bedLen / 2 + 0.05, 0.65, 0);
    add(piv, fl, fw, can, tg);
    for (const s of [-1, 1]) { const w = rbox(bedLen, 1.05, 0.1, 0.03, mat); at(w, cx, 0.65, s * (W / 2 - 0.05)); piv.add(w); const rib = box(bedLen, 0.06, 0.05, m.darkMetal); at(rib, cx, 1.18, s * (W / 2)); piv.add(rib); }
    tilt(piv, 0.75, px);
    piv.position.x = px; 
    piv.children.forEach((c) => (c.position.x += bedLen / 2 + 0.0 - cx + (cx - cx)));
    const ram = cyl(0.07, 0.07, 1.4, m.chrome, 'y', 12); at(ram, x0 - 1.6, yb + 0.7, 0); ram.rotation.z = 0.0; g.add(ram);
  } else if (mod === 'tanker') {
    const r = 1.05;
    const cap = new THREE.CapsuleGeometry(r, len - 2 * r - 0.1, 12, 40);
    cap.rotateZ(Math.PI / 2);
    const tk = new THREE.Mesh(cap, std('#cfd5db', 0.18, 1)); tk.scale.set(1, 1, 1.12); tk.castShadow = true;
    at(tk, mid, yb + r + 0.15, 0); g.add(tk);
    for (let i = 1; i < 5; i++) { const ring = new THREE.Mesh(new THREE.TorusGeometry(r + 0.01, 0.025, 8, 40), m.steel); ring.rotation.y = Math.PI / 2; ring.scale.set(1.12, 1, 1); ring.position.set(xEnd + (len * i) / 5, yb + r + 0.15, 0); ring.rotation.set(0, Math.PI / 2, 0); ring.scale.set(1, 1, 1); g.add(ring); }
    for (let i = 0; i < 3; i++) { const mh = cyl(0.26, 0.28, 0.14, m.steel, 'y', 20); at(mh, x0 - 1.0 - i * 1.6, yb + 2.3 + 0.02, 0); g.add(mh); }
    const walk = rbox(len - 0.8, 0.03, 0.4, 0.01, m.darkMetal); at(walk, mid, yb + 2.33, 0); g.add(walk);
    const vb = rbox(0.4, 0.6, 1.0, 0.04, m.darkMetal); at(vb, xEnd + 0.1, yb + 0.5, 0); g.add(vb);
    for (const s of [-1, 1]) { const l = cyl(0.04, 0.04, 2.0, m.steel, 'y', 8); at(l, xEnd - 0.1, yb + 1.3, s * 0.12); g.add(l); }
    const sk = rbox(len - 0.5, 0.12, W - 0.2, 0.04, m.black); at(sk, mid, yb + 0.12, 0); g.add(sk);
  } else if (mod === 'mixer') {
    const Rd = 1.12, Ld = len - 0.3;
    const pts: THREE.Vector2[] = [];
    for (let i = 0; i <= 10; i++) { const a = (i / 10) * Math.PI / 2; pts.push(new THREE.Vector2(Math.sin(a) * Rd * 0.98, -Ld / 2 + (1 - Math.cos(a)) * 0.9)); }
    pts.push(new THREE.Vector2(Rd, Ld / 2 - 1.3), new THREE.Vector2(Rd * 0.55, Ld / 2), new THREE.Vector2(Rd * 0.5, Ld / 2));
    const dg = new THREE.LatheGeometry(pts, 48); dg.rotateZ(-Math.PI / 2); dg.scale(-1, 1, 1);
    const drum = new THREE.Group();
    const dm = new THREE.Mesh(dg, std('#e86a10', 0.4, 0.3)); dm.castShadow = true;
    drum.add(dm);
    const hp: THREE.Vector3[] = [];
    for (let i = 0; i <= 80; i++) { const t = i / 80; const a = t * Math.PI * 2 * 3.2; const x = -Ld / 2 + 0.9 + t * (Ld - 2.4); hp.push(V(x, Math.cos(a) * (Rd + 0.015), Math.sin(a) * (Rd + 0.015))); }
    drum.add(tube(hp, 0.05, std('#f4f4f4', 0.4), false, 160));
    const pivot = new THREE.Group();
    pivot.add(drum);
    at(pivot, mid + 0.1, yb + Rd + 0.6, 0);
    pivot.rotation.z = -0.2;
    g.add(pivot);
    v.anims.push((dt, s) => { drum.rotation.x += dt * (0.7 + s.speed * 0.05); });
    const ped = rbox(1.0, 0.8, W - 0.5, 0.05, m.darkMetal); at(ped, xEnd + 1.0, yb + 0.5, 0); g.add(ped);
    const ped2 = rbox(0.5, 0.5, W - 0.5, 0.05, m.darkMetal); at(ped2, x0 - 0.7, yb + 0.5, 0); g.add(ped2);
    const chute = rbox(1.4, 0.1, 0.5, 0.04, std('#c9ccd0', 0.4, 0.8)); at(chute, xEnd - 0.2, yb + 1.1, 0); chute.rotation.z = -0.45; g.add(chute);
    const tank = cyl(0.3, 0.3, 1.0, m.white, 'z', 20); at(tank, x0 - 0.5, yb + 1.3, 0); g.add(tank);
  } else if (mod === 'carrier') {
    const frame = (x: number, y: number) => { for (const s of [-1, 1]) { const p = box(0.08, y, 0.08, m.darkMetal); at(p, x, yb + y / 2, s * (W / 2 - 0.05)); g.add(p); } };
    for (let x = x0 - 0.1; x > xEnd; x -= 2.4) frame(x, 3.1);
    for (const lvl of [0.35, 2.5]) {
      const dk = rbox(len, 0.08, W - 0.2, 0.02, m.steel); at(dk, mid, yb + lvl, 0); g.add(dk);
      for (const s of [-1, 1]) { const rl = rbox(len, 0.05, 0.05, 0.01, m.darkMetal); at(rl, mid, yb + lvl + 0.35, s * (W / 2 - 0.1)); g.add(rl); }
    }
    const ramp = rbox(1.8, 0.06, W - 0.4, 0.02, m.steel); at(ramp, xEnd - 0.7, yb + 1.4, 0); ramp.rotation.z = 0.45; g.add(ramp);
    const cs = (spec.opts?.cargoSpecs ?? []) as CarSpec[];
    if (cargoBuilder) cs.forEach((c, i) => {
      const cv = cargoBuilder(c);
      const k = 0.95;
      cv.group.scale.setScalar(k);
      cv.group.position.set(x0 - 2.4 - (i % 2) * 4.3, yb + (i < 2 ? 0.45 : 2.6), 0);
      cv.group.position.y = yb + (i < 2 ? 0.4 : 2.55);
      g.add(cv.group);
    });
  } else if (mod === 'logging') {
    for (let k = 0; k < 2; k++) for (const s of [-1, 1]) {
      const x = x0 - 0.8 - k * (len - 1.6);
      const bk = rbox(0.25, 0.15, 0.1, 0.02, m.darkMetal); at(bk, x, yb + 0.1, s * 1.1); g.add(bk);
      const up = rbox(0.12, 2.5, 0.12, 0.02, m.darkMetal); at(up, x, yb + 1.3, s * 1.2); g.add(up);
    }
    const bunk = rbox(0.2, 0.14, W, 0.03, m.darkMetal);
    for (let k = 0; k < 2; k++) { const b = bunk.clone(); b.position.set(x0 - 0.8 - k * (len - 1.6), yb + 0.12, 0); g.add(b); }
    const bark = new THREE.MeshStandardMaterial({ map: canvasTex(128, 128, (c, w, h) => { c.fillStyle = '#5a3d27'; c.fillRect(0, 0, w, h); for (let i = 0; i < 160; i++) { c.fillStyle = `rgba(${20 + Math.random() * 40},${12 + Math.random() * 20},8,0.6)`; c.fillRect(Math.random() * w, Math.random() * h, 3, 14 + Math.random() * 20); } }, [4, 1]), roughness: 1 });
    const endMat = std('#d9b383', 0.8);
    const layout = [[-0.55, 0.45], [0.55, 0.45], [0, 1.15], [-0.55 - 0.5, 0.35], [1.05, 0.35]];
    layout.forEach(([z, y], i) => {
      const r = 0.34 + (i % 3) * 0.03;
      const l = len - 0.6 + (i % 2) * 0.35;
      const lg = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 1.05, l, 24), [bark, endMat, endMat]);
      lg.rotation.z = Math.PI / 2; lg.castShadow = true;
      lg.position.set(mid + (i % 2) * 0.1, yb + 0.55 + y + (i === 3 || i === 4 ? -0.05 : 0.05), z);
      g.add(lg);
    });
    for (const k of [0.25, 0.75]) for (const s of [-1, 1]) { const ch = tube([V(x0 - 0.8 - k * (len - 1.6), yb + 1.8, s * 1.2), V(x0 - 0.8 - k * (len - 1.6), yb + 1.8, 0)], 0.015, m.darkMetal, false, 4); g.add(ch); }
  } else if (mod === 'fire') {
    const h = 2.0;
    const body = rbox(len, h, W, 0.07, m.paint); at(body, mid, yb + h / 2 + 0.1, 0); g.add(body);
    const st = new THREE.MeshStandardMaterial({ map: shutterTex(spec.color), roughness: 0.5, metalness: 0.4 });
    for (const s of [-1, 1]) for (let i = 0; i < 3; i++) {
      const pw = (len - 0.8) / 3 - 0.1;
      const p = new THREE.Mesh(new THREE.PlaneGeometry(pw, h - 0.5), st);
      p.position.set(x0 - 0.5 - pw / 2 - i * (pw + 0.1), yb + h / 2 + 0.1, s * (W / 2 + 0.006));
      if (s < 0) p.rotation.y = Math.PI;
      g.add(p);
    }
    const top = rbox(len - 0.2, 0.12, W - 0.1, 0.04, m.steel); at(top, mid, yb + h + 0.2, 0); g.add(top);
    for (const s of [-1, 1]) { const rl = cyl(0.04, 0.04, len - 1.4, m.steel, 'x', 10); at(rl, mid - 0.2, yb + h + 0.45, s * 0.35); g.add(rl); }
    for (let i = 0; i < 12; i++) { const rg = cyl(0.025, 0.025, 0.7, m.steel, 'z', 6); at(rg, x0 - 0.5 - i * ((len - 1.6) / 11), yb + h + 0.42, 0); g.add(rg); }
    const hose = cyl(0.3, 0.3, 0.5, std('#c9a227', 0.8), 'z', 20); at(hose, xEnd + 0.8, yb + h + 0.45, 0.0); g.add(hose);
    const pump = rbox(0.5, 0.9, 0.2, 0.03, m.steel); at(pump, mid, yb + 0.9, W / 2 + 0.08); g.add(pump);
    const chev = new THREE.Mesh(new THREE.PlaneGeometry(W - 0.3, 0.5), new THREE.MeshStandardMaterial({ map: canvasTex(256, 64, (c, w, hh) => { for (let i = -2; i < 12; i++) { c.fillStyle = i % 2 ? '#d6e22a' : '#c8141c'; c.beginPath(); c.moveTo(i * 30, 0); c.lineTo(i * 30 + 30, 0); c.lineTo(i * 30 + 60, hh); c.lineTo(i * 30 + 30, hh); c.fill(); } }) }));
    chev.rotation.y = -Math.PI / 2; at(chev, xEnd - 0.01, yb + 0.5, 0); g.add(chev);
    const step = rbox(0.4, 0.06, W - 0.4, 0.02, m.steel); at(step, xEnd - 0.2, yb + 0.1, 0); g.add(step);
  } else if (mod === 'tow') {
    const piv = new THREE.Group();
    const bl = len - 0.4;
    const px = xEnd + 0.4;
    const cx = (x0 - px) - bl / 2 - 0.0;
    const dk = rbox(bl, 0.14, W - 0.15, 0.03, std('#2c3036', 0.6, 0.6)); at(dk, cx + 0.0, 0.07, 0);
    piv.add(dk);
    for (const s of [-1, 1]) { const r = rbox(bl, 0.18, 0.08, 0.02, m.paint); at(r, cx, 0.2, s * (W / 2 - 0.12)); piv.add(r); }
    for (let i = 0; i < 12; i++) { const rb = box(0.04, 0.02, W - 0.3, m.steel); at(rb, cx - bl / 2 + 0.2 + i * (bl / 12), 0.15, 0); piv.add(rb); }
    const hbd = rbox(0.12, 0.9, W - 0.15, 0.03, m.paint); at(hbd, cx + bl / 2 - 0.05, 0.55, 0); piv.add(hbd);
    const winch = cyl(0.12, 0.12, 0.7, m.darkMetal, 'z', 16); at(winch, cx + bl / 2 - 0.35, 0.25, 0); piv.add(winch);
    piv.position.set(px, yb, 0);
    g.add(piv);
    piv.children.forEach((c) => (c.position.x -= 0));
    const cs = (spec.opts?.cargoSpecs ?? []) as CarSpec[];
    if (cargoBuilder && cs[0]) { const cv = cargoBuilder(cs[0]); cv.group.scale.setScalar(0.9); cv.group.position.set(cx - 0.2, 0.28, 0); piv.add(cv.group); }
    let cur = 0;
    v.anims.push((dt, s) => { const tg = (s.doorL + s.doorR) / 2; cur += (tg - cur) * Math.min(1, dt * 1.2); piv.rotation.z = cur * 0.38; });
    piv.position.x = px;
    const lock = cyl(0.06, 0.06, 1.0, m.chrome, 'y', 10); at(lock, x0 - 1.4, yb + 0.5, 0.0); g.add(lock);
    const lb = rbox(0.4, 0.14, 0.9, 0.04, std('#e8a400', 0.4)); at(lb, x0 - 0.1, yb + 1.15, 0); g.add(lb);
  } else if (mod === 'garbage') {
    const bodyG = rbox(len - 1.2, 2.3, W, 0.2, m.paint); at(bodyG, x0 - (len - 1.2) / 2, yb + 1.3, 0); g.add(bodyG);
    const hop = rbox(1.3, 1.2, W - 0.1, 0.1, m.paint); at(hop, xEnd + 0.65, yb + 0.9, 0); g.add(hop);
    const hopIn = rbox(1.1, 0.2, W - 0.4, 0.04, m.black); at(hopIn, xEnd + 0.65, yb + 0.5, 0); g.add(hopIn);
    const lip = rbox(0.2, 0.2, W - 0.2, 0.05, m.black); at(lip, xEnd + 0.05, yb + 1.05, 0); g.add(lip);
    for (const s of [-1, 1]) { const arm = rbox(0.9, 0.1, 0.1, 0.02, m.darkMetal); at(arm, xEnd + 0.3, yb + 1.9, s * 0.9); arm.rotation.z = 0.3; g.add(arm); }
    const bin = rbox(0.8, 0.9, 0.9, 0.06, std('#2a5a8a', 0.6)); at(bin, xEnd - 0.5, yb + 0.9, 0); g.add(bin);
    const stripe = rbox(len - 1.2, 0.2, W + 0.01, 0.01, std('#f2f2f2', 0.5)); at(stripe, x0 - (len - 1.2) / 2, yb + 1.0, 0); g.add(stripe);
    const lt = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.02, 8, 24), m.chrome); at(lt, xEnd + 0.1, yb + 2.1, 0); g.add(lt);
  } else if (mod === 'chassis') {
    for (const s of [-1, 1]) { const b = rbox(0.5, 0.2, 0.15, 0.03, m.black); at(b, xEnd + 0.2, frameH + 0.3, s * 0.7); g.add(b); }
    const spare = makeWheel(m, { R, tw, rimR: spec.rimR, style: 'truck', rimMat, brake: false });
    const sg = new THREE.Group(); sg.add(spare.spin); sg.rotation.y = Math.PI / 2; at(sg, xEnd + 0.3, frameH + 0.1, 0); g.add(sg);
    const deck = rbox(len - 1.0, 0.04, 0.9, 0.01, m.darkMetal); at(deck, mid + 0.2, frameH + 0.13, 0); g.add(deck);
  }
  void walls; void tilt;

  // recentre
  const shift = -(xmax + xEnd) / 2;
  g.children.forEach((c) => { c.position.x += shift; });
  v.eye.x += shift;
  v.size = { L: xmax - xEnd, W: Math.max(spec.W, W) + 0.2, H: Math.max(spec.H, yb + 2.6) };
  return v;
}

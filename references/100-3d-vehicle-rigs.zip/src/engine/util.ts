import * as THREE from 'three';

export const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const V3 = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);

/** Monotone cubic interpolation (no overshoot) through the given points. */
export function pchip(xs: number[], ys: number[]): (x: number) => number {
  const n = xs.length;
  const h: number[] = [];
  const d: number[] = [];
  for (let i = 0; i < n - 1; i++) {
    h[i] = xs[i + 1] - xs[i];
    d[i] = (ys[i + 1] - ys[i]) / h[i];
  }
  const m: number[] = new Array(n).fill(0);
  m[0] = d[0];
  m[n - 1] = d[n - 2];
  for (let i = 1; i < n - 1; i++) {
    if (d[i - 1] * d[i] <= 0) m[i] = 0;
    else {
      const w1 = 2 * h[i] + h[i - 1];
      const w2 = h[i] + 2 * h[i - 1];
      m[i] = (w1 + w2) / (w1 / d[i - 1] + w2 / d[i]);
    }
  }
  return (x: number) => {
    if (x <= xs[0]) return ys[0];
    if (x >= xs[n - 1]) return ys[n - 1];
    let lo = 0;
    let hi = n - 1;
    while (hi - lo > 1) {
      const mid = (lo + hi) >> 1;
      if (xs[mid] > x) hi = mid;
      else lo = mid;
    }
    const t = (x - xs[lo]) / h[lo];
    const t2 = t * t;
    const t3 = t2 * t;
    return (2 * t3 - 3 * t2 + 1) * ys[lo] + (t3 - 2 * t2 + t) * h[lo] * m[lo] + (-2 * t3 + 3 * t2) * ys[lo + 1] + (t3 - t2) * h[lo] * m[lo + 1];
  };
}

export function canvasTex(w: number, h: number, draw: (g: CanvasRenderingContext2D, w: number, h: number) => void, repeat?: [number, number]) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const g = c.getContext('2d')!;
  draw(g, w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  if (repeat) {
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(repeat[0], repeat[1]);
  }
  return t;
}

export function plateTexture(text: string, bg = '#f4f4ee', fg = '#1a2a55') {
  return canvasTex(512, 128, (g, w, h) => {
    g.fillStyle = bg;
    g.fillRect(0, 0, w, h);
    g.strokeStyle = fg;
    g.lineWidth = 6;
    g.strokeRect(6, 6, w - 12, h - 12);
    g.fillStyle = fg;
    g.font = 'bold 84px Arial Narrow, Arial, sans-serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText(text, w / 2, h / 2 + 4);
  });
}

export function grilleTexture(style: 'mesh' | 'bars' | 'honey' | 'slats' = 'mesh', bg = '#08090a', fg = '#3a3d42') {
  return canvasTex(256, 256, (g, w, h) => {
    g.fillStyle = bg;
    g.fillRect(0, 0, w, h);
    g.strokeStyle = fg;
    g.fillStyle = fg;
    if (style === 'mesh') {
      g.lineWidth = 3;
      for (let i = -h; i < w + h; i += 16) {
        g.beginPath(); g.moveTo(i, 0); g.lineTo(i + h, h); g.stroke();
        g.beginPath(); g.moveTo(i, h); g.lineTo(i + h, 0); g.stroke();
      }
    } else if (style === 'bars') {
      for (let i = 12; i < h; i += 40) g.fillRect(0, i, w, 14);
    } else if (style === 'slats') {
      for (let i = 0; i < w; i += 22) g.fillRect(i, 0, 8, h);
    } else {
      for (let y = 0; y < h + 18; y += 14) for (let x = 0; x < w + 18; x += 16) {
        g.beginPath();
        const cx = x + (Math.round(y / 14) % 2 ? 8 : 0);
        for (let k = 0; k < 6; k++) g.lineTo(cx + 6.5 * Math.cos(k * Math.PI / 3 + Math.PI / 6), y + 6.5 * Math.sin(k * Math.PI / 3 + Math.PI / 6));
        g.closePath(); g.fill();
      }
    }
  }, [1, 1]);
}

export function carbonTexture() {
  return canvasTex(128, 128, (g, w, h) => {
    g.fillStyle = '#0b0b0c';
    g.fillRect(0, 0, w, h);
    for (let y = 0; y < h; y += 16) for (let x = 0; x < w; x += 16) {
      const a = ((x + y) / 16) % 2 === 0;
      const gr = g.createLinearGradient(x, y, a ? x + 16 : x, a ? y : y + 16);
      gr.addColorStop(0, '#2a2b2e'); gr.addColorStop(1, '#101012');
      g.fillStyle = gr;
      g.fillRect(x + 1, y + 1, 14, 14);
    }
  }, [6, 6]);
}

export function decalTexture(text: string, color: string, bg: string | null = null, font = 'bold 120px Arial, sans-serif', w = 1024, h = 256) {
  const t = canvasTex(w, h, (g) => {
    if (bg) { g.fillStyle = bg; g.fillRect(0, 0, w, h); }
    g.fillStyle = color;
    g.font = font;
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText(text, w / 2, h / 2 + 6);
  });
  return t;
}

export function roadTexture() {
  const t = canvasTex(1024, 1024, (g, w, h) => {
    g.fillStyle = '#26282c';
    g.fillRect(0, 0, w, h);
    for (let i = 0; i < 9000; i++) {
      const v = 30 + Math.random() * 28;
      g.fillStyle = `rgba(${v},${v},${v + 3},${Math.random() * 0.5})`;
      g.fillRect(Math.random() * w, Math.random() * h, 2 + Math.random() * 3, 2 + Math.random() * 3);
    }
    g.fillStyle = '#e9e6d8';
    g.fillRect(0, h * 0.03, w, 14);
    g.fillRect(0, h * 0.97 - 14, w, 14);
    g.fillStyle = '#e3b82a';
    for (let x = 0; x < w; x += 256) g.fillRect(x + 20, h / 2 - 8, 150, 16);
  });
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

/** Live instrument cluster texture (speedometer + tachometer) */
export class Cluster {
  canvas = document.createElement('canvas');
  tex: THREE.CanvasTexture;
  last = -1;
  constructor(public accent = '#35c7ff') {
    this.canvas.width = 512;
    this.canvas.height = 192;
    this.tex = new THREE.CanvasTexture(this.canvas);
    this.tex.colorSpace = THREE.SRGBColorSpace;
    this.draw(0, 0);
  }
  private dial(g: CanvasRenderingContext2D, cx: number, cy: number, r: number, v: number, max: number, step: number, red: number) {
    g.strokeStyle = '#1b222b'; g.lineWidth = 6;
    g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.stroke();
    const a0 = Math.PI * 0.75, a1 = Math.PI * 2.25;
    g.font = 'bold 13px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle';
    for (let k = 0; k <= max; k += step / 2) {
      const a = a0 + (a1 - a0) * (k / max);
      const major = k % step === 0;
      g.strokeStyle = k >= red ? '#ff3b30' : '#dfe8f0';
      g.lineWidth = major ? 3 : 1.5;
      g.beginPath();
      g.moveTo(cx + Math.cos(a) * (r - (major ? 14 : 8)), cy + Math.sin(a) * (r - (major ? 14 : 8)));
      g.lineTo(cx + Math.cos(a) * (r - 2), cy + Math.sin(a) * (r - 2));
      g.stroke();
      if (major) { g.fillStyle = '#dfe8f0'; g.fillText(String(k), cx + Math.cos(a) * (r - 28), cy + Math.sin(a) * (r - 28)); }
    }
    const a = a0 + (a1 - a0) * clamp(v / max, 0, 1);
    g.strokeStyle = this.accent; g.lineWidth = 4; g.lineCap = 'round';
    g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + Math.cos(a) * (r - 10), cy + Math.sin(a) * (r - 10)); g.stroke();
    g.fillStyle = '#10151b'; g.beginPath(); g.arc(cx, cy, 8, 0, 7); g.fill();
  }
  draw(kmh: number, rpm: number) {
    const key = Math.round(kmh) * 100 + Math.round(rpm / 100);
    if (key === this.last) return;
    this.last = key;
    const g = this.canvas.getContext('2d')!;
    g.fillStyle = '#05080c';
    g.fillRect(0, 0, 512, 192);
    this.dial(g, 112, 98, 84, kmh, 280, 40, 999);
    this.dial(g, 400, 98, 84, rpm / 1000, 8, 1, 6.5);
    g.fillStyle = '#ffffff'; g.font = 'bold 44px Arial'; g.textAlign = 'center';
    g.fillText(String(Math.round(kmh)), 256, 80);
    g.font = '16px Arial'; g.fillStyle = this.accent; g.fillText('km/h', 256, 106);
    g.fillStyle = '#9fb2c2'; g.font = '14px Arial'; g.fillText('D  ' + (kmh < 1 ? 'P' : 'AUTO'), 256, 140);
    this.tex.needsUpdate = true;
  }
}

export function screenTexture(accent = '#35c7ff') {
  return canvasTex(512, 256, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, w, h);
    gr.addColorStop(0, '#0a1420'); gr.addColorStop(1, '#14283c');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    g.strokeStyle = accent; g.lineWidth = 6; g.lineCap = 'round';
    g.beginPath(); g.moveTo(30, 190); g.bezierCurveTo(130, 60, 240, 220, 330, 90); g.bezierCurveTo(380, 30, 440, 70, 480, 40); g.stroke();
    g.fillStyle = '#fff'; g.beginPath(); g.arc(330, 90, 10, 0, 7); g.fill();
    g.fillStyle = '#7f95aa'; g.font = '22px Arial'; g.fillText('NAV  21°C  FM 98.5', 24, 36);
  });
}

export interface Mats {
  paint: THREE.MeshPhysicalMaterial;
  paint2: THREE.MeshPhysicalMaterial;
  glass: THREE.MeshPhysicalMaterial;
  black: THREE.MeshStandardMaterial;
  under: THREE.MeshStandardMaterial;
  chrome: THREE.MeshStandardMaterial;
  steel: THREE.MeshStandardMaterial;
  darkMetal: THREE.MeshStandardMaterial;
  rubber: THREE.MeshStandardMaterial;
  trim: THREE.MeshStandardMaterial;
  trim2: THREE.MeshStandardMaterial;
  dash: THREE.MeshStandardMaterial;
  carpet: THREE.MeshStandardMaterial;
  headliner: THREE.MeshStandardMaterial;
  lens: THREE.MeshPhysicalMaterial;
  headLamp: THREE.MeshStandardMaterial;
  tailLamp: THREE.MeshStandardMaterial;
  amber: THREE.MeshStandardMaterial;
  white: THREE.MeshStandardMaterial;
  all: THREE.Material[];
}

export function makeMats(color: string, interior: string, opts: { color2?: string; matte?: boolean; metal?: number; trim2?: string } = {}): Mats {
  const std = (c: string | number, r: number, m = 0) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, side: THREE.DoubleSide });
  const paint = new THREE.MeshPhysicalMaterial({
    color: color, metalness: opts.metal ?? 0.55, roughness: opts.matte ? 0.55 : 0.26,
    clearcoat: opts.matte ? 0 : 1, clearcoatRoughness: 0.04, side: THREE.DoubleSide, envMapIntensity: 0.75,
  });
  const paint2 = paint.clone();
  paint2.color = new THREE.Color(opts.color2 ?? color);
  const glass = new THREE.MeshPhysicalMaterial({
    color: 0x0c1319, metalness: 0.1, roughness: 0.03, transparent: true, opacity: 0.34,
    side: THREE.DoubleSide, depthWrite: false, envMapIntensity: 1.8,
  });
  const lens = new THREE.MeshPhysicalMaterial({
    color: 0xe8f2ff, metalness: 0, roughness: 0.02, transparent: true, opacity: 0.14, side: THREE.DoubleSide, depthWrite: false, envMapIntensity: 0.8,
  });
  const headLamp = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff3d6, emissiveIntensity: 0.15, roughness: 0.2 });
  const tailLamp = new THREE.MeshStandardMaterial({ color: 0x8a0710, emissive: 0xff1020, emissiveIntensity: 0.25, roughness: 0.25 });
  const amber = new THREE.MeshStandardMaterial({ color: 0xc87a10, emissive: 0xff8a00, emissiveIntensity: 0.1, roughness: 0.25 });
  const m: Mats = {
    paint, paint2, glass,
    black: std(0x0e0f10, 0.5, 0.1),
    under: std(0x0a0a0b, 0.9, 0.2),
    chrome: std(0xe8ecf0, 0.06, 1),
    steel: std(0xa9b0b8, 0.35, 0.9),
    darkMetal: std(0x2a2d31, 0.45, 0.85),
    rubber: std(0x111112, 0.88, 0),
    trim: std(interior, 0.62, 0.02),
    trim2: std(opts.trim2 ?? '#1a1a1c', 0.7, 0.02),
    dash: std(0x17181a, 0.55, 0.05),
    carpet: std(0x1c1d1f, 0.97, 0),
    headliner: std(0xcfc9bc, 0.95, 0),
    lens, headLamp, tailLamp, amber,
    white: std(0xf2f2f2, 0.4, 0.1),
    all: [],
  };
  m.all = Object.values(m).filter((v) => v instanceof THREE.Material) as THREE.Material[];
  return m;
}

export function disposeTree(o: THREE.Object3D) {
  o.traverse((c) => {
    const m = c as THREE.Mesh;
    if (m.geometry) m.geometry.dispose();
    const mat = (m as any).material;
    if (mat) {
      const arr = Array.isArray(mat) ? mat : [mat];
      arr.forEach((x: THREE.Material) => {
        for (const k of Object.keys(x)) {
          const v = (x as any)[k];
          if (v && v.isTexture) v.dispose();
        }
        x.dispose();
      });
    }
  });
}

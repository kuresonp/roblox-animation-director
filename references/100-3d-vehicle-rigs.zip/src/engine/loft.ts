import * as THREE from 'three';
import { Mats, clamp, lerp } from './util';

export interface DoorSpec {
  side: 'L' | 'R';
  x0: number; x1: number;            // opening x-range (x1 = forward edge)
  hinge: 'front' | 'rear' | 'slide';
  win?: [number, number] | null;     // glass x-range
  winRows?: [number, number];        // band rows with glass (k index, 1..nB-1)
  angle?: number;
  lowRows?: number;                  // extra rows to skip at bottom (0 default)
  topK?: number;                     // limit door height to band row k
}
export interface DoorRig {
  pivot: THREE.Group; spec: DoorSpec; side: number; t: number; target: number;
  angle: number; len: number; px: number; pz: number;
}
export interface WindowSpec { x0: number; x1: number; rows?: [number, number]; }
export interface HoleSpec { x0: number; x1: number; rowFrom: number; }

export interface BodyOpts {
  xmin: number; xmax: number;
  top: (x: number) => number; bottom: (x: number) => number; belt: (x: number) => number;
  halfW: number; wMul?: (x: number) => number;
  rl: number; rs: number; rr: number; roofRatio: number; bulge: number; crown: number; hoodCrown: number;
  planN: number; rfF: number; rfR: number;
  bandT?: number[]; nW?: number; cabinH: number;
  arches: { x: number; R: number }[]; archGap?: number;
  doors: DoorSpec[]; windows: WindowSpec[]; topGlass: [number, number][];
  holes?: HoleSpec[]; cladding?: number; roofTwoTone?: boolean; roofX?: [number, number];
  doorGap?: number; doorThick?: number;
  M: Mats;
}

export class MB {
  pos: number[] = [];
  uv: number[] = [];
  idx: Record<string, number[]> = {};
  v(x: number, y: number, z: number, u = 0, w = 0) { this.pos.push(x, y, z); this.uv.push(u, w); return this.pos.length / 3 - 1; }
  q(a: number, b: number, c: number, d: number, key: string) {
    (this.idx[key] ??= []).push(a, b, c, a, c, d);
  }
  build(mats: Record<string, THREE.Material>, shadow = true) {
    const keys = Object.keys(this.idx);
    const all: number[] = [];
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2));
    const ms: THREE.Material[] = [];
    keys.forEach((k, n) => {
      g.addGroup(all.length, this.idx[k].length, n);
      all.push(...this.idx[k]);
      ms.push(mats[k]);
    });
    g.setIndex(all);
    g.computeVertexNormals();
    const mesh = new THREE.Mesh(g, ms);
    mesh.castShadow = shadow;
    mesh.receiveShadow = shadow;
    return mesh;
  }
}

export function buildBody(o: BodyOpts) {
  const nW = o.nW ?? 10;
  const bandT = o.bandT ?? [0.07, 0.35, 0.7, 1.0];
  const nB = bandT.length;
  const iBelt = 7 + nW;
  const iBandEnd = iBelt + nB;
  const T = iBandEnd + 4;
  const Nr = 2 * T;
  const rLo = 4 + Math.round(nW * 0.22);
  const archGap = o.archGap ?? 0.04;
  const gap = o.doorGap ?? 0.006;
  const thick = o.doorThick ?? 0.085;
  const sup = (t: number) => (t <= 0 ? 0 : t >= 1 ? 1 : Math.pow(1 - Math.pow(1 - t, o.planN), 1 / o.planN));
  const plan = (x: number) => Math.min(sup((o.xmax - x) / o.rfF), sup((x - o.xmin) / o.rfR));

  // ---- cross-section at any x: list of [z, y] (z>=0) from underside centre to roof centre
  const sec = (x: number) => {
    const w = o.halfW * (o.wMul ? o.wMul(x) : 1) * plan(x);
    const yB = o.bottom(x);
    let yT = o.top(x);
    let yBelt = Math.min(o.belt(x), yT - 0.0005);
    yBelt = Math.max(yBelt, yB + 0.16);
    yT = Math.max(yT, yBelt);
    const a = w * 0.8;
    const rl = Math.min(o.rl, (yBelt - yB) * 0.3);
    const rs = Math.min(o.rs, (yBelt - yB - rl) * 0.4, Math.max(w * 0.4, 0.001));
    const cabin = yT - yBelt;
    const rr = Math.min(o.rr, cabin * 0.5);
    const tumble = clamp(cabin / o.cabinH, 0, 1);
    const wS = w - rs;
    const wTop = lerp(wS, Math.min(w * o.roofRatio, wS), tumble);
    const P: number[][] = [[0, yB]];
    for (let k = 1; k <= 4; k++) {
      const f = (k / 4) * Math.PI / 2;
      P.push([a + (w - a) * Math.sin(f), yB + rl * (1 - Math.cos(f))]);
    }
    const yw0 = yB + rl;
    const yw1 = yBelt - rs;
    for (let k = 1; k <= nW; k++) {
      const t = k / nW;
      P.push([w * (1 + o.bulge * Math.sin(Math.PI * t)), lerp(yw0, yw1, t)]);
    }
    for (let k = 1; k <= 3; k++) {
      const th = k * Math.PI / 6;
      P.push([w - rs + rs * Math.cos(th), yw1 + rs * Math.sin(th)]);
    }
    for (const t of bandT) P.push([lerp(wS, wTop, t), lerp(yBelt, yT - rr, t)]);
    const cx = wTop - rr;
    const cy = yT - rr;
    P.push([cx + rr * Math.cos(Math.PI / 4), cy + rr * Math.sin(Math.PI / 4)]);
    P.push([cx, yT]);
    const crown = lerp(o.hoodCrown, o.crown, tumble);
    P.push([cx * 0.5, yT + crown * 0.75]);
    P.push([0, yT + crown]);
    return { P, w, yB, yT, yBelt };
  };

  // ---- stations
  const set = new Set<number>();
  const step = clamp((o.xmax - o.xmin) / 120, 0.03, 0.1);
  for (let x = o.xmin; x < o.xmax; x += step) set.add(+x.toFixed(4));
  set.add(o.xmax);
  for (let k = 0; k <= 16; k++) {
    const t = (k / 16) ** 2;
    set.add(+(o.xmin + t * o.rfR).toFixed(4));
    set.add(+(o.xmax - t * o.rfF).toFixed(4));
  }
  o.doors.forEach((d) => {
    [d.x0, d.x0 + gap, d.x1 - gap, d.x1].forEach((x) => set.add(+x.toFixed(4)));
    if (d.win) d.win.forEach((x) => set.add(+x.toFixed(4)));
  });
  o.windows.forEach((w) => { set.add(+w.x0.toFixed(4)); set.add(+w.x1.toFixed(4)); });
  o.topGlass.forEach((w) => { set.add(+w[0].toFixed(4)); set.add(+w[1].toFixed(4)); });
  o.holes?.forEach((h) => { set.add(+h.x0.toFixed(4)); set.add(+h.x1.toFixed(4)); });
  if (o.roofX) o.roofX.forEach((x) => set.add(+x.toFixed(4)));
  let xs = [...set].filter((x) => x >= o.xmin - 1e-6 && x <= o.xmax + 1e-6).sort((a, b) => a - b);
  xs = xs.filter((x, i) => i === 0 || x - xs[i - 1] > 4e-4);
  const nS = xs.length;
  const secs = xs.map(sec);

  const ringPt = (i: number, j: number) => {
    const k = j <= T ? j : 2 * T - j;
    const sg = j <= T ? 1 : -1;
    const p = secs[i].P[k];
    return [xs[i], p[1], sg * p[0]];
  };
  const mb = new MB();
  const vid = (i: number, j: number) => i * Nr + (j % Nr);
  for (let i = 0; i < nS; i++) for (let j = 0; j < Nr; j++) { const p = ringPt(i, j); mb.v(p[0], p[1], p[2]); }

  const inRange = (x: number, a: number, b: number) => x >= a - 1e-6 && x <= b + 1e-6;
  const M = o.M;
  const clad = o.cladding ?? 0;
  const archCut = (xc: number, yc: number) => o.arches.some((a) => (xc - a.x) ** 2 + (yc - a.R) ** 2 < (a.R + archGap + 0.025) ** 2);

  for (let i = 0; i < nS - 1; i++) {
    const xc = (xs[i] + xs[i + 1]) / 2;
    for (let j = 0; j < Nr; j++) {
      const side = j < T ? 1 : -1;
      const r = j < T ? j : 2 * T - 1 - j;
      const a = vid(i, j), b = vid(i + 1, j), c = vid(i + 1, j + 1), d = vid(i, j + 1);
      const yc = (mb.pos[a * 3 + 1] + mb.pos[c * 3 + 1]) / 2;
      // skips
      let skip = false;
      for (const dr of o.doors) {
        if ((dr.side === 'R' ? 1 : -1) === side && r >= rLo + (dr.lowRows ?? 0) && r <= (dr.topK ? iBelt + dr.topK : iBandEnd) - 1 && inRange(xc, dr.x0, dr.x1)) { skip = true; break; }
      }
      if (skip) continue;
      if (o.holes) for (const h of o.holes) if (r >= h.rowFrom && inRange(xc, h.x0, h.x1)) skip = true;
      if (skip) continue;
      if (r >= 1 && r <= iBelt && archCut(xc, yc)) continue;
      let key = 'paint';
      if (r <= 1) key = 'under';
      else if (clad && r >= 2 && r <= (clad === 1 ? 4 : rLo + 2)) key = 'clad';
      else if (r >= iBelt && r < iBandEnd + 2) {
        const k = r - iBelt;
        const inX = o.windows.filter((w) => inRange(xc, w.x0, w.x1));
        if (inX.length) {
          if (k === 0 || k > nB - 1) key = 'black';
          else if (inX.some((w) => { const rows = w.rows ?? [1, nB - 1]; return k >= rows[0] && k <= rows[1]; })) key = 'glass';
        }
        if (key === 'paint' && o.topGlass.some((t) => inRange(xc, t[0], t[1])) && r >= iBandEnd) key = 'black';
        if (key === 'paint' && r >= iBandEnd && o.roofTwoTone && (!o.roofX || inRange(xc, o.roofX[0], o.roofX[1]))) key = 'roof';
      } else if (r >= iBandEnd + 2) {
        if (o.topGlass.some((t) => inRange(xc, t[0], t[1]))) key = 'glass';
        else if (o.roofTwoTone && (!o.roofX || inRange(xc, o.roofX[0], o.roofX[1]))) key = 'roof';
      }
      mb.q(a, b, c, d, key);
    }
  }
  const matMap: Record<string, THREE.Material> = { paint: M.paint, roof: M.paint2, black: M.black, glass: M.glass, under: M.under, clad: M.black };
  const mesh = mb.build(matMap);

  // ---- helpers over arbitrary x
  const zAt = (x: number, y: number) => {
    const P = sec(x).P;
    for (let r = 1; r < iBandEnd; r++) {
      const y0 = P[r][1], y1 = P[r + 1][1];
      if (y1 > y0 + 1e-6 && y >= y0 - 1e-9 && y <= y1 + 1e-9) return lerp(P[r][0], P[r + 1][0], (y - y0) / (y1 - y0));
    }
    return P[iBandEnd][0];
  };

  // ---- doors
  const doors: DoorRig[] = [];
  const idxOf = (x: number) => { let bi = 0, bd = 1e9; xs.forEach((v, i) => { const d = Math.abs(v - x); if (d < bd) { bd = d; bi = i; } }); return bi; };
  for (const sp of o.doors) {
    const side = sp.side === 'R' ? 1 : -1;
    const iA = idxOf(sp.x0 + gap), iB = idxOf(sp.x1 - gap);
    const px = sp.hinge === 'front' ? xs[iB] : sp.hinge === 'rear' ? xs[iA] : (xs[iA] + xs[iB]) / 2;
    const jOf = (r: number) => (side > 0 ? r : (2 * T - r) % Nr);
    const pz = ringPt(iB, jOf(iBelt))[2];
    const db = new MB();
    const rLoD = rLo + (sp.lowRows ?? 0);
    const rTop = sp.topK ? iBelt + sp.topK : iBandEnd;
    const grid: number[][] = [];
    const inner: number[][] = [];
    for (let i = iA; i <= iB; i++) {
      grid[i] = []; inner[i] = [];
      for (let r = rLoD; r <= rTop; r++) {
        const p = ringPt(i, jOf(r));
        grid[i][r] = db.v(p[0] - px, p[1], p[2] - side * Math.abs(pz) * 0 - pz);
        if (r <= iBelt) inner[i][r] = db.v(p[0] - px, p[1], p[2] - pz - side * thick);
      }
    }
    for (let i = iA; i < iB; i++) {
      const xc = (xs[i] + xs[i + 1]) / 2;
      for (let r = rLoD; r < rTop; r++) {
        let key = 'paint';
        if (r === iBelt) key = 'black';
        else if (r > iBelt) {
          const k = r - iBelt;
          const rows = sp.winRows ?? [1, nB - 1];
          key = sp.win && inRange(xc, sp.win[0], sp.win[1]) && k >= rows[0] && k <= rows[1] ? 'glass' : 'paint';
        }
        if (r < rLoD + 1 && clad) key = 'clad';
        db.q(grid[i][r], grid[i + 1][r], grid[i + 1][r + 1], grid[i][r + 1], key);
        if (r <= iBelt) {
          db.q(inner[i][r], inner[i + 1][r], inner[i + 1][r + 1] ?? inner[i + 1][r], inner[i][r + 1] ?? inner[i][r], 'trim');
        }
      }
      // bottom & top edge seals
      db.q(grid[i][rLoD], grid[i + 1][rLoD], inner[i + 1][rLoD], inner[i][rLoD], 'black');
      db.q(grid[i][iBelt], grid[i + 1][iBelt], inner[i + 1][iBelt], inner[i][iBelt], 'black');
    }
    for (const i of [iA, iB]) for (let r = rLoD; r < iBelt; r++) db.q(grid[i][r], grid[i][r + 1], inner[i][r + 1], inner[i][r], 'black');
    const dm = db.build({ paint: M.paint, black: M.black, glass: M.glass, trim: M.trim, clad: M.black });
    const pivot = new THREE.Group();
    pivot.position.set(px, 0, pz);
    pivot.add(dm);
    doors.push({ pivot, spec: sp, side, t: 0, target: 0, angle: sp.angle ?? 1.1, len: xs[iB] - xs[iA], px, pz });
  }

  const nearestStation = (x: number) => xs[idxOf(x)];

  /** patch following the outer wall between x0..x1 and y0..y1 (right side, +z) */
  const wallPatch = (x0: number, x1: number, y0: number, y1: number, off: number, mat: THREE.Material, nx = 28, ny = 6) => {
    const b = new MB();
    const id: number[][] = [];
    for (let a = 0; a <= nx; a++) {
      id[a] = [];
      const x = lerp(x0, x1, a / nx);
      for (let c = 0; c <= ny; c++) {
        const y = lerp(y0, y1, c / ny);
        id[a][c] = b.v(x, y, zAt(x, y) + off, a / nx, c / ny);
      }
    }
    for (let a = 0; a < nx; a++) for (let c = 0; c < ny; c++) b.q(id[a][c], id[a + 1][c], id[a + 1][c + 1], id[a][c + 1], 'm');
    const m = b.build({ m: mat }, false);
    return m;
  };

  /** point on nose/tail surface at lateral z & height y (right half) with outward normal offset */
  const endPoint = (end: 'front' | 'rear', zt: number, y: number, off = 0) => {
    const xe = end === 'front' ? o.xmax : o.xmin;
    const dir = end === 'front' ? -1 : 1;
    const zone = (end === 'front' ? o.rfF : o.rfR) + 0.4;
    let lo = 0, hi = zone;
    for (let k = 0; k < 22; k++) { const mid = (lo + hi) / 2; if (zAt(xe + dir * mid, y) < zt) lo = mid; else hi = mid; }
    const d = (lo + hi) / 2;
    const z = zAt(xe + dir * d, y);
    const sl = (zAt(xe + dir * (d + 0.01), y) - zAt(xe + dir * Math.max(0, d - 0.01), y)) / (d < 0.01 ? 0.01 + d : 0.02);
    const nrm = new THREE.Vector2(-dir * sl, 1).normalize();
    return new THREE.Vector3(xe + dir * d + nrm.x * off, y, z + nrm.y * off);
  };
  /** patch hugging the nose/tail between z-range zA..zB and y0..y1 (right half, mirror with scale.z=-1) */
  const endPatch = (end: 'front' | 'rear', zA: number, zB: number, y0: number, y1: number, off: number, mat: THREE.Material, nz = 14, ny = 6) => {
    const b = new MB();
    const id: number[][] = [];
    for (let c = 0; c <= ny; c++) {
      const y = lerp(y0, y1, c / ny);
      id[c] = [];
      for (let a = 0; a <= nz; a++) {
        const p = endPoint(end, lerp(zA, zB, a / nz), y, off);
        id[c][a] = b.v(p.x, p.y, p.z, a / nz, c / ny);
      }
    }
    for (let c = 0; c < ny; c++) for (let a = 0; a < nz; a++) b.q(id[c][a], id[c][a + 1], id[c + 1][a + 1], id[c + 1][a], 'm');
    return b.build({ m: mat }, false);
  };

  const group = new THREE.Group();
  group.add(mesh);
  doors.forEach((d) => group.add(d.pivot));

  return {
    group, mesh, doors, zAt, wallPatch, endPatch, endPoint, sec, nearestStation, xs,
    wallZ: (x: number) => o.halfW * (o.wMul ? o.wMul(x) : 1) * (1 + o.bulge * 0.5),
    rows: { iBelt, iBandEnd, T, rLo, nB },
  };
}
export type Body = ReturnType<typeof buildBody>;

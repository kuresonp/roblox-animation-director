import * as THREE from 'three';
import { Mats, Cluster } from './util';
import { Body, DoorRig, DoorSpec, WindowSpec } from './loft';
import type { WheelStyle } from './parts';

export interface WheelSpec { x: number; R?: number; tw?: number; steer?: boolean; dual?: boolean; z?: number; }

export interface CarSpec {
  name: string;
  cat?: string;
  kind?: 'car' | 'truck' | 'special';
  color: string; color2?: string; interior: string; trim2?: string; matte?: boolean; metal?: number;
  L: number; W: number; H: number; wb: number;
  fo?: number;
  R: number; tw: number; rimR: number; wheel?: WheelStyle; rimColor?: string; caliper?: string; lugs?: boolean;
  rearR?: number; rearTw?: number; whitewall?: boolean;
  clr?: number;
  hoodLen: number; screen: number; roofLen: number; rwRun: number;
  hoodH: number; noseH: number; deckH: number; tailH?: number; beltH: number;
  rearGlass?: boolean; frontGlass?: boolean;
  crown?: number; hoodCrown?: number; roofRatio?: number; rs?: number; rl?: number; rr?: number; planN?: number; rfF?: number; rfR?: number; bulge?: number;
  doorsN?: 0 | 2 | 4 | 6; doorLen?: number; rearDoorLen?: number; doorShift?: number; slideRear?: boolean; doorsAt?: DoorSpec[];
  windows?: WindowSpec[]; quarterEnd?: number; bandT?: number[]; cladding?: number;
  open?: 'convertible' | 'targa' | 'bed' | 'cab' | 'none';
  openX?: [number, number];
  roofTwoTone?: boolean; roofX?: [number, number];
  rowGap?: number; rows?: { dx?: number; x?: number; n: number; kind?: 'bucket' | 'bench' | 'sport' | 'bus' | 'racing'; zs?: number[]; h?: number }[];
  seatH?: number; steerH?: number; seatKind?: 'bucket' | 'bench' | 'sport' | 'racing';
  grille?: 'mesh' | 'bars' | 'honey' | 'slats' | 'none'; grilleW?: number; grilleY?: [number, number]; chromeGrille?: boolean;
  lamp?: { y0: number; y1: number; z0: number; z1: number };
  tail?: { y0: number; y1: number; z0: number; z1: number; bar?: boolean };
  round?: boolean;            // round retro headlights
  plate?: string;
  extras?: string[];
  roll?: boolean;
  rhd?: boolean;
  noMirror?: boolean; noRear?: boolean; noUnder?: boolean; hoodNarrow?: number; rearHinge?: boolean; tl?: number;
  wheels?: WheelSpec[];
  sixWheel?: boolean;
  noArchRear?: boolean;
  heavy?: boolean;
  sound?: number;             // engine pitch factor
  // truck specific
  truck?: string; rearLen?: number; cabClr?: number; frameH?: number; axles?: number[];
  opts?: Record<string, any>;
}

export interface TrackRig { mesh: THREE.Mesh; tex?: THREE.Texture; speedRatio: number; }

export interface State { speed: number; steer: number; doorL: number; doorR: number; lights: boolean; time: number; }

export class Vehicle {
  group = new THREE.Group();
  doors: DoorRig[] = [];
  wheels: { steer: THREE.Group | null; spin: THREE.Group; R: number; side: number }[] = [];
  spinners: { obj: THREE.Object3D; axis: 'x' | 'y' | 'z'; ratio: number; sign?: number }[] = [];
  tracks: TrackRig[] = [];
  anims: ((dt: number, s: State) => void)[] = [];
  steerWheel: THREE.Object3D | null = null;
  cluster: Cluster | null = null;
  mats!: Mats;
  eye = new THREE.Vector3(0, 1.2, -0.4);
  size = { L: 4.5, W: 1.9, H: 1.5 };
  lightMats: { head: THREE.MeshStandardMaterial[]; tail: THREE.MeshStandardMaterial[]; amber: THREE.MeshStandardMaterial[] } = { head: [], tail: [], amber: [] };
  lightObjs: THREE.Light[] = [];
  odo = 0;
  update(dt: number, s: State) {
    // doors
    for (const d of this.doors) {
      const tgt = d.side < 0 ? s.doorL : s.doorR;
      d.target = tgt;
      d.t += (d.target - d.t) * Math.min(1, dt * 4.5);
      const e = d.t * d.t * (3 - 2 * d.t);
      if (d.spec.hinge === 'slide') {
        d.pivot.position.x = d.px - e * d.len * 0.92;
        d.pivot.position.z = d.pz + d.side * Math.min(1, e * 6) * 0.1;
      } else {
        const dirn = d.spec.hinge === 'front' ? 1 : -1;
        d.pivot.rotation.y = d.side * dirn * d.angle * e;
      }
    }
    // wheels
    const steerAng = s.steer * 0.55;
    for (const w of this.wheels) {
      w.spin.rotation.z -= (s.speed / w.R) * dt;
      if (w.steer) w.steer.rotation.y = steerAng;
    }
    for (const sp of this.spinners) {
      const k = (sp.sign ?? 1) * sp.ratio * s.speed * dt;
      sp.obj.rotation[sp.axis] += k;
    }
    for (const t of this.tracks) {
      if (t.tex) t.tex.offset.x += (s.speed * t.speedRatio) * dt;
    }
    if (this.steerWheel) this.steerWheel.rotation.z = -s.steer * 2.4;
    if (this.cluster) this.cluster.draw(Math.abs(s.speed) * 3.6, 800 + Math.min(6200, Math.abs(s.speed) * 3.6 * 28 % 5200 + (s.speed > 0.1 ? 900 : 0)));
    const on = s.lights;
    this.lightMats.head.forEach((m) => (m.emissiveIntensity = on ? 3.2 : 0.12));
    this.lightMats.tail.forEach((m) => (m.emissiveIntensity = on ? 2.4 : 0.2));
    this.lightMats.amber.forEach((m) => (m.emissiveIntensity = on ? (Math.floor(s.time * 2) % 2 ? 2.5 : 0.1) : 0.1));
    this.lightObjs.forEach((l) => (l.visible = on));
    for (const a of this.anims) a(dt, s);
  }
}

export interface Ctx {
  spec: CarSpec; m: Mats; body: Body; v: Vehicle; g: THREE.Group;
  xmin: number; xmax: number; halfW: number; H: number;
  xCowl: number; xRoofF: number; xRoofR: number; xRw: number;
  floorY: number; clr: number; steerX: number; seatX: number;
  axleF: number; axleR: number;
  topAt: (x: number) => number;
  doors: DoorRig[];
  interior: THREE.Group;
}

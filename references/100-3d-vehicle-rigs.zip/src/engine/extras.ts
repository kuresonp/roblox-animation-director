import * as THREE from 'three';
import { Ctx } from './types';
import { MB } from './loft';
import { rbox, box, cyl, tube, at, add, makeWheel, sphere } from './parts';
import { decalTexture, canvasTex, lerp } from './util';

type Extra = (c: Ctx, arg?: string) => void;
const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
const mir = <T extends THREE.Object3D>(o: T): T => { const k = o.clone() as T; k.scale.z = -1; return k; };
const std = (color: number | string, rough = 0.5, metal = 0, emissive?: number, ei = 0) =>
  new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal, emissive: emissive ?? 0x000000, emissiveIntensity: ei, side: THREE.DoubleSide });
const roofW = (c: Ctx, x: number) => { const P = c.body.sec(x).P; return P[P.length - 3][0]; };

function decalMat(text: string, color: string, bg: string | null, font: string, flip = false, w = 1024, h = 256) {
  const t = decalTexture(text, color, bg, font, w, h);
  if (flip) { t.wrapS = THREE.RepeatWrapping; t.repeat.x = -1; t.offset.x = 1; }
  return new THREE.MeshStandardMaterial({ map: t, transparent: !bg, roughness: 0.45, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2 });
}

export const EXTRAS: Record<string, Extra> = {
  spoiler(c) {
    const { xmin, halfW, m } = c;
    const x = xmin + 0.22;
    const lip = rbox(0.2, 0.03, halfW * 1.7, 0.012, m.paint);
    at(lip, x, c.topAt(x) + 0.035, 0);
    lip.rotation.z = 0.12;
    c.g.add(lip);
  },
  wing(c, arg) {
    const { xmin, halfW, m } = c;
    const h = arg ? parseFloat(arg) : 0.3;
    const x = xmin + 0.38;
    const y = c.topAt(x) + h;
    const foil = rbox(0.34, 0.03, halfW * 1.8, 0.012, m.black);
    at(foil, x, y, 0);
    foil.rotation.z = 0.12;
    c.g.add(foil);
    for (const s of [-1, 1]) {
      const plate = rbox(0.4, 0.14, 0.012, 0.005, m.black);
      at(plate, x, y, s * halfW * 0.9);
      const st = rbox(0.06, h + 0.02, 0.03, 0.01, m.black);
      at(st, x + 0.02, y - h / 2, s * halfW * 0.5);
      add(c.g, plate, st);
    }
  },
  splitter(c) {
    const f = rbox(0.28, 0.02, c.halfW * 1.8, 0.008, c.m.black);
    at(f, c.xmax - 0.1, c.clr + 0.0, 0);
    c.g.add(f);
    for (const s of [-1, 1]) {
      const ep = rbox(0.3, 0.07, 0.012, 0.004, c.m.black);
      at(ep, c.xmax - 0.1, c.clr + 0.04, s * c.halfW * 0.88);
      c.g.add(ep);
    }
  },
  diffuser(c) {
    for (let i = -4; i <= 4; i++) {
      const f = box(0.3, 0.1, 0.012, c.m.black);
      at(f, c.xmin + 0.15, c.clr + 0.08, i * c.halfW * 0.2);
      c.g.add(f);
    }
  },
  skirts(c) {
    const x0 = c.axleR + 0.45, x1 = c.axleF - 0.45;
    for (const s of [-1, 1]) {
      const k = rbox(x1 - x0, 0.07, 0.05, 0.02, c.m.black);
      at(k, (x0 + x1) / 2, c.clr + 0.1, s * (c.halfW - 0.015));
      c.g.add(k);
    }
  },
  scoop(c) {
    const x = c.xCowl + (c.xmax - c.xCowl) * 0.35;
    const b = rbox(0.5, 0.07, 0.42, 0.03, c.m.paint);
    at(b, x, c.topAt(x) + 0.04, 0);
    const hole = box(0.04, 0.045, 0.34, c.m.black);
    at(hole, x + 0.25, c.topAt(x) + 0.04, 0);
    add(c.g, b, hole);
  },
  hoodVents(c) {
    for (const s of [-1, 1]) for (let i = 0; i < 5; i++) {
      const x = c.xCowl + 0.25 + i * 0.05 + (c.xmax - c.xCowl) * 0.2;
      const v = box(0.02, 0.008, 0.3, c.m.black);
      at(v, x, c.topAt(x) + 0.032, s * c.halfW * 0.4);
      c.g.add(v);
    }
  },
  stripes(c, arg) {
    const col = arg ?? '#f5f5f5';
    const mat = std(col, 0.35, 0.2);
    const mb = new MB();
    const skip = (x: number) => (x > c.xRoofF - 0.01 && x < c.xCowl + 0.01) || (x > c.xRw - 0.01 && x < c.xRoofR + 0.01 && c.spec.rwRun > 0.1);
    for (const zc of [-0.18, 0.18]) {
      const prev: number[] = [];
      for (let x = c.xmin + 0.12; x < c.xmax - 0.1; x += 0.05) {
        if (skip(x)) { prev.length = 0; continue; }
        const P = c.body.sec(x).P;
        const T = P.length - 1;
        const yAt = (z: number) => lerp(P[T][1], P[T - 1][1], Math.min(1, Math.abs(z) / Math.max(0.01, P[T - 1][0]))) + 0.003;
        const a = mb.v(x, yAt(zc - 0.07), zc - 0.07), b = mb.v(x, yAt(zc + 0.07), zc + 0.07);
        if (prev.length) mb.q(prev[0], prev[1], b, a, 's');
        prev[0] = a; prev[1] = b;
      }
    }
    c.g.add(mb.build({ s: mat }, false));
  },
  sideStripes(c) {
    const list: any[] = c.spec.opts?.sideStripes ?? [];
    list.forEach((s) => {
      const mat = std(s.color, 0.35, 0.1);
      const p = c.body.wallPatch(s.x0 ?? c.xmin + 0.3, s.x1 ?? c.xmax - 0.3, s.y0, s.y1, 0.003, mat, 40, 2);
      c.g.add(p, mir(p));
    });
  },
  decals(c) {
    const list: any[] = c.spec.opts?.decals ?? [];
    list.forEach((d) => {
      const font = d.font ?? 'bold 150px Arial, sans-serif';
      const x0 = d.x0, x1 = d.x1, y0 = d.y0, y1 = d.y1;
      const pr = c.body.wallPatch(x0, x1, y0, y1, 0.004, decalMat(d.text, d.color ?? '#fff', d.bg ?? null, font, false, d.w ?? 1024, d.h ?? 256), 24, 2);
      const pl = c.body.wallPatch(x0, x1, y0, y1, 0.004, decalMat(d.text, d.color ?? '#fff', d.bg ?? null, font, true, d.w ?? 1024, d.h ?? 256), 24, 2);
      c.g.add(pr, mir(pl));
    });
  },
  chromeBelt(c) {
    const p = c.body.wallPatch(c.xRw, c.xCowl - 0.1, c.spec.beltH - 0.03, c.spec.beltH - 0.012, 0.003, c.m.chrome, 40, 1);
    c.g.add(p, mir(p));
  },
  bumpers(c) {
    const { m, halfW, xmin, xmax, clr } = c;
    const fb = rbox(0.1, 0.12, halfW * 1.9, 0.04, m.chrome);
    at(fb, xmax + 0.04, clr + 0.18, 0);
    const rb = rbox(0.1, 0.12, halfW * 1.9, 0.04, m.chrome);
    at(rb, xmin - 0.04, clr + 0.18, 0);
    for (const s of [-1, 1]) {
      const g1 = cyl(0.03, 0.03, 0.2, m.chrome, 'x', 12);
      at(g1, xmax + 0.08, clr + 0.18, s * halfW * 0.3);
      const g2 = g1.clone();
      g2.position.x = xmin - 0.08;
      add(c.g, g1, g2);
    }
    add(c.g, fb, rb);
  },
  roofRails(c) {
    const x0 = c.xRoofF - 0.1, x1 = c.xRoofR + 0.1;
    for (const s of [-1, 1]) {
      const pts: THREE.Vector3[] = [];
      for (let i = 0; i <= 12; i++) { const x = lerp(x0, x1, i / 12); pts.push(V(x, c.topAt(x) + 0.05, s * roofW(c, x) * 0.97)); }
      c.g.add(tube(pts, 0.014, c.m.black, false, 30));
      for (let i = 0; i < 4; i++) {
        const x = lerp(x0, x1, i / 3);
        const p = box(0.04, 0.05, 0.02, c.m.black);
        at(p, x, c.topAt(x) + 0.025, s * roofW(c, x) * 0.97);
        c.g.add(p);
      }
    }
  },
  roofRack(c, arg) {
    const x0 = c.xRoofF - 0.05, x1 = c.xRoofR + 0.1;
    const h = 0.1;
    const zw = (x: number) => roofW(c, x) * 0.95;
    const top = (x: number) => c.topAt(x) + 0.06 + h * 0.5;
    const m = c.m.darkMetal;
    for (const s of [-1, 1]) c.g.add(tube([V(x0, top(x0) - 0.03, s * zw(x0)), V(x1, top(x1) - 0.03, s * zw(x1))], 0.012, m, false, 6));
    const n = 6;
    for (let i = 0; i <= n; i++) {
      const x = lerp(x0, x1, i / n);
      c.g.add(tube([V(x, top(x) - 0.03, -zw(x)), V(x, top(x) - 0.03, zw(x))], 0.011, m, false, 4));
    }
    if (arg === 'basket') {
      for (const s of [-1, 1]) c.g.add(tube([V(x0, top(x0) + 0.08, s * zw(x0)), V(x1, top(x1) + 0.08, s * zw(x1))], 0.01, m, false, 6));
      c.g.add(tube([V(x0, top(x0) + 0.08, -zw(x0)), V(x0, top(x0) + 0.08, zw(x0))], 0.01, m, false, 4));
    }
  },
  topBox(c) {
    const xm = (c.xRoofF + c.xRoofR) / 2;
    const b = rbox(1.5, 0.28, 0.85, 0.12, c.m.black);
    at(b, xm, c.topAt(xm) + 0.2, 0);
    c.g.add(b);
  },
  lightbar(c, arg) {
    const xm = (c.xRoofF + c.xRoofR) / 2 + (arg ? parseFloat(arg) : 0);
    const y = c.topAt(xm) + 0.05;
    const w = Math.min(roofW(c, xm) * 1.7, c.halfW * 1.5);
    const base = rbox(0.28, 0.035, w, 0.012, c.m.black);
    at(base, xm, y, 0);
    const red = std(0xff1010, 0.2, 0, 0xff0000, 0.2), blue = std(0x1040ff, 0.2, 0, 0x0030ff, 0.2);
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, w * 0.46, 20, 1, false, 0, Math.PI), red);
    cap.rotation.x = Math.PI / 2; cap.rotation.z = Math.PI / 2;
    cap.scale.set(0.9, 1, 0.9);
    const capR = cap.clone(); capR.material = red; capR.position.set(xm, y + 0.02, -w * 0.25);
    const capB = cap.clone(); capB.material = blue; capB.position.set(xm, y + 0.02, w * 0.25);
    const mid = rbox(0.15, 0.06, w * 0.04, 0.01, c.m.white);
    at(mid, xm, y + 0.03, 0);
    add(c.g, base, capR, capB);
    c.v.anims.push((_dt, s) => {
      const ph = Math.floor(s.time * 6) % 2;
      red.emissiveIntensity = s.lights || s.speed > 0.5 ? (ph ? 3 : 0.15) : 0.2;
      blue.emissiveIntensity = s.lights || s.speed > 0.5 ? (ph ? 0.15 : 3) : 0.2;
    });
  },
  beacon(c, arg) {
    const xm = (c.xRoofF + c.xRoofR) / 2;
    const col = arg ?? '#ff9a00';
    const mat = std(col, 0.2, 0, new THREE.Color(col).getHex(), 0.3);
    const b = cyl(0.1, 0.12, 0.05, c.m.black, 'y', 20);
    at(b, xm, c.topAt(xm) + 0.05, 0);
    const d = new THREE.Mesh(new THREE.SphereGeometry(0.1, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2), mat);
    at(d, xm, c.topAt(xm) + 0.07, 0);
    add(c.g, b, d);
    c.v.anims.push((_dt, s) => { mat.emissiveIntensity = Math.floor(s.time * 3) % 2 ? 3 : 0.2; });
  },
  taxiSign(c) {
    const xm = (c.xRoofF + c.xRoofR) / 2;
    const tex = canvasTex(256, 64, (g, w, h) => { g.fillStyle = '#fff6c9'; g.fillRect(0, 0, w, h); g.fillStyle = '#111'; g.font = 'bold 48px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('TAXI', w / 2, h / 2 + 3); });
    const mat = new THREE.MeshStandardMaterial({ map: tex, emissive: 0xffe9a0, emissiveMap: tex, emissiveIntensity: 0.6 });
    const b = rbox(0.2, 0.13, 0.55, 0.04, c.m.white);
    at(b, xm, c.topAt(xm) + 0.1, 0);
    const f = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.11), mat);
    f.rotation.y = Math.PI / 2;
    at(f, xm + 0.103, c.topAt(xm) + 0.1, 0);
    const bk = f.clone(); bk.rotation.y = -Math.PI / 2; bk.position.x = xm - 0.103;
    add(c.g, b, f, bk);
  },
  fogLamps(c) {
    for (const s of [-1, 1]) {
      const p = c.body.endPoint('front', c.halfW * 0.62, c.clr + 0.14, 0.012);
      const l = cyl(0.04, 0.04, 0.02, c.m.chrome, 'x', 20);
      l.position.set(p.x, p.y, p.z * s);
      const g = new THREE.Mesh(new THREE.CircleGeometry(0.032, 20), c.m.headLamp);
      g.rotation.y = Math.PI / 2; g.position.set(p.x + 0.011, p.y, p.z * s);
      add(c.g, l, g);
    }
  },
  rallyLights(c) {
    for (const z of [-0.45, -0.15, 0.15, 0.45]) {
      const p = c.body.endPoint('front', Math.abs(z) * c.halfW * 1.4, c.spec.noseH - 0.2, 0.0);
      const l = cyl(0.065, 0.065, 0.07, c.m.black, 'x', 20);
      l.position.set(p.x + 0.03, c.spec.noseH + 0.04, z * c.halfW * 1.1);
      const g = new THREE.Mesh(new THREE.CircleGeometry(0.058, 20), c.m.headLamp);
      g.rotation.y = Math.PI / 2; g.position.set(p.x + 0.066, c.spec.noseH + 0.04, z * c.halfW * 1.1);
      add(c.g, l, g);
    }
    c.v.lightMats.head.push(c.m.headLamp);
  },
  bullbar(c) {
    const { xmax, clr, halfW, m } = c;
    const y0 = clr + 0.2, y1 = c.spec.noseH + 0.08;
    const t = (a: THREE.Vector3[], r = 0.03) => c.g.add(tube(a, r, m.black, false, 20));
    t([V(xmax - 0.1, y0, -halfW * 0.7), V(xmax + 0.16, y0 + 0.05, -halfW * 0.55), V(xmax + 0.16, y0 + 0.05, halfW * 0.55), V(xmax - 0.1, y0, halfW * 0.7)]);
    t([V(xmax + 0.12, y1, -halfW * 0.45), V(xmax + 0.16, y1, halfW * 0.45)], 0.026);
    for (const s of [-1, 1]) t([V(xmax + 0.16, y0 + 0.05, s * halfW * 0.5), V(xmax + 0.13, y1, s * halfW * 0.45), V(xmax - 0.1, y1 + 0.02, s * halfW * 0.45)], 0.026);
  },
  winch(c) {
    const b = rbox(0.18, 0.14, 0.5, 0.03, c.m.black);
    at(b, c.xmax + 0.09, c.clr + 0.2, 0);
    const d = cyl(0.045, 0.045, 0.3, c.m.darkMetal, 'z', 16);
    at(d, c.xmax + 0.1, c.clr + 0.2, 0);
    add(c.g, b, d);
  },
  snorkel(c) {
    const s = c.spec.rhd ? -1 : 1;
    const z = (c.halfW * 0.9) * s;
    c.g.add(tube([V(c.xCowl + 0.2, c.spec.hoodH - 0.2, z), V(c.xCowl - 0.05, c.spec.hoodH + 0.1, z), V(c.xCowl - 0.1, c.H + 0.08, z * 0.95), V(c.xCowl - 0.3, c.H + 0.1, z * 0.95)], 0.04, c.m.black, false, 20));
  },
  jerry(c) {
    const mat = std(0x6b7a3a, 0.6, 0.1);
    for (const z of [-0.18, 0.18]) {
      const can = rbox(0.18, 0.4, 0.35, 0.03, mat);
      at(can, c.xmin - 0.12, c.spec.beltH - 0.15, c.halfW * 0.55 * (z > 0 ? 1 : -1));
      c.g.add(can);
    }
  },
  spare(c) {
    const R = c.spec.R, rimR = c.spec.rimR;
    const w = makeWheel(c.m, { R, tw: c.spec.tw, rimR, style: c.spec.wheel ?? 'steel', rimMat: std('#9aa0a6', 0.4, 0.8), brake: false });
    const g = new THREE.Group();
    g.add(w.spin);
    g.rotation.y = -Math.PI / 2;
    g.position.set(c.xmin - c.spec.tw / 2 - 0.04, c.spec.beltH - 0.28 + R * 0.3 - 0.0, 0);
    const mount = box(0.04, 0.08, 0.1, c.m.black);
    at(mount, c.xmin - 0.02, g.position.y, 0);
    add(c.g, g, mount);
  },
  antenna(c) {
    const x = c.xRoofR + 0.1;
    const a = cyl(0.004, 0.006, 0.45, c.m.black, 'y', 6);
    at(a, x, c.topAt(x) + 0.22, c.halfW * 0.4);
    c.g.add(a);
  },
  sharkfin(c) {
    const x = c.xRoofR + 0.2;
    const f = sphere(0.1, c.m.black, 1.3, 0.35, 0.28);
    at(f, x, c.topAt(x) + 0.03, 0);
    c.g.add(f);
  },
  ornament(c) {
    const x = c.xmax - 0.2;
    const o = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.12, 12), c.m.chrome);
    o.rotation.z = -Math.PI / 2;
    at(o, x + 0.02, c.topAt(x) + 0.05, 0);
    c.g.add(o);
  },
  fenders(c) {
    // separate wing-style fenders over wheels (classic / hot rod)
    const wheels = c.v.wheels;
    const xs = [...new Set(wheels.map((w) => w.spin.parent!.position.x))];
    xs.forEach((x) => {
      const R = c.spec.R + 0.05;
      const g = new THREE.CylinderGeometry(R, R, c.spec.tw + 0.16, 40, 1, true, Math.PI / 2 - 0.6, Math.PI + 1.2);
      g.rotateX(Math.PI / 2);
      for (const s of [-1, 1]) {
        const f = new THREE.Mesh(g, c.m.paint);
        f.position.set(x, c.spec.R, s * (c.halfW - c.spec.tw / 2 - 0.02));
        c.g.add(f);
      }
    });
    const rb = rbox(c.axleF - c.axleR - 1.1, 0.04, 0.2, 0.01, c.m.black);
    for (const s of [-1, 1]) { const b = rb.clone(); b.position.set((c.axleF + c.axleR) / 2, c.clr + 0.12, s * (c.halfW + 0.04)); c.g.add(b); }
  },
  sunroof(c) {
    const x = (c.xRoofF + c.xRoofR) / 2;
    const p = rbox(0.7, 0.012, 0.7, 0.01, c.m.glass);
    at(p, x, c.topAt(x) + 0.032, 0);
    const f = rbox(0.74, 0.01, 0.74, 0.01, c.m.black);
    at(f, x, c.topAt(x) + 0.026, 0);
    add(c.g, f, p);
  },
  tonneau(c) {
    const hx0 = c.xmin + 0.12, hx1 = c.xRw - 0.04;
    const t = rbox(hx1 - hx0, 0.03, c.halfW * 1.7, 0.012, c.m.black);
    at(t, (hx0 + hx1) / 2, c.spec.beltH - 0.03, 0);
    c.g.add(t);
  },
  rollCage(c) {
    const m = c.m.black;
    const x0 = c.xCowl - 1.2, x1 = c.xCowl - 0.35;
    const w = c.halfW * 0.72;
    const h = c.spec.H - 0.05;
    const T = (pts: THREE.Vector3[]) => c.g.add(tube(pts, 0.02, m, false, 10));
    T([V(x0, c.floorY, -w), V(x0, h, -w), V(x0, h, w), V(x0, c.floorY, w)]);
    T([V(x1, c.floorY, -w), V(x1, h, -w), V(x1, h, w), V(x1, c.floorY, w)]);
    for (const s of [-1, 1]) T([V(x0, h, s * w), V(x1, h, s * w)]);
    T([V(x0, c.floorY + 0.1, -w), V(x0, h, w)]);
  },
  acUnit(c) {
    const x = c.xRoofR + 0.7;
    const b = rbox(1.0, 0.2, 0.9, 0.08, c.m.white);
    at(b, x, c.topAt(x) + 0.12, 0);
    const g = rbox(0.05, 0.1, 0.7, 0.02, c.m.black);
    at(g, x + 0.5, c.topAt(x) + 0.12, 0);
    add(c.g, b, g);
  },
  awning(c, arg) {
    const col = arg ?? '#d33';
    const x0 = (c.spec.opts?.awnX ?? [c.xmin + 1.2, c.xmin + 3.2]) as number[];
    const y = (c.spec.opts?.awnY ?? c.H - 0.9) as number;
    const mat = new THREE.MeshStandardMaterial({ map: canvasTex(256, 64, (g, w, h) => { for (let i = 0; i < 8; i++) { g.fillStyle = i % 2 ? '#fff' : col; g.fillRect((i * w) / 8, 0, w / 8, h); } }), roughness: 0.8, side: THREE.DoubleSide });
    const p = new THREE.Mesh(new THREE.PlaneGeometry(x0[1] - x0[0], 0.9), mat);
    p.rotation.x = Math.PI / 2 - 0.5;
    p.rotation.order = 'YXZ';
    p.rotation.set(-Math.PI / 2 + 0.55, 0, 0);
    p.position.set((x0[0] + x0[1]) / 2, y - 0.2, c.halfW + 0.42);
    p.rotation.y = 0;
    const sx = rbox(x0[1] - x0[0], 0.2, 0.01, 0.005, mat);
    at(sx, (x0[0] + x0[1]) / 2, y - 0.62, c.halfW + 0.84);
    add(c.g, p);
    for (const xx of x0) c.g.add(tube([V(xx, y, c.halfW), V(xx, y - 0.2, c.halfW + 0.84)], 0.012, c.m.chrome, false, 4));
  },
  serviceWindow(c) {
    const [x0, x1] = (c.spec.opts?.winX ?? [c.xmin + 1.3, c.xmin + 2.6]) as number[];
    const [y0, y1] = (c.spec.opts?.winY ?? [c.spec.beltH + 0.2, c.spec.beltH + 0.9]) as number[];
    const p = c.body.wallPatch(x0, x1, y0, y1, 0.004, c.m.black, 8, 2);
    const g = c.body.wallPatch(x0 + 0.04, x1 - 0.04, y0 + 0.04, y1 - 0.04, 0.008, c.m.glass, 8, 2);
    const counter = rbox(x1 - x0 + 0.1, 0.04, 0.3, 0.012, c.m.steel);
    at(counter, (x0 + x1) / 2, y0 - 0.02, c.halfW + 0.12);
    add(c.g, p, g, counter);
  },
  popTop(c) {
    const x0 = c.xRoofR + 0.2, x1 = c.xRoofF - 0.15;
    const b = rbox(x1 - x0, 0.14, c.halfW * 1.5, 0.05, c.m.paint);
    at(b, (x0 + x1) / 2, c.H + 0.1, 0);
    const win = rbox(x1 - x0 - 0.2, 0.06, c.halfW * 1.55, 0.02, c.m.glass);
    at(win, (x0 + x1) / 2, c.H + 0.1, 0);
    add(c.g, b, win);
  },
  roofTent(c) {
    const x0 = c.xRoofR + 0.1, x1 = c.xRoofF - 0.1;
    const xm = (x0 + x1) / 2;
    const tent = rbox(x1 - x0, 0.3, c.halfW * 1.7, 0.1, std(0x4a4f3a, 0.9));
    at(tent, xm, c.H + 0.22, 0);
    const base = rbox(x1 - x0, 0.05, c.halfW * 1.7, 0.02, c.m.black);
    at(base, xm, c.H + 0.06, 0);
    add(c.g, tent, base);
  },
  armor(c) {
    const mat = std(0x20262b, 0.6, 0.6);
    const x0 = c.xCowl - 2.2, x1 = c.xCowl - 0.25;
    for (const s of [-1, 1]) {
      const plate = rbox(x1 - x0, 0.5, 0.03, 0.01, mat);
      at(plate, (x0 + x1) / 2, c.spec.beltH - 0.25, s * (c.halfW + 0.012));
      c.g.add(plate);
    }
    const ram = rbox(0.18, 0.3, c.halfW * 1.9, 0.05, mat);
    at(ram, c.xmax + 0.02, c.clr + 0.28, 0);
    c.g.add(ram);
  },
  turret(c) {
    const xm = (c.xRoofF + c.xRoofR) / 2;
    const base = cyl(0.3, 0.32, 0.12, c.m.black, 'y', 24);
    at(base, xm, c.H + 0.08, 0);
    const shield = rbox(0.1, 0.45, 0.7, 0.04, c.m.darkMetal);
    at(shield, xm + 0.3, c.H + 0.35, 0);
    add(c.g, base, shield);
  },
  crossSign(c) {
    const t = canvasTex(128, 128, (g, w, h) => { g.fillStyle = '#fff'; g.fillRect(0, 0, w, h); g.fillStyle = '#d4101a'; g.fillRect(w * 0.4, h * 0.12, w * 0.2, h * 0.76); g.fillRect(w * 0.12, h * 0.4, w * 0.76, h * 0.2); });
    const mat = new THREE.MeshStandardMaterial({ map: t, roughness: 0.4, side: THREE.DoubleSide });
    c.spec.opts?.cross?.forEach((p: number[]) => {
      const a = c.body.wallPatch(p[0] - p[2] / 2, p[0] + p[2] / 2, p[1] - p[2] / 2, p[1] + p[2] / 2, 0.005, mat, 2, 2);
      c.g.add(a, mir(a));
    });
  },
  bookshelves(c) {
    const x0 = c.spec.opts?.shelfX?.[0] ?? c.xmin + 0.5, x1 = c.spec.opts?.shelfX?.[1] ?? c.xRoofR + 1.5;
    const y0 = c.floorY + 0.1;
    const cols = ['#b5392b', '#2d6a9f', '#e0b020', '#3b8a4f', '#7b3fa0', '#d27a2c', '#e8e2d0'];
    for (const s of [-1, 1]) {
      const back = box(x1 - x0, 1.3, 0.04, c.m.trim2);
      at(back, (x0 + x1) / 2, y0 + 0.65, s * (c.halfW - 0.18));
      c.g.add(back);
      for (let r = 0; r < 4; r++) {
        const sh = box(x1 - x0, 0.025, 0.28, c.m.trim);
        at(sh, (x0 + x1) / 2, y0 + 0.1 + r * 0.34, s * (c.halfW - 0.3));
        c.g.add(sh);
        let x = x0 + 0.05;
        let i = 0;
        while (x < x1 - 0.1) {
          const w = 0.03 + ((i * 7) % 5) * 0.008, h = 0.2 + ((i * 3) % 4) * 0.02;
          const bk = box(w, h, 0.2, std(cols[(i + r) % cols.length], 0.7));
          at(bk, x + w / 2, y0 + 0.1 + r * 0.34 + 0.0125 + h / 2, s * (c.halfW - 0.3));
          c.g.add(bk);
          x += w + 0.004; i++;
        }
      }
    }
  },
  gurney(c) {
    const x = (c.xmin + c.xRoofR) / 2 + 0.6;
    const bed = rbox(2.0, 0.05, 0.6, 0.02, c.m.white);
    at(bed, x, c.floorY + 0.55, 0.0);
    const mat = rbox(1.9, 0.08, 0.55, 0.03, std(0x3a6ea5, 0.8));
    at(mat, x, c.floorY + 0.6, 0);
    const legs = rbox(1.6, 0.3, 0.06, 0.02, c.m.steel);
    at(legs, x, c.floorY + 0.38, 0);
    add(c.g, bed, mat, legs);
  },
  casket(c) {
    const x = (c.xmin + c.xRoofR) / 2 + 0.7;
    const cb = rbox(2.1, 0.32, 0.62, 0.1, std(0x5a3320, 0.35, 0.2));
    at(cb, x, c.floorY + 0.33, 0);
    const lid = rbox(2.0, 0.05, 0.52, 0.02, std(0x6b3d25, 0.3, 0.3));
    at(lid, x, c.floorY + 0.5, 0);
    for (const k of [-0.7, -0.2, 0.3, 0.8]) for (const s of [-1, 1]) {
      const h = rbox(0.14, 0.02, 0.025, 0.008, c.m.chrome);
      at(h, x + k, c.floorY + 0.38, s * 0.325);
      c.g.add(h);
    }
    for (const s of [-1, 1]) {
      const f = rbox(1.9, 0.015, 0.12, 0.006, std(0xefe6d6, 0.8));
      at(f, x, c.floorY + 0.53, s * 0.2);
      c.g.add(f);
    }
    add(c.g, cb, lid);
  },
  cargoRack(c) {
    const x0 = c.xmin + 0.3, x1 = c.xRoofR + 0.9;
    for (const s of [-1, 1]) {
      const sh = box(x1 - x0, 0.03, 0.3, c.m.darkMetal);
      at(sh, (x0 + x1) / 2, c.floorY + 0.55, s * (c.halfW - 0.3));
      const sh2 = sh.clone(); sh2.position.y = c.floorY + 1.0;
      add(c.g, sh, sh2);
      for (let i = 0; i < 5; i++) {
        const bx = rbox(0.3, 0.3 + (i % 2) * 0.08, 0.26, 0.02, std(i % 2 ? 0xb08a55 : 0x8f6d3d, 0.9));
        at(bx, x0 + 0.25 + i * 0.4, c.floorY + 0.73, s * (c.halfW - 0.3));
        c.g.add(bx);
      }
    }
  },
  seatLeds(_c) { /* reserved */ },
};

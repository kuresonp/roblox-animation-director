import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { Mats } from './util';

type M = THREE.Material;

export function rbox(w: number, h: number, d: number, r: number, mat: M, seg = 3) {
  const g = new RoundedBoxGeometry(w, h, d, seg, Math.min(r, w / 2 - 0.0005, h / 2 - 0.0005, d / 2 - 0.0005));
  const m = new THREE.Mesh(g, mat);
  m.castShadow = true;
  return m;
}
export function box(w: number, h: number, d: number, mat: M) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.castShadow = true;
  return m;
}
/** cylinder along given axis ('x'|'y'|'z') */
export function cyl(rTop: number, rBot: number, len: number, mat: M, axis: 'x' | 'y' | 'z' = 'y', seg = 32) {
  const g = new THREE.CylinderGeometry(rTop, rBot, len, seg);
  if (axis === 'x') g.rotateZ(Math.PI / 2);
  if (axis === 'z') g.rotateX(Math.PI / 2);
  const m = new THREE.Mesh(g, mat);
  m.castShadow = true;
  return m;
}
export function sphere(r: number, mat: M, sx = 1, sy = 1, sz = 1) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(r, 24, 16), mat);
  m.scale.set(sx, sy, sz);
  m.castShadow = true;
  return m;
}
export function tube(pts: THREE.Vector3[], r: number, mat: M, closed = false, seg = 48) {
  const c = new THREE.CatmullRomCurve3(pts, closed, 'catmullrom', 0.1);
  const m = new THREE.Mesh(new THREE.TubeGeometry(c, seg, r, 10, closed), mat);
  m.castShadow = true;
  return m;
}
export function at<T extends THREE.Object3D>(o: T, x = 0, y = 0, z = 0): T {
  o.position.set(x, y, z);
  return o;
}
export function add(parent: THREE.Object3D, ...kids: THREE.Object3D[]) {
  kids.forEach((k) => parent.add(k));
  return parent;
}

// ---------------------------------------------------------------- WHEELS
export type WheelStyle = 'five' | 'multi' | 'twin' | 'mesh' | 'steel' | 'hubcap' | 'turbine' | 'classic' | 'offroad' | 'truck' | 'racing' | 'aero' | 'slick' | 'whitewall';

export interface WheelOpts {
  R: number; tw: number; rimR: number; style: WheelStyle; rimMat: M;
  caliper?: string; lugs?: boolean; brake?: boolean; whitewall?: boolean; nuts?: number;
}

export function makeWheel(m: Mats, o: WheelOpts) {
  const { R, tw, rimR } = o;
  const hw = tw / 2;
  const s = rimR / 0.2;
  const spin = new THREE.Group();
  const fixed = new THREE.Group();

  // --- tyre (lathe profile)
  const side = (hwv: number) => {
    const p: [number, number][] = [
      [rimR - 0.006, 0.6], [rimR + 0.01, 0.8], [rimR + (R - rimR) * 0.25, 0.97], [rimR + (R - rimR) * 0.55, 1.0],
      [R - (R - rimR) * 0.2, 0.95], [R - 0.014, 0.82], [R - 0.003, 0.66], [R, 0.56],
    ];
    return p.map(([r, a]) => [r, a * hwv] as [number, number]);
  };
  const half = side(hw);
  const treadHalf: [number, number][] = o.style === 'slick' ? [[R, hw * 0.3], [R, 0]] : [[R, hw * 0.46], [R - 0.007, hw * 0.4], [R - 0.007, hw * 0.3], [R, hw * 0.26], [R, hw * 0.12], [R - 0.007, hw * 0.08], [R - 0.007, 0.0]];
  const pts: THREE.Vector2[] = [];
  half.forEach(([r, a]) => pts.push(new THREE.Vector2(r, -a)));
  // tread
  const tl = treadHalf.slice(0, o.style === 'slick' ? 1 : 5).map(([r, a]) => new THREE.Vector2(r, -a));
  tl.forEach((p) => pts.push(p));
  const tr = [...tl].reverse().map((p) => new THREE.Vector2(p.x, -p.y));
  tr.forEach((p) => pts.push(p));
  [...half].reverse().forEach(([r, a]) => pts.push(new THREE.Vector2(r, a)));
  // inner wall
  pts.push(new THREE.Vector2(rimR - 0.02, hw * 0.5), new THREE.Vector2(rimR - 0.02, -hw * 0.5));
  const tg = new THREE.LatheGeometry(pts, 96);
  tg.rotateX(Math.PI / 2);
  const tireMat = o.style === 'whitewall' || o.whitewall ? m.rubber : m.rubber;
  const tire = new THREE.Mesh(tg, tireMat);
  tire.castShadow = true;
  spin.add(tire);
  if (o.style === 'whitewall' || o.whitewall) {
    const ww = new THREE.Mesh(new THREE.RingGeometry(rimR + 0.03, rimR + (R - rimR) * 0.5, 64), new THREE.MeshStandardMaterial({ color: 0xf1efe6, roughness: 0.7, side: THREE.DoubleSide }));
    ww.position.z = hw * 0.985;
    spin.add(ww);
  }
  if (o.lugs) {
    const n = 40;
    const lugGeo = new RoundedBoxGeometry(0.05, 0.05, tw * 0.9, 1, 0.012);
    for (let i = 0; i < n; i++) {
      const l = new THREE.Mesh(lugGeo, m.rubber);
      l.position.set(R - 0.004, 0, 0);
      const g2 = new THREE.Group();
      g2.add(l);
      g2.rotation.z = (i / n) * Math.PI * 2;
      spin.add(g2);
    }
  }

  // --- rim barrel
  const barrelPts = [
    [rimR + 0.014, hw * 0.86], [rimR + 0.014, hw * 0.78], [rimR - 0.004, hw * 0.74], [rimR - 0.026 * s, hw * 0.55], [rimR - 0.026 * s, -hw * 0.7], [rimR + 0.005, -hw * 0.8],
  ].map(([r, a]) => new THREE.Vector2(r, a));
  const bg = new THREE.LatheGeometry(barrelPts, 64);
  bg.rotateX(Math.PI / 2);
  spin.add(new THREE.Mesh(bg, o.rimMat));

  // --- rim face
  const face = new THREE.Group();
  const zf = hw * 0.5;
  face.position.z = zf;
  const inner = rimR - 0.02 * s;
  const hub = 0.062 * s;
  const addSpokes = (n: number, wRoot: number, wTip: number, depth: number, rot = 0, twist = 0) => {
    for (let i = 0; i < n; i++) {
      const sh = new THREE.Shape();
      sh.moveTo(hub * 0.7, -wRoot / 2);
      sh.lineTo(inner, -wTip / 2);
      sh.lineTo(inner, wTip / 2);
      sh.lineTo(hub * 0.7, wRoot / 2);
      sh.closePath();
      const g = new THREE.ExtrudeGeometry(sh, { depth, bevelEnabled: true, bevelThickness: depth * 0.25, bevelSize: depth * 0.2, bevelSegments: 1 });
      const mesh = new THREE.Mesh(g, o.rimMat);
      mesh.rotation.z = rot + (i / n) * Math.PI * 2 + twist;
      mesh.position.z = -depth * 0.5;
      face.add(mesh);
    }
  };
  const backDisc = new THREE.Mesh(new THREE.CircleGeometry(inner, 48), m.darkMetal);
  backDisc.position.z = zf - hw * 0.28;
  spin.add(backDisc);
  const centerCap = cyl(hub, hub * 1.05, 0.03 * s, o.rimMat, 'z', 32);
  centerCap.position.z = 0.012 * s;
  face.add(centerCap);
  const logo = new THREE.Mesh(new THREE.CircleGeometry(hub * 0.55, 24), new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.4, metalness: 0.7 }));
  logo.position.z = 0.028 * s;
  face.add(logo);

  switch (o.style) {
    case 'five': addSpokes(5, 0.07 * s, 0.1 * s, 0.03 * s); break;
    case 'multi': addSpokes(10, 0.034 * s, 0.05 * s, 0.026 * s); break;
    case 'twin': addSpokes(10, 0.028 * s, 0.04 * s, 0.026 * s, 0, 0); addSpokes(10, 0.028 * s, 0.04 * s, 0.026 * s, Math.PI / 10 * 0.5, 0.04); break;
    case 'turbine': addSpokes(14, 0.04 * s, 0.06 * s, 0.024 * s, 0, 0.35); break;
    case 'racing': case 'slick': addSpokes(6, 0.075 * s, 0.1 * s, 0.03 * s); break;
    case 'offroad': {
      addSpokes(8, 0.07 * s, 0.09 * s, 0.04 * s);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(rimR - 0.004, 0.012 * s, 8, 48), m.black);
      ring.position.z = hw * 0.4; spin.add(ring);
      for (let i = 0; i < 24; i++) {
        const a = (i / 24) * Math.PI * 2;
        const b = cyl(0.007 * s, 0.007 * s, 0.014, m.steel, 'z', 8);
        b.position.set(Math.cos(a) * (rimR - 0.004), Math.sin(a) * (rimR - 0.004), hw * 0.4 + 0.012);
        spin.add(b);
      }
      break;
    }
    case 'mesh': {
      for (let k = 0; k < 2; k++) addSpokes(18, 0.014 * s, 0.022 * s, 0.014 * s, 0, k ? 0.28 : -0.28);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(inner * 0.55, 0.008 * s, 6, 40), o.rimMat);
      face.add(ring);
      break;
    }
    case 'classic': {
      for (let i = 0; i < 36; i++) {
        const a = (i / 36) * Math.PI * 2;
        const wire = cyl(0.0022, 0.0022, 1, o.rimMat, 'y', 4);
        const rr = inner - 0.005;
        const hubR = hub * 1.05;
        const len = Math.hypot(rr - hubR, 0.06);
        wire.scale.y = len;
        const mid = (rr + hubR) / 2;
        const sgn = i % 2 ? 1 : -1;
        wire.position.set(Math.cos(a) * mid, Math.sin(a) * mid, -0.03 * 0.5 * sgn * 0);
        wire.rotation.z = a - Math.PI / 2;
        const tilt = new THREE.Group();
        tilt.add(wire);
        face.add(tilt);
        wire.rotateX(sgn * 0.12);
      }
      const nut = cyl(hub * 0.9, hub * 0.7, 0.05, o.rimMat, 'z', 6);
      face.add(nut);
      break;
    }
    case 'steel': case 'hubcap': case 'truck': case 'aero': case 'whitewall': {
      const holes = o.style === 'steel' ? 6 : 0;
      const sh = new THREE.Shape();
      sh.absarc(0, 0, inner, 0, Math.PI * 2, false);
      for (let i = 0; i < holes; i++) {
        const a = (i / holes) * Math.PI * 2;
        const h = new THREE.Path();
        h.absarc(Math.cos(a) * inner * 0.62, Math.sin(a) * inner * 0.62, inner * 0.14, 0, Math.PI * 2, true);
        sh.holes.push(h);
      }
      const dg = new THREE.ExtrudeGeometry(sh, { depth: 0.012, bevelEnabled: false, curveSegments: 32 });
      const disc = new THREE.Mesh(dg, o.style === 'truck' || o.style === 'steel' ? new THREE.MeshStandardMaterial({ color: o.style === 'truck' ? 0xc9ccd0 : 0x6b7077, roughness: 0.5, metalness: 0.6 }) : o.rimMat);
      disc.position.z = -0.012;
      face.add(disc);
      if (o.style === 'hubcap' || o.style === 'whitewall') {
        for (let i = 1; i <= 3; i++) {
          const ring = new THREE.Mesh(new THREE.TorusGeometry(inner * (0.3 + i * 0.18), 0.004 * s, 6, 48), o.rimMat);
          ring.position.z = 0.004; face.add(ring);
        }
        const dome = new THREE.Mesh(new THREE.SphereGeometry(hub * 1.6, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), o.rimMat);
        dome.rotation.x = Math.PI / 2; dome.scale.set(1, 0.4, 1); dome.rotation.x = Math.PI / 2; face.add(dome);
      }
      if (o.style === 'aero') {
        for (let i = 0; i < 12; i++) {
          const a = (i / 12) * Math.PI * 2;
          const sl = box(0.05 * s, 0.01, 0.006, m.black);
          sl.position.set(Math.cos(a) * inner * 0.8, Math.sin(a) * inner * 0.8, 0.006);
          sl.rotation.z = a + Math.PI / 2;
          face.add(sl);
        }
      }
      if (o.style === 'truck') {
        const bigHub = cyl(hub * 2.2, hub * 2.5, 0.07, new THREE.MeshStandardMaterial({ color: 0xb7bcc2, roughness: 0.4, metalness: 0.8 }), 'z', 24);
        bigHub.position.z = 0.03;
        face.add(bigHub);
        const tops = 10;
        for (let i = 0; i < tops; i++) {
          const a = (i / tops) * Math.PI * 2;
          const n = cyl(0.014 * s, 0.014 * s, 0.03, m.steel, 'z', 6);
          n.position.set(Math.cos(a) * inner * 0.62, Math.sin(a) * inner * 0.62, 0.012);
          face.add(n);
        }
      }
      break;
    }
  }
  // lug nuts
  if (!['truck', 'classic', 'steel', 'hubcap', 'whitewall'].includes(o.style)) {
    const nn = o.nuts ?? 5;
    for (let i = 0; i < nn; i++) {
      const a = (i / nn) * Math.PI * 2 + 0.3;
      const n = cyl(0.0085 * s, 0.0085 * s, 0.018, m.steel, 'z', 6);
      n.position.set(Math.cos(a) * hub * 0.82, Math.sin(a) * hub * 0.82, 0.022 * s);
      face.add(n);
    }
  }
  spin.add(face);

  // --- brakes
  if (o.brake !== false) {
    const dz = hw * 0.2;
    const disc = new THREE.Mesh(new THREE.CylinderGeometry(inner * 0.86, inner * 0.86, 0.026, 48), m.steel);
    disc.rotation.x = Math.PI / 2;
    disc.position.z = dz;
    spin.add(disc);
    const hat = cyl(hub * 1.4, hub * 1.4, 0.05, m.darkMetal, 'z', 24);
    hat.position.z = dz + 0.01;
    spin.add(hat);
    const cal = rbox(0.16 * s, inner * 0.38, 0.09, 0.012, new THREE.MeshStandardMaterial({ color: o.caliper ?? '#b3121a', roughness: 0.35, metalness: 0.4 }));
    cal.position.set(inner * 0.62 * Math.cos(0.5), inner * 0.62 * Math.sin(0.5), dz + 0.005);
    cal.rotation.z = 0.5 - Math.PI / 2;
    fixed.add(cal);
  }
  return { spin, fixed };
}

// ---------------------------------------------------------------- SEATS
export interface SeatOpts { w?: number; h?: number; kind?: 'bucket' | 'bench' | 'sport' | 'bus' | 'racing'; headrests?: number; back?: number; }

/** Seat centred on origin at floor level, facing +X. */
export function makeSeat(m: Mats, o: SeatOpts = {}) {
  const g = new THREE.Group();
  const kind = o.kind ?? 'bucket';
  const w = o.w ?? (kind === 'bench' ? 1.3 : 0.5);
  const h = o.h ?? 0.3;
  const backH = (o.back ?? 0.62) * (kind === 'sport' || kind === 'racing' ? 1.15 : 1);
  const bolster = kind === 'sport' || kind === 'racing' ? 0.07 : 0.035;
  const rail = rbox(0.42, 0.04, w * 0.82, 0.01, m.darkMetal);
  rail.position.set(0, 0.02 + (h > 0.4 ? 0.03 : 0), 0);
  const pedestal = box(0.34, Math.max(0.02, h - 0.17), w * 0.5, m.black);
  pedestal.position.set(-0.02, 0.04 + (h - 0.17) / 2 + 0.01, 0);
  g.add(rail, pedestal);
  const cushion = rbox(0.5, 0.13, w, 0.05, m.trim);
  cushion.position.set(0.02, h - 0.065, 0);
  cushion.rotation.z = 0.05;
  g.add(cushion);
  const ins = rbox(0.4, 0.02, w * 0.62, 0.008, m.trim2);
  ins.position.set(0.02, h + 0.004, 0);
  ins.rotation.z = 0.05;
  g.add(ins);
  for (const sgn of [-1, 1]) {
    const b = rbox(0.46, 0.05, bolster, 0.02, m.trim);
    b.position.set(0.02, h + 0.01, sgn * (w / 2 - bolster / 2));
    g.add(b);
  }
  const back = new THREE.Group();
  back.position.set(-0.24, h - 0.04, 0);
  back.rotation.z = kind === 'bus' ? 0.1 : 0.22;
  const bb = rbox(0.11, backH, w * 0.98, 0.05, m.trim);
  bb.position.set(0, backH / 2, 0);
  back.add(bb);
  const binset = rbox(0.02, backH * 0.72, w * 0.6, 0.008, m.trim2);
  binset.position.set(0.058, backH * 0.46, 0);
  back.add(binset);
  for (const sgn of [-1, 1]) {
    const sb = rbox(0.14, backH * 0.8, bolster * 1.2, 0.025, m.trim);
    sb.position.set(0.02, backH * 0.42, sgn * (w / 2 - bolster * 0.4));
    back.add(sb);
  }
  const nh = o.headrests ?? (kind === 'bench' ? 3 : 1);
  const integrated = kind === 'racing';
  for (let i = 0; i < nh; i++) {
    const zc = nh === 1 ? 0 : (i - (nh - 1) / 2) * (w / nh);
    const hr = rbox(0.09, integrated ? 0.26 : 0.17, Math.min(0.22, (w / nh) * 0.7), 0.04, m.trim);
    hr.position.set(0.0, backH + (integrated ? 0.0 : 0.1), zc);
    back.add(hr);
    if (!integrated) for (const sgn of [-1, 1]) {
      const post = cyl(0.007, 0.007, 0.1, m.chrome, 'y', 8);
      post.position.set(0, backH + 0.01, zc + sgn * 0.04);
      back.add(post);
    }
  }
  g.add(back);
  return g;
}

// ---------------------------------------------------------------- STEERING
export function makeSteeringWheel(m: Mats, r = 0.185, sport = false) {
  const root = new THREE.Group();
  const face = new THREE.Group(); // oriented so +Z points to driver
  face.rotation.y = -Math.PI / 2;
  const spinG = new THREE.Group();
  face.add(spinG);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(r, 0.0165, 16, 56), m.trim2);
  spinG.add(ring);
  if (sport) {
    const flat = rbox(r * 1.0, 0.04, 0.034, 0.012, m.trim2);
    flat.position.y = -r;
    spinG.add(flat);
  }
  for (const a of [Math.PI, 0, -Math.PI / 2]) {
    const sp = rbox(r * 0.92, 0.03, 0.016, 0.006, m.darkMetal);
    sp.position.set(Math.cos(a) * r * 0.46, Math.sin(a) * r * 0.46, -0.005);
    sp.rotation.z = a;
    spinG.add(sp);
  }
  const pad = rbox(0.1, 0.1, 0.05, 0.022, m.trim2);
  pad.position.z = 0.0;
  spinG.add(pad);
  const badge = new THREE.Mesh(new THREE.CircleGeometry(0.02, 20), m.chrome);
  badge.position.z = 0.0275;
  spinG.add(badge);
  const col = cyl(0.03, 0.036, 0.3, m.black, 'z', 16);
  col.position.z = -0.17;
  face.add(col);
  const cover = rbox(0.1, 0.09, 0.14, 0.03, m.black);
  cover.position.z = -0.1;
  face.add(cover);
  for (const sgn of [-1, 1]) {
    const st = cyl(0.007, 0.007, 0.1, m.black, 'x', 8);
    st.position.set(sgn * 0.07, 0.0, -0.1);
    st.rotation.z = sgn * 0.0;
    face.add(st);
  }
  const tilt = new THREE.Group();
  tilt.rotation.z = -0.42;
  tilt.add(face);
  root.add(tilt);
  return { root, spinG };
}

export function makeMirror(m: Mats, paint: M, big = false) {
  const g = new THREE.Group();
  const s = big ? 1.7 : 1;
  const housing = rbox(0.1 * s, 0.075 * s, 0.17 * s, 0.03, paint);
  housing.position.set(-0.01, 0, 0.1 * s);
  const glass = new THREE.Mesh(new THREE.PlaneGeometry(0.15 * s, 0.065 * s), new THREE.MeshStandardMaterial({ color: 0x9aa7b0, metalness: 1, roughness: 0.04 }));
  glass.position.set(-0.062 * s, 0, 0.1 * s);
  glass.rotation.y = -Math.PI / 2 - 0.1;
  const stem = rbox(0.045 * s, 0.03 * s, 0.07 * s, 0.01, m.black);
  stem.position.set(0.0, -0.02 * s, 0.01);
  g.add(housing, glass, stem);
  return g;
}

export function makeHandle(m: Mats, paint: M) {
  const g = new THREE.Group();
  const pocket = rbox(0.17, 0.03, 0.006, 0.006, m.black);
  const h = rbox(0.15, 0.022, 0.016, 0.008, paint);
  h.position.z = 0.008;
  g.add(pocket, h);
  return g;
}

export function makeExhaustTip(m: Mats, r = 0.04, len = 0.1) {
  const g = new THREE.Group();
  const t = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 0.92, len, 28, 1, true), m.chrome);
  t.rotation.z = Math.PI / 2;
  const inn = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.85, r * 0.85, len * 0.9, 24, 1, true), m.black);
  inn.rotation.z = Math.PI / 2;
  g.add(t, inn);
  return g;
}

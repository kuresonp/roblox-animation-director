import * as THREE from 'three';
import { CarSpec, Vehicle } from './types';
import { buildBody, DoorRig } from './loft';
import { makeMats, pchip, lerp, canvasTex } from './util';
import { rbox, box, cyl, tube, at, add, makeWheel, sphere, makeSteeringWheel, makeSeat } from './parts';

const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
const std = (c: number | string, r = 0.5, m = 0) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, side: THREE.DoubleSide });

function wheelAt(v: Vehicle, x: number, z: number, R: number, tw: number, rimR: number, style: any, steer: boolean, rimMat: THREE.Material, lugs = false) {
  for (const s of [-1, 1]) {
    const hub = new THREE.Group();
    hub.position.set(x, R, s * z);
    const w = makeWheel(v.mats, { R, tw, rimR, style, rimMat, lugs, caliper: '#d11' });
    const sp = new THREE.Group(); const fl = new THREE.Group(); fl.rotation.y = s < 0 ? Math.PI : 0; fl.add(w.spin); sp.add(fl);
    const ff = new THREE.Group(); ff.rotation.y = s < 0 ? Math.PI : 0; ff.add(w.fixed);
    hub.add(sp, ff); v.group.add(hub);
    v.wheels.push({ steer: steer ? hub : null, spin: sp, R, side: s });
  }
}
const rig = (pivot: THREE.Group, side: number, x0: number, x1: number, hinge: 'front' | 'rear', angle = 1.2): DoorRig => ({
  pivot, spec: { side: side < 0 ? 'L' : 'R', x0, x1, hinge }, side, t: 0, target: 0, angle, len: x1 - x0, px: pivot.position.x, pz: pivot.position.z,
});
const lift = (v: Vehicle, obj: THREE.Object3D, side: number, max: number, axis: 'x' | 'z' = 'x') => {
  let cur = 0;
  v.anims.push((dt, s) => { const tg = side < 0 ? s.doorL : s.doorR; cur += (tg - cur) * Math.min(1, dt * 4); obj.rotation[axis] = cur * max * (axis === 'x' ? -side : 1); });
};

export function buildSpecial(spec: CarSpec): Vehicle {
  const kind = spec.opts?.special as string;
  const v = new Vehicle();
  const m = makeMats(spec.color, spec.interior, { color2: spec.color2, matte: spec.matte, trim2: spec.trim2 });
  v.mats = m;
  const g = v.group;
  const rimMat = new THREE.MeshStandardMaterial({ color: spec.rimColor ?? '#c9ced4', metalness: 0.95, roughness: 0.2 });
  const tub = (pts: number[][], r = 0.022, mat: THREE.Material = m.chrome) => { g.add(tube(pts.map((p) => V(p[0], p[1], p[2])), r, mat, false, 24)); };
  const sym = (fn: (s: number) => void) => { fn(1); fn(-1); };

  if (kind === 'formula') {
    const xmin = -2.3, xmax = 2.6;
    const top = pchip([xmin, -1.9, -1.2, -0.7, -0.2, 0.5, 1.0, 1.8, xmax], [0.38, 0.62, 0.98, 0.9, 0.66, 0.6, 0.42, 0.3, 0.22]);
    const bot = pchip([xmin, -1.6, 2.0, xmax], [0.18, 0.1, 0.08, 0.16]);
    const wm = pchip([xmin, -1.8, -1.1, -0.2, 0.4, 1.0, 1.8, xmax], [0.22, 0.36, 0.82, 1.0, 0.62, 0.42, 0.26, 0.15]);
    const body = buildBody({
      xmin, xmax, top, bottom: bot, belt: (x) => top(x) - 0.002, halfW: 0.55, wMul: wm, rl: 0.05, rs: 0.1, rr: 0.03, roofRatio: 0.8, bulge: 0, crown: 0.04, hoodCrown: 0.05,
      planN: 2.2, rfF: 0.5, rfR: 0.5, cabinH: 0.2, arches: [], doors: [], windows: [], topGlass: [], holes: [{ x0: -0.15, x1: 0.85, rowFrom: 18 }], M: m,
    });
    g.add(body.group);
    const floor = box(4.6, 0.025, 1.2, m.black); at(floor, 0.1, 0.07, 0); g.add(floor);
    const sp = sphere(0.14, std('#f2f2f2', 0.2, 0.4), 1.1, 1.05, 1); at(sp, 0.12, 0.72, 0); g.add(sp);
    const visor = box(0.1, 0.07, 0.2, m.black); at(visor, 0.24, 0.74, 0); g.add(visor);
    const tub2 = rbox(1.0, 0.4, 0.5, 0.15, m.trim); at(tub2, 0.35, 0.38, 0); g.add(tub2);
    const sw = rbox(0.05, 0.12, 0.28, 0.03, m.black); at(sw, 0.62, 0.62, 0); sw.rotation.z = -0.5; g.add(sw);
    const sc = box(0.02, 0.04, 0.1, std('#00d1ff', 0.3)); at(sc, 0.605, 0.67, 0); sc.rotation.z = -0.5; g.add(sc);
    // halo
    tub([[0.05, 0.62, -0.28], [0.45, 0.98, -0.12], [0.85, 0.7, 0]], 0.03, m.darkMetal);
    tub([[0.05, 0.62, 0.28], [0.45, 0.98, 0.12], [0.85, 0.7, 0]], 0.03, m.darkMetal);
    tub([[0.05, 0.62, -0.28], [-0.05, 0.9, 0], [0.05, 0.62, 0.28]], 0.03, m.darkMetal);
    // wings
    const fw = rbox(0.4, 0.04, 1.9, 0.015, m.paint2); at(fw, 2.5, 0.12, 0); g.add(fw);
    const fw2 = rbox(0.3, 0.03, 1.8, 0.012, m.paint); at(fw2, 2.35, 0.2, 0); fw2.rotation.z = 0.1; g.add(fw2);
    sym((s) => { const ep = rbox(0.55, 0.28, 0.025, 0.01, m.paint); at(ep, 2.42, 0.2, s * 0.95); g.add(ep); const rp = rbox(0.9, 0.5, 0.03, 0.01, m.paint); at(rp, -2.15, 0.62, s * 0.5); g.add(rp); const st = box(0.06, 0.55, 0.03, m.darkMetal); at(st, -1.95, 0.5, s * 0.1); g.add(st); });
    const rw = rbox(0.55, 0.05, 1.0, 0.015, m.paint); at(rw, -2.15, 0.85, 0); g.add(rw);
    const rw2 = rbox(0.4, 0.04, 1.0, 0.015, m.paint); at(rw2, -2.12, 0.65, 0); rw2.rotation.z = 0.15; g.add(rw2);
    const ac = cyl(0.04, 0.05, 0.4, m.chrome, 'x', 12); at(ac, -2.35, 0.3, 0); g.add(ac);
    const bw = rbox(0.5, 0.025, 0.6, 0.01, m.black); at(bw, -2.0, 0.1, 0); g.add(bw);
    // sidepods + intakes
    sym((s) => { const ip = rbox(0.5, 0.3, 0.1, 0.04, m.black); at(ip, -0.2, 0.5, s * 0.58); g.add(ip); const mir = rbox(0.12, 0.07, 0.14, 0.03, m.paint); at(mir, 0.7, 0.72, s * 0.6); g.add(mir);
      // suspension
      tub([[1.6, 0.3, s * 0.8], [1.5, 0.28, s * 0.3]], 0.015, m.darkMetal); tub([[1.8, 0.32, s * 0.8], [1.45, 0.34, s * 0.3]], 0.015, m.darkMetal); tub([[1.7, 0.5, s * 0.8], [1.5, 0.32, s * 0.28]], 0.015, m.darkMetal);
      tub([[-1.7, 0.3, s * 0.8], [-1.5, 0.28, s * 0.35]], 0.015, m.darkMetal); tub([[-1.9, 0.34, s * 0.8], [-1.45, 0.36, s * 0.3]], 0.015, m.darkMetal);
      // flaps
      const piv = new THREE.Group(); piv.position.set(-0.5, 0.72, s * 0.28);
      const fl = rbox(0.9, 0.025, 0.32, 0.01, m.paint); at(fl, 0, 0, s * 0.16); piv.add(fl); g.add(piv);
      lift(v, piv, s, 1.0);
    });
    wheelAt(v, 1.7, 0.82, 0.33, 0.3, 0.2, 'racing', true, rimMat);
    wheelAt(v, -1.7, 0.8, 0.36, 0.42, 0.2, 'racing', false, rimMat);
    v.eye.set(0.2, 0.78, 0);
    v.size = { L: 5.0, W: 2.0, H: 1.1 };
    const sw2 = makeSteeringWheel(m, 0.1); sw2.root.position.set(0.5, 0.6, 0); void sw2;
  } else if (kind === 'dragster') {
    const fus = new THREE.Mesh(new THREE.CapsuleGeometry(0.2, 5.2, 12, 24), m.paint); fus.rotation.z = Math.PI / 2; fus.scale.set(1, 1, 0.8); at(fus, 1.2, 0.32, 0); g.add(fus);
    const cowl = rbox(1.2, 0.25, 0.5, 0.12, m.paint); at(cowl, 0.2, 0.5, 0); g.add(cowl);
    tub([[1.0, 0.3, 0.35], [-2.2, 0.35, 0.4], [-2.2, 0.35, -0.4], [1.0, 0.3, -0.35]], 0.025, m.chrome);
    tub([[0.6, 0.45, 0.28], [0.5, 0.95, 0.2], [0.0, 1.0, 0.2], [-0.2, 0.45, 0.3]], 0.03, m.chrome);
    tub([[0.6, 0.45, -0.28], [0.5, 0.95, -0.2], [0.0, 1.0, -0.2], [-0.2, 0.45, -0.3]], 0.03, m.chrome);
    tub([[0.5, 0.95, 0.2], [0.5, 0.95, -0.2]], 0.03, m.chrome); tub([[0.0, 1.0, 0.2], [0.0, 1.0, -0.2]], 0.03, m.chrome);
    const hel = sphere(0.14, std('#ff6a00', 0.2, 0.3)); at(hel, 0.3, 0.7, 0); g.add(hel);
    const seat = rbox(0.5, 0.25, 0.4, 0.08, m.trim); at(seat, 0.1, 0.45, 0); g.add(seat);
    // engine
    const eng = rbox(1.0, 0.5, 0.7, 0.06, m.darkMetal); at(eng, -1.3, 0.55, 0); g.add(eng);
    const blower = rbox(0.6, 0.18, 0.5, 0.04, m.chrome); at(blower, -1.3, 0.92, 0); g.add(blower);
    const scoop = cyl(0.17, 0.2, 0.3, m.black, 'y', 20); at(scoop, -1.3, 1.1, 0); g.add(scoop);
    for (let i = 0; i < 4; i++) sym((s) => { const st = cyl(0.045, 0.06, 0.65, m.chrome, 'y', 10); at(st, -1.0 - i * 0.22, 1.0, s * 0.2); st.rotation.z = 0; g.add(st); const ex = cyl(0.04, 0.04, 0.5, m.steel, 'z', 10); at(ex, -1.0 - i * 0.22, 0.52, s * 0.5); g.add(ex); });
    const rw = rbox(0.7, 0.05, 1.6, 0.02, m.paint2); at(rw, -3.05, 1.35, 0); g.add(rw);
    const rw2 = rbox(0.5, 0.04, 1.5, 0.02, m.paint); at(rw2, -3.0, 1.1, 0); rw2.rotation.z = 0.15; g.add(rw2);
    sym((s) => { const ep = rbox(0.9, 0.55, 0.03, 0.01, m.paint2); at(ep, -3.0, 1.2, s * 0.8); g.add(ep); const st = box(0.06, 1.0, 0.04, m.darkMetal); at(st, -2.9, 0.8, s * 0.3); g.add(st);
      const piv = new THREE.Group(); piv.position.set(0.3, 0.62, s * 0.24); const fl = rbox(0.8, 0.02, 0.22, 0.008, m.paint); at(fl, 0, 0, s * 0.11); piv.add(fl); g.add(piv); lift(v, piv, s, 1.0);
      tub([[2.7, 0.2, s * 0.16], [2.7, 0.2, s * 0.3]], 0.012, m.darkMetal);
    });
    const wb = tube([V(-3.3, 0.32, 0), V(-3.9, 0.15, 0)], 0.02, m.chrome); g.add(wb);
    const chute = cyl(0.2, 0.2, 0.5, m.black, 'z', 16); at(chute, -3.05, 0.9, 0); g.add(chute);
    wheelAt(v, -2.5, 0.55, 0.45, 0.45, 0.2, 'slick', false, rimMat);
    for (const s of [-1, 1]) { const fw = makeWheel(m, { R: 0.3, tw: 0.07, rimR: 0.2, style: 'multi', rimMat, brake: false }); const hub = new THREE.Group(); hub.position.set(2.6, 0.3, s * 0.2); const sp = new THREE.Group(); const fl = new THREE.Group(); fl.rotation.y = s < 0 ? Math.PI : 0; fl.add(fw.spin); sp.add(fl); hub.add(sp); g.add(hub); v.wheels.push({ steer: hub, spin: sp, R: 0.3, side: s }); }
    tub([[2.6, 0.3, 0.1], [2.6, 0.3, -0.1]], 0.015, m.darkMetal);
    v.eye.set(0.1, 0.78, 0);
    v.size = { L: 7.5, W: 2.0, H: 1.5 };
    g.position.x = 0.5; v.eye.x += 0.5;
  } else if (kind === 'sandrail') {
    const T = (pts: number[][], r = 0.028) => tub(pts, r, m.paint);
    sym((s) => {
      T([[1.4, 0.35, s * 0.3], [0.3, 0.38, s * 0.6], [-1.3, 0.4, s * 0.55], [-1.7, 0.5, s * 0.3]], 0.035);
      T([[0.3, 0.38, s * 0.6], [0.2, 1.0, s * 0.55], [-0.5, 1.6, s * 0.5], [-1.3, 1.45, s * 0.5]]);
      T([[-1.3, 0.4, s * 0.55], [-1.3, 1.45, s * 0.5]]);
      T([[0.2, 1.0, s * 0.55], [-0.3, 1.0, s * 0.6], [-1.0, 0.95, s * 0.58]]);
      T([[1.4, 0.35, s * 0.3], [1.4, 0.8, s * 0.3], [0.9, 1.15, s * 0.45], [0.2, 1.0, s * 0.55]]);
      T([[-0.5, 1.6, s * 0.5], [-0.5, 0.95, s * 0.58]]);
      T([[-0.1, 0.4, s * 0.6], [-0.1, 1.0, s * 0.58]]);
      // half door frames
      const piv = new THREE.Group(); piv.position.set(0.2, 0, s * 0.6);
      const f = tube([V(-0.0, 0.5, 0), V(-0.55, 0.5, 0), V(-0.55, 0.95, 0), V(0, 0.95, 0), V(0, 0.5, 0)], 0.025, m.paint, false, 24); piv.add(f);
      const cr = tube([V(-0.0, 0.72, 0), V(-0.55, 0.72, 0)], 0.02, m.paint, false, 4); piv.add(cr);
      g.add(piv);
      v.doors.push(rig(piv, s, -0.35, 0.2, 'front', 1.3));
    });
    T([[1.4, 0.35, 0.3], [1.55, 0.35, 0], [1.4, 0.35, -0.3]]);
    T([[-1.7, 0.5, 0.3], [-1.8, 0.5, 0], [-1.7, 0.5, -0.3]]);
    T([[-0.5, 1.6, 0.5], [-0.5, 1.6, -0.5]]); T([[-1.3, 1.45, 0.5], [-1.3, 1.45, -0.5]]);
    T([[1.4, 0.8, 0.3], [1.4, 0.8, -0.3]]);
    const floor = box(2.6, 0.03, 1.0, m.darkMetal); at(floor, -0.1, 0.4, 0); g.add(floor);
    const nose = rbox(0.5, 0.35, 0.6, 0.12, m.paint); at(nose, 1.5, 0.55, 0); g.add(nose);
    const lamp = cyl(0.07, 0.07, 0.05, m.headLamp, 'x', 18); at(lamp, 1.76, 0.6, 0.15); g.add(lamp); const lamp2 = lamp.clone(); lamp2.position.z = -0.15; g.add(lamp2); v.lightMats.head.push(m.headLamp);
    const eng = rbox(0.9, 0.55, 0.7, 0.06, m.darkMetal); at(eng, -1.3, 0.75, 0); g.add(eng);
    for (let i = 0; i < 4; i++) sym((s) => { const hd = cyl(0.04, 0.04, 0.5, m.steel, 'x', 8); at(hd, -1.55, 0.55 + i * 0.0, s * (0.15 + i * 0.01)); g.add(hd); });
    sym((s) => { const sh = makeSeat(m, { kind: 'racing', w: 0.42, h: 0.2 }); at(sh, -0.45, 0.4, s * 0.25); g.add(sh); const sw = makeSteeringWheel(m, 0.15); at(sw.root, 0.3, 0.85, s * 0.25); if (s < 0) { g.add(sw.root); v.steerWheel = sw.spinG; } });
    sym((s) => { const a = tube([V(1.4, 0.42, s * 0.3), V(1.35, 0.4, s * 0.85)], 0.02, m.darkMetal); g.add(a); const a2 = tube([V(1.2, 0.42, s * 0.3), V(1.35, 0.4, s * 0.85)], 0.02, m.darkMetal); g.add(a2); const b = tube([V(-1.5, 0.42, s * 0.35), V(-1.5, 0.45, s * 0.95)], 0.025, m.darkMetal); g.add(b); const sh = cyl(0.03, 0.03, 0.5, m.steel, 'y', 8); at(sh, -1.5, 0.6, s * 0.8); g.add(sh); });
    wheelAt(v, 1.35, 0.9, 0.33, 0.18, 0.2, 'multi', true, rimMat);
    wheelAt(v, -1.5, 0.95, 0.5, 0.45, 0.22, 'offroad', false, rimMat, true);
    v.eye.set(-0.4, 1.0, -0.25);
    v.size = { L: 3.9, W: 2.1, H: 1.7 };
    g.position.x = 0.0;
  } else if (kind === 'tank') {
    const olive = new THREE.MeshStandardMaterial({ color: spec.color, roughness: 0.75, metalness: 0.25, side: THREE.DoubleSide });
    const dark = std('#2e3329', 0.85, 0.3);
    // hull side profile extruded across width
    const sh = new THREE.Shape();
    const pts: [number, number][] = [[-3.5, 0.75], [-3.5, 1.35], [-2.3, 1.6], [0.9, 1.6], [3.0, 1.35], [3.7, 1.0], [3.5, 0.65], [3.0, 0.6], [-3.0, 0.6]];
    sh.moveTo(pts[0][0], pts[0][1]); pts.slice(1).forEach((p) => sh.lineTo(p[0], p[1])); sh.closePath();
    const hullG = new THREE.ExtrudeGeometry(sh, { depth: 2.2, bevelEnabled: true, bevelSize: 0.1, bevelThickness: 0.1, bevelSegments: 3 });
    hullG.translate(0, 0, -1.1);
    const hull = new THREE.Mesh(hullG, olive); hull.castShadow = true; g.add(hull);
    // track guards
    sym((s) => {
      const gd = rbox(7.6, 0.1, 0.9, 0.04, olive); at(gd, -0.1, 1.15, s * 1.45); g.add(gd);
      const sk = rbox(6.6, 0.55, 0.06, 0.02, olive); at(sk, -0.1, 0.9, s * 1.12); g.add(sk);
      for (let i = 0; i < 10; i++) { const rl = box(0.06, 0.06, 0.1, dark); void rl; }
      const box1 = rbox(1.3, 0.45, 0.4, 0.04, dark); at(box1, -2.3, 1.45, s * 1.45); g.add(box1);
      const lt = cyl(0.12, 0.12, 0.5, dark, 'z', 10); at(lt, -3.3, 1.3, s * 1.2); g.add(lt);
      // tracks
      const N = 150, Ls = 2.9, r = 0.62, P = 4 * Ls + 2 * Math.PI * r;
      const inst = new THREE.InstancedMesh(new THREE.BoxGeometry(0.1, 0.05, 0.72), std('#232323', 0.7, 0.5), N);
      inst.castShadow = true; g.add(inst);
      const d = new THREE.Object3D();
      let off = 0;
      const place = () => {
        for (let i = 0; i < N; i++) {
          let q = (((i / N) * P + off) % P + P) % P;
          let x: number, y: number, a: number;
          if (q < 2 * Ls) { x = Ls - q; y = 0.025; a = Math.PI; }
          else if ((q -= 2 * Ls) < Math.PI * r) { const f = q / r; x = -Ls - Math.sin(f) * r; y = r - Math.cos(f) * r; a = Math.PI - f; }
          else if ((q -= Math.PI * r) < 2 * Ls) { x = -Ls + q; y = 2 * r - 0.025; a = 0; }
          else { q -= 2 * Ls; const f = q / r; x = Ls + Math.sin(f) * r; y = r + Math.cos(f) * r; a = -f; }
          d.position.set(x, y, s * 1.45); d.rotation.set(0, 0, a); d.updateMatrix(); inst.setMatrixAt(i, d.matrix);
        }
        inst.instanceMatrix.needsUpdate = true;
      };
      place();
      v.anims.push((dt, st) => { off += st.speed * dt * 1.0; place(); });
      // road wheels, sprocket, idler
      const addW = (x: number, y: number, R: number, rr: number) => {
        const sp = new THREE.Group(); sp.position.set(x, y, s * 1.45);
        const w = cyl(R, R, 0.2, std('#3a3d38', 0.7, 0.5), 'z', 24); const hubc = cyl(R * 0.45, R * 0.45, 0.24, m.steel, 'z', 12);
        sp.add(w, hubc);
        for (let k = 0; k < 6; k++) { const b = cyl(0.02, 0.02, 0.26, m.darkMetal, 'z', 6); b.position.set(Math.cos(k) * R * 0.7, Math.sin(k) * R * 0.7, 0); sp.add(b); }
        g.add(sp); v.wheels.push({ steer: null, spin: sp, R: rr, side: s });
      };
      for (let i = 0; i < 7; i++) addW(-2.4 + i * 0.8, 0.44, 0.38, 0.38);
      addW(-Ls, r, 0.52, 0.52); addW(Ls, r, 0.5, 0.5);
      for (let i = 0; i < 4; i++) addW(-1.6 + i * 1.1, 1.05, 0.12, 0.12);
    });
    // turret
    const ts = new THREE.Shape();
    const tp: [number, number][] = [[-1.5, 0], [-1.7, 0.9], [-0.8, 1.35], [0.9, 1.3], [1.5, 0.7], [1.4, -0.6], [0.8, -1.3], [-0.8, -1.35], [-1.7, -0.9]];
    ts.moveTo(tp[0][0], tp[0][1]); tp.slice(1).forEach((p) => ts.lineTo(p[0], p[1])); ts.closePath();
    const tg = new THREE.ExtrudeGeometry(ts, { depth: 0.65, bevelEnabled: true, bevelSize: 0.15, bevelThickness: 0.12, bevelSegments: 4 });
    tg.rotateX(-Math.PI / 2); tg.scale(0.9, 1, 0.9); tg.translate(0.0, 1.6, 0);
    const turret = new THREE.Group();
    const tm = new THREE.Mesh(tg, olive); tm.castShadow = true; turret.add(tm);
    const mant = rbox(0.5, 0.6, 0.9, 0.2, olive); at(mant, 1.05, 2.0, 0); turret.add(mant);
    const gun = cyl(0.11, 0.12, 4.6, dark, 'x', 20); at(gun, 3.2, 2.0, 0); turret.add(gun);
    const ejector = cyl(0.17, 0.17, 0.6, dark, 'x', 20); at(ejector, 2.3, 2.0, 0); turret.add(ejector);
    const brake = cyl(0.17, 0.17, 0.35, dark, 'x', 20); at(brake, 5.35, 2.0, 0); turret.add(brake);
    const bore = cyl(0.07, 0.07, 0.36, m.black, 'x', 12); at(bore, 5.36, 2.0, 0); turret.add(bore);
    const mg = cyl(0.03, 0.03, 0.9, m.black, 'x', 8); at(mg, 1.4, 2.1, 0.45); turret.add(mg);
    const sb = rbox(0.9, 0.35, 0.12, 0.03, dark); at(sb, -1.2, 1.95, -0.7); turret.add(sb); const sb2 = sb.clone(); sb2.position.z = 0.7; turret.add(sb2);
    const bas = rbox(0.6, 0.5, 1.6, 0.08, olive); at(bas, -1.15, 2.0, 0); turret.add(bas);
    for (const z of [-0.5, -0.35, 0.35, 0.5]) { const sm = cyl(0.04, 0.04, 0.2, m.black, 'x', 8); at(sm, 0.9, 2.15, z * 1.4); sm.rotation.z = 0.6; turret.add(sm); }
    const ant = cyl(0.012, 0.012, 2.4, m.black, 'y', 6); at(ant, -1.5, 3.1, 0.9); turret.add(ant);
    // hatches
    const hole = cyl(0.36, 0.36, 0.02, m.black, 'y', 20);
    sym((s) => {
      const hx = s > 0 ? -0.2 : -0.3, hz = s * 0.55;
      const hc = cyl(0.4, 0.4, 0.1, olive, 'y', 20); at(hc, hx, 2.25, hz); turret.add(hc);
      const hl = hole.clone(); at(hl, hx, 2.31, hz); turret.add(hl);
      const piv = new THREE.Group(); piv.position.set(hx - 0.38, 2.33, hz);
      const lid = cyl(0.37, 0.37, 0.06, olive, 'y', 20); at(lid, 0.38, 0, 0); piv.add(lid);
      const hdl = tube([V(0.2, 0.05, -0.1), V(0.2, 0.15, 0), V(0.2, 0.05, 0.1)], 0.015, m.steel); piv.add(hdl);
      turret.add(piv);
      let cur = 0;
      v.anims.push((dt, st) => { const tg2 = s < 0 ? st.doorL : st.doorR; cur += (tg2 - cur) * Math.min(1, dt * 4); piv.rotation.z = cur * 1.5; });
      const hm = sphere(0.17, std('#c9a77a', 0.7)); at(hm, hx, 2.35, hz); void hm;
    });
    turret.position.set(0.2, 0, 0);
    g.add(turret);
    // engine deck grilles & periscopes
    for (let i = 0; i < 6; i++) { const gr = box(0.06, 0.02, 1.4, dark); at(gr, -2.9 + i * 0.12, 1.62, 0); g.add(gr); }
    const dr = rbox(0.5, 0.35, 0.55, 0.1, olive); at(dr, 2.4, 1.6, -0.5); g.add(dr);
    const lampT = cyl(0.1, 0.1, 0.06, m.headLamp, 'x', 14); at(lampT, 3.55, 1.1, 0.8); g.add(lampT); const lamp2 = lampT.clone(); lamp2.position.z = -0.8; g.add(lamp2); v.lightMats.head.push(m.headLamp);
    const tow = tube([V(3.6, 0.85, 0.6), V(3.4, 0.6, 0.3), V(3.4, 0.6, -0.3), V(3.6, 0.85, -0.6)], 0.035, dark); g.add(tow);
    v.eye.set(0.3, 2.9, 0.0);
    v.size = { L: 11.0, W: 3.5, H: 3.1 };
    g.position.x = -0.9;
    v.eye.x -= 0.9;
    void lerp; void canvasTex; void add;
  }
  return v;
}

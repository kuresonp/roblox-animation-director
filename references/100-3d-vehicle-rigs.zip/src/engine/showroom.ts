import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Vehicle, State } from './types';
import { disposeTree, roadTexture } from './util';

export type ViewMode = 'orbit' | 'driver' | 'front' | 'rear' | 'side' | 'top' | 'cabin';

export class Showroom {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  controls: OrbitControls;
  vehicle: Vehicle | null = null;
  state: State = { speed: 0, steer: 0, doorL: 0, doorR: 0, lights: false, time: 0 };
  targetSpeed = 0;
  mode: ViewMode = 'orbit';
  autoRotate = false;
  road: THREE.Mesh;
  roadTex: THREE.Texture;
  posts: THREE.Group;
  dist = 0;
  sun: THREE.DirectionalLight;
  raf = 0;
  last = performance.now();
  yaw = 0; pitch = 0;
  camTween: { p: THREE.Vector3; t: THREE.Vector3; k: number } | null = null;
  drag = false;
  ro: ResizeObserver;

  constructor(public el: HTMLElement) {
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance', preserveDrawingBuffer: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    el.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.display = 'block';

    const sky = document.createElement('canvas'); sky.width = 4; sky.height = 256;
    const sg = sky.getContext('2d')!; const gr = sg.createLinearGradient(0, 0, 0, 256);
    gr.addColorStop(0, '#05080f'); gr.addColorStop(0.55, '#1c2a40'); gr.addColorStop(0.75, '#3a5273'); gr.addColorStop(1, '#5d7597');
    sg.fillStyle = gr; sg.fillRect(0, 0, 4, 256);
    const skyTex = new THREE.CanvasTexture(sky); skyTex.colorSpace = THREE.SRGBColorSpace;
    this.scene.background = skyTex;
    this.scene.fog = new THREE.Fog(0x4a617f, 50, 200);
    const pm = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pm.fromScene(new RoomEnvironment(), 0.03).texture;
    this.scene.environmentIntensity = 0.95;

    this.camera = new THREE.PerspectiveCamera(40, 1, 0.05, 600);
    this.camera.position.set(6, 2.2, 7);
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.maxPolarAngle = Math.PI * 0.495;
    this.controls.minDistance = 1.2;
    this.controls.maxDistance = 40;

    this.sun = new THREE.DirectionalLight(0xfff1de, 2.4);
    this.sun.position.set(-8, 14, 9);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    this.sun.shadow.bias = -0.0004;
    this.sun.shadow.normalBias = 0.03;
    this.scene.add(this.sun, this.sun.target);
    const rim = new THREE.DirectionalLight(0x8fb4ff, 1.1);
    rim.position.set(9, 5, -9);
    this.scene.add(rim);
    this.scene.add(new THREE.HemisphereLight(0xbcd0ff, 0x1a1c20, 0.5));

    // ground
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(600, 600), new THREE.MeshStandardMaterial({ color: 0x14181d, roughness: 1 }));
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.01;
    ground.receiveShadow = true;
    this.scene.add(ground);
    this.roadTex = roadTexture();
    this.roadTex.repeat.set(40, 1);
    this.roadTex.anisotropy = 8;
    this.roadTex.colorSpace = THREE.SRGBColorSpace;
    this.road = new THREE.Mesh(new THREE.PlaneGeometry(320, 16), new THREE.MeshStandardMaterial({ map: this.roadTex, roughness: 0.82, metalness: 0.05 }));
    this.road.rotation.x = -Math.PI / 2;
    this.road.receiveShadow = true;
    this.scene.add(this.road);
    this.posts = new THREE.Group();
    const postGeo = new THREE.CylinderGeometry(0.06, 0.08, 1.2, 8);
    const postMat = new THREE.MeshStandardMaterial({ color: 0xdadada, roughness: 0.5 });
    const capMat = new THREE.MeshStandardMaterial({ color: 0xff7a1a, emissive: 0xff5500, emissiveIntensity: 0.4 });
    for (let i = 0; i < 28; i++) for (const s of [-1, 1]) {
      const p = new THREE.Mesh(postGeo, postMat);
      p.position.set(0, 0.6, s * 9.2);
      p.userData.i = i;
      const cap = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.2, 0.05), capMat);
      cap.position.y = 0.45;
      p.add(cap);
      p.castShadow = true;
      this.posts.add(p);
    }
    this.scene.add(this.posts);

    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(el);
    this.resize();
    const dom = this.renderer.domElement;
    dom.addEventListener('pointerdown', () => { this.drag = true; });
    window.addEventListener('pointerup', () => { this.drag = false; });
    dom.addEventListener('pointermove', (e) => {
      if (this.mode === 'driver' && this.drag) {
        this.yaw -= e.movementX * 0.004;
        this.pitch = Math.max(-1.0, Math.min(1.0, this.pitch - e.movementY * 0.004));
      }
    });
    this.loop();
  }

  resize() {
    const w = this.el.clientWidth || 1, h = this.el.clientHeight || 1;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  load(v: Vehicle) {
    if (this.vehicle) { this.scene.remove(this.vehicle.group); disposeTree(this.vehicle.group); }
    this.vehicle = v;
    this.scene.add(v.group);
    const { L, W, H } = v.size;
    const s = Math.max(L, W * 1.5, H * 1.5);
    const sc = this.sun.shadow.camera;
    const r = s * 0.8 + 2;
    sc.left = -r; sc.right = r; sc.top = r; sc.bottom = -r; sc.near = 1; sc.far = 80;
    sc.updateProjectionMatrix();
    this.sun.position.set(-s * 0.7, s * 1.1 + 6, s * 0.8);
    this.setView(this.mode === 'driver' ? 'driver' : 'orbit', true);
  }

  setView(mode: ViewMode, instant = false) {
    this.mode = mode;
    const v = this.vehicle;
    if (!v) return;
    const { L, W, H } = v.size;
    const d = Math.max(L * 1.05, 4) + 1.5;
    const tgt = new THREE.Vector3(0, H * 0.42, 0);
    let pos = new THREE.Vector3(d * 0.72, H * 0.75 + 0.8, d * 0.78);
    this.controls.enabled = mode !== 'driver';
    switch (mode) {
      case 'front': pos = new THREE.Vector3(d * 0.95, H * 0.6 + 0.4, d * 0.28); break;
      case 'rear': pos = new THREE.Vector3(-d * 0.95, H * 0.7 + 0.6, -d * 0.3); break;
      case 'side': pos = new THREE.Vector3(0, H * 0.55 + 0.3, d * 1.05); break;
      case 'top': pos = new THREE.Vector3(0.01, d * 0.95, 0.01); break;
      case 'cabin': {
        const e = v.eye;
        tgt.set(e.x - 0.1, e.y - 0.35, 0);
        pos = new THREE.Vector3(e.x - 1.7 - L * 0.04, e.y + 1.35 + H * 0.25, -W * 1.2);
        break;
      }
      case 'driver': this.yaw = 0; this.pitch = -0.04; return;
      default: break;
    }
    if (instant) { this.camera.position.copy(pos); this.controls.target.copy(tgt); this.camTween = null; this.controls.update(); }
    else this.camTween = { p: pos, t: tgt, k: 0 };
  }

  loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    const st = this.state;
    st.time += dt;
    const tgt = this.targetSpeed / 3.6;
    st.speed += (tgt - st.speed) * Math.min(1, dt * 1.6);
    if (Math.abs(tgt - st.speed) < 0.02) st.speed = tgt;
    if (this.vehicle) {
      this.vehicle.update(dt, st);
      // slight pitch / bump
      this.vehicle.group.rotation.z = -st.steer * st.speed * 0.0009;
      this.vehicle.group.position.y = Math.sin(st.time * 40) * Math.min(1, st.speed / 40) * 0.0016;
    }
    // world scrolling
    this.dist += st.speed * dt;
    this.roadTex.offset.x += (st.speed * dt) / (320 / 40);
    const span = 28 * 6;
    this.posts.children.forEach((p) => {
      const i = p.userData.i as number;
      let x = i * 6 - this.dist;
      x = ((x % span) + span) % span - span / 2;
      p.position.x = x;
    });
    if (this.camTween) {
      const t = this.camTween;
      t.k = Math.min(1, t.k + dt * 2.2);
      const e = t.k * t.k * (3 - 2 * t.k);
      this.camera.position.lerp(t.p, e * 0.25 + 0.02);
      this.controls.target.lerp(t.t, e * 0.25 + 0.02);
      if (t.k >= 1) this.camTween = null;
    }
    if (this.mode === 'driver' && this.vehicle) {
      const e = this.vehicle.eye;
      this.camera.position.set(e.x, e.y, e.z);
      const dir = new THREE.Vector3(Math.cos(this.yaw) * Math.cos(this.pitch), Math.sin(this.pitch), -Math.sin(this.yaw) * Math.cos(this.pitch));
      this.camera.lookAt(e.x + dir.x, e.y + dir.y, e.z + dir.z);
      this.camera.fov = 70;
    } else {
      this.camera.fov = 40;
      if (this.autoRotate) this.controls.autoRotate = true; else this.controls.autoRotate = false;
      this.controls.autoRotateSpeed = 1.2;
      this.controls.update();
    }
    this.camera.updateProjectionMatrix();
    this.renderer.render(this.scene, this.camera);
  };

  dispose() {
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    this.controls.dispose();
    this.renderer.dispose();
    this.el.removeChild(this.renderer.domElement);
  }
}

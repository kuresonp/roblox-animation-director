import * as THREE from 'three';
import { Ctx } from './types';
import { rbox, box, cyl, makeSeat, makeSteeringWheel, add, at } from './parts';
import { Cluster, screenTexture } from './util';
import { MB } from './loft';

export function buildInterior(c: Ctx) {
  const { spec, m, halfW, interior: I } = c;
  const sw = halfW / 0.9;
  const ds = spec.rhd ? 1 : -1;
  const dz = ds * 0.38 * sw;
  const beltH = spec.beltH;
  const floorY = c.floorY;
  const dashTop = beltH - 0.06;
  const dashBack = c.steerX + 0.3;
  const dashFront = c.xCowl - 0.03;
  const dashW = 2 * (halfW * 0.86);
  const dashLen = Math.max(0.2, dashFront - dashBack);
  const dashX = (dashBack + dashFront) / 2;

  // ---------- dashboard
  const dash = new THREE.Group();
  const top = rbox(dashLen, 0.2, dashW, 0.05, m.dash);
  at(top, dashX, dashTop - 0.1, 0);
  const knee = rbox(0.1, dashTop - floorY - 0.12, dashW * 0.96, 0.03, m.trim2);
  at(knee, dashBack + 0.06, floorY + (dashTop - floorY - 0.12) / 2 + 0.02, 0);
  const lowerTrim = rbox(0.02, 0.05, dashW * 0.9, 0.012, m.darkMetal);
  at(lowerTrim, dashBack - 0.002, dashTop - 0.26, 0);
  const strip = rbox(0.012, 0.022, dashW * 0.96, 0.008, spec.cat === 'classic' ? m.chrome : m.darkMetal);
  at(strip, dashBack - 0.002, dashTop - 0.045, 0);
  const strip2 = rbox(0.008, 0.012, dashW * 0.6, 0.004, m.chrome);
  at(strip2, dashBack - 0.004, dashTop - 0.075, 0);
  const glove = rbox(0.012, 0.13, 0.4 * sw, 0.015, m.trim2);
  at(glove, dashBack - 0.002, dashTop - 0.16, -dz * 0.95);
  const gloveHandle = rbox(0.014, 0.012, 0.1, 0.005, m.chrome);
  at(gloveHandle, dashBack - 0.01, dashTop - 0.1, -dz * 0.95);
  add(dash, top, knee, lowerTrim, strip, strip2, glove, gloveHandle);
  // defrost vents
  const defrost = rbox(0.08, 0.008, dashW * 0.78, 0.004, m.black);
  at(defrost, dashX + dashLen * 0.28, dashTop + 0.002, 0);
  dash.add(defrost);

  // instrument binnacle + live cluster
  const bin = rbox(0.22, 0.15, 0.46, 0.05, m.dash);
  at(bin, dashBack - 0.01, dashTop + 0.05, dz);
  const brow = rbox(0.1, 0.012, 0.44, 0.005, m.black);
  at(brow, dashBack - 0.08, dashTop + 0.125, dz);
  const cl = new Cluster(spec.cat === 'classic' ? '#ffb347' : '#35c7ff');
  c.v.cluster = cl;
  const clPlane = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.15), new THREE.MeshBasicMaterial({ map: cl.tex, toneMapped: false }));
  clPlane.rotation.y = -Math.PI / 2;
  clPlane.rotation.x = 0.0;
  at(clPlane, dashBack - 0.113, dashTop + 0.06, dz);
  const clGlass = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.16), new THREE.MeshPhysicalMaterial({ color: 0x000000, transparent: true, opacity: 0.12, roughness: 0.05 }));
  clGlass.rotation.y = -Math.PI / 2;
  at(clGlass, dashBack - 0.117, dashTop + 0.06, dz);
  add(dash, bin, brow, clPlane, clGlass);

  // centre screen + vents + stack
  const scrTex = screenTexture();
  const frame = rbox(0.03, 0.17, 0.3, 0.012, m.black);
  at(frame, dashBack - 0.02, dashTop + 0.075, 0);
  frame.rotation.z = 0.2;
  const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.27, 0.14), new THREE.MeshBasicMaterial({ map: scrTex, toneMapped: false }));
  scr.rotation.set(0, -Math.PI / 2, 0.2);
  at(scr, dashBack - 0.0365, dashTop + 0.078, 0);
  add(dash, frame, scr);
  for (const zz of [-0.42, -0.2, 0.2, 0.42]) {
    const vz = zz * sw;
    const vb = rbox(0.016, 0.05, 0.12, 0.008, m.black);
    at(vb, dashBack - 0.003, dashTop - 0.12, vz);
    dash.add(vb);
    for (let k = -1; k <= 1; k++) {
      const sl = box(0.008, 0.004, 0.1, m.chrome);
      at(sl, dashBack - 0.011, dashTop - 0.12 + k * 0.012, vz);
      dash.add(sl);
    }
  }
  const stack = rbox(0.09, 0.2, 0.2, 0.02, m.trim2);
  at(stack, dashBack + 0.0, dashTop - 0.3, 0);
  dash.add(stack);
  for (const kz of [-0.06, 0, 0.06]) {
    const knob = cyl(0.016, 0.016, 0.02, m.chrome, 'x', 20);
    at(knob, dashBack - 0.052, dashTop - 0.27, kz);
    dash.add(knob);
    for (const ky of [-0.32, -0.36]) {
      const btn = rbox(0.008, 0.016, 0.03, 0.004, m.black);
      at(btn, dashBack - 0.046, dashTop + ky + 0.03, kz);
      dash.add(btn);
    }
  }
  I.add(dash);

  // ---------- steering
  const st = makeSteeringWheel(m, 0.185 * Math.min(1.5, 1 + (spec.steerH ?? 0.6) * 0.35 - 0.2), spec.cat === 'sport');
  const steerY = floorY + (spec.steerH ?? 0.6);
  st.root.position.set(c.steerX, steerY, dz);
  c.v.steerWheel = st.spinG;
  I.add(st.root);
  // pedals
  for (let k = 0; k < 3; k++) {
    const p = rbox(0.02, k === 0 ? 0.04 : 0.09, k === 0 ? 0.12 : 0.05, 0.006, k === 2 ? m.darkMetal : m.black);
    at(p, c.steerX + 0.34, floorY + 0.1, dz + (k - 1.4) * 0.13 * sw);
    p.rotation.z = 0.5;
    I.add(p);
  }
  const dead = rbox(0.03, 0.1, 0.1, 0.01, m.darkMetal);
  at(dead, c.steerX + 0.36, floorY + 0.1, dz - ds * 0.2);
  dead.rotation.z = 0.6;
  I.add(dead);

  // ---------- seats
  const seatH = spec.seatH ?? 0.3;
  const rows = spec.rows ?? [{ n: 2 }, { n: 3, kind: 'bench' as const }];
  const gap = spec.rowGap ?? 0.88;
  let lastX = c.seatX;
  rows.forEach((row, k) => {
    const x = row.x ?? c.seatX - k * gap + (row.dx ?? 0);
    lastX = Math.min(lastX, x);
    const kind = row.kind ?? (k === 0 ? (spec.seatKind ?? 'bucket') : 'bench');
    const h = row.h ?? seatH + (k > 0 && spec.cat !== 'bus' ? 0.03 : 0);
    if (row.zs) {
      row.zs.forEach((z) => {
        const s = makeSeat(m, { kind: kind === 'bus' ? 'bus' : 'bucket', w: 0.46, h, back: 0.62 });
        at(s, x, floorY, z);
        I.add(s);
      });
    } else if (kind === 'bench') {
      const wBench = (2 * halfW - 0.5) * 0.98;
      const s = makeSeat(m, { kind: 'bench', w: wBench, h, headrests: row.n });
      at(s, x, floorY, 0);
      I.add(s);
      if (k > 0) {
        const arm = rbox(0.12, 0.06, 0.24, 0.02, m.trim);
        arm.position.set(x - 0.2, floorY + h + 0.34, 0);
        arm.rotation.z = 0.2;
        I.add(arm);
      }
    } else {
      const n = row.n;
      const zsList = n === 1 ? [dz] : n === 2 ? [-0.38 * sw, 0.38 * sw] : n === 3 ? [-0.55 * sw, 0, 0.55 * sw] : [-0.7 * sw, -0.23 * sw, 0.23 * sw, 0.7 * sw];
      zsList.forEach((z) => {
        const s = makeSeat(m, { kind: kind as any, w: n >= 3 ? 0.42 * sw : 0.5, h });
        at(s, x, floorY, z);
        I.add(s);
      });
    }
  });
  const cargoOpen = (spec.rwRun < 0.4 && spec.open !== 'bed' && spec.open !== 'convertible') || spec.opts?.cargo;
  const floorBack = cargoOpen ? c.xmin + 0.18 : lastX - 0.5;

  // ---------- floor, tunnel, console
  const fw = 2 * (halfW - 0.2);
  const floor = rbox(dashBack - floorBack, 0.05, fw, 0.01, m.carpet, 1);
  at(floor, (dashBack + floorBack) / 2, floorY - 0.025, 0);
  I.add(floor);
  const tunnel = rbox(dashBack - floorBack - 0.1, 0.11, 0.2 * sw, 0.05, m.carpet);
  at(tunnel, (dashBack + floorBack) / 2 - 0.05, floorY + 0.035, 0);
  I.add(tunnel);
  const frontSeat = c.seatX;
  if (rows[0].n >= 2 && rows[0].kind !== 'bench' && spec.seatKind !== 'bench') {
    const cx0 = frontSeat - 0.25, cx1 = Math.min(dashBack - 0.08, frontSeat + 0.62);
    const consH = (spec.open === 'bed' || spec.heavy) ? 0.3 : 0.26;
    const con = rbox(cx1 - cx0, consH, 0.22 * sw, 0.045, m.trim2);
    at(con, (cx0 + cx1) / 2, floorY + consH / 2 + 0.05, 0);
    I.add(con);
    const arm = rbox(0.34, 0.07, 0.19 * sw, 0.03, m.trim);
    at(arm, cx0 + 0.19, floorY + consH + 0.075, 0);
    I.add(arm);
    // shifter
    const base = rbox(0.12, 0.012, 0.09, 0.005, m.black);
    at(base, cx1 - 0.2, floorY + consH + 0.058, 0);
    const lever = cyl(0.008, 0.01, 0.1, m.black, 'y', 10);
    at(lever, cx1 - 0.2, floorY + consH + 0.11, 0);
    const knob = new THREE.Mesh(new THREE.SphereGeometry(0.026, 20, 14), m.trim2);
    at(knob, cx1 - 0.2, floorY + consH + 0.17, 0);
    knob.scale.set(1, 1.2, 1);
    const cupR = new THREE.Mesh(new THREE.TorusGeometry(0.036, 0.004, 8, 24), m.chrome);
    cupR.rotation.x = Math.PI / 2;
    at(cupR, cx1 - 0.06, floorY + consH + 0.06, 0.0);
    const cup = cyl(0.034, 0.034, 0.008, m.black, 'y', 20);
    at(cup, cx1 - 0.06, floorY + consH + 0.056, 0.0);
    const btn = cyl(0.016, 0.016, 0.01, m.black, 'y', 16);
    at(btn, cx1 - 0.35, floorY + consH + 0.058, 0.04);
    const redRing = new THREE.Mesh(new THREE.TorusGeometry(0.016, 0.002, 6, 20), new THREE.MeshStandardMaterial({ color: 0xff3030, emissive: 0xff2020, emissiveIntensity: 0.6 }));
    redRing.rotation.x = Math.PI / 2;
    at(redRing, cx1 - 0.35, floorY + consH + 0.063, 0.04);
    add(I, base, lever, knob, cupR, cup, btn, redRing);
  } else {
    // column / bench cars: handbrake & small floor shifter
    const hb = cyl(0.01, 0.01, 0.2, m.black, 'y', 10);
    at(hb, c.seatX + 0.42, floorY + 0.2, 0.0);
    hb.rotation.z = 0.3;
    I.add(hb);
  }
  // floor mats
  for (const zz of [dz, -dz]) {
    const mat = rbox(0.5, 0.012, 0.36 * sw, 0.004, m.black, 1);
    at(mat, c.steerX + 0.3, floorY + 0.003, zz);
    I.add(mat);
  }

  // ---------- cargo area lining (vans / wagons / SUVs)
  if (cargoOpen) {
    for (const sg of [-1, 1]) {
      const w = rbox(lastX - 0.4 - floorBack + 0.0 + (c.xmin + 0.18 - floorBack) * 0 + 0.9, spec.beltH - floorY - 0.02, 0.04, 0.01, m.carpet, 1);
      at(w, floorBack + (lastX - 0.4 - floorBack) / 2 + 0.2, floorY + (spec.beltH - floorY) / 2, sg * (halfW * 0.9));
      I.add(w);
      const arch = rbox(0.55, 0.2, 0.2, 0.05, m.carpet);
      at(arch, c.axleR, floorY + 0.12, sg * (halfW * 0.78));
      I.add(arch);
    }
    const back = rbox(0.04, spec.beltH - floorY, 2 * halfW * 0.85, 0.01, m.carpet, 1);
    at(back, c.xmin + 0.12, floorY + (spec.beltH - floorY) / 2, 0);
    I.add(back);
  }

  // ---------- headliner (follows the roof)
  const roofed = spec.open !== 'convertible' && (spec.open as string) !== 'targa';
  if (roofed) {
    const hb = new MB();
    const xa = Math.min(c.xRoofR + 0.05, c.xRoofF - 0.2), xb = c.xRoofF + 0.08;
    const n = 14;
    const rowsZ = [-1, -0.5, 0, 0.5, 1];
    const idx: number[][] = [];
    for (let i = 0; i <= n; i++) {
      idx[i] = [];
      const x = xa + ((xb - xa) * i) / n;
      const s = c.body.sec(x);
      const wTop = s.P[c.body.rows.iBandEnd + 1][0] * 0.96;
      rowsZ.forEach((f, jj) => {
        const y = s.yT - 0.045 + 0.012 * (1 - f * f) + (jj === 0 || jj === 4 ? -0.03 : 0);
        idx[i][jj] = hb.v(x, y, f * wTop);
      });
    }
    for (let i = 0; i < n; i++) for (let j = 0; j < rowsZ.length - 1; j++) hb.q(idx[i][j], idx[i + 1][j], idx[i + 1][j + 1], idx[i][j + 1], 'h');
    I.add(hb.build({ h: m.headliner }, false));
    // sun visors & mirror & dome light
    const visY = c.topAt(c.xRoofF) - 0.1;
    for (const sg of [-1, 1]) {
      const v = rbox(0.02, 0.1, 0.34, 0.01, m.headliner);
      at(v, c.xRoofF + 0.1, visY, sg * 0.34 * sw);
      v.rotation.z = 0.15;
      I.add(v);
    }
    const stem = cyl(0.008, 0.008, 0.08, m.black, 'y', 8);
    at(stem, c.xRoofF + 0.14, c.topAt(c.xRoofF + 0.14) - 0.075, 0);
    const mir = rbox(0.03, 0.065, 0.26, 0.015, m.black);
    at(mir, c.xRoofF + 0.15, c.topAt(c.xRoofF + 0.14) - 0.15, 0);
    const mirG = new THREE.Mesh(new THREE.PlaneGeometry(0.24, 0.05), new THREE.MeshStandardMaterial({ color: 0xb4c0c8, metalness: 1, roughness: 0.05 }));
    mirG.rotation.y = -Math.PI / 2;
    at(mirG, c.xRoofF + 0.133, c.topAt(c.xRoofF + 0.14) - 0.15, 0);
    add(I, stem, mir, mirG);
  }
  // eye position
  c.v.eye.set(c.seatX - 0.08, floorY + seatH + 0.6, dz);
  return { dz, dashBack, lastX };
}
